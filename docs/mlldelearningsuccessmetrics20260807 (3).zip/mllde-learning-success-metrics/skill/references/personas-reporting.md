<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. profeanaeslava · profeanaeslavaedtech · UPV. Part of a PhD proposal. Full APA list: references/apa-references.md -->

# Persona reporting pack — three blueprints, one data layer

All three reports are queries over the same LRS data (performance stream +
pedagogy stream + incident stream). Design the data once; render three lenses.

## 1. Independent learner — the dual ledger

Immersion is preserved: the learner sees the product's own metaphor; the CEFR
runs underneath. The report has two columns with an explicit mapping:

- **Game layer (visible):** stamps, coins, ranks, streaks, missions completed,
  "clearer speech" wins (successful model imitations).
- **CEFR layer (underneath, revealed on demand or at milestones):** current
  band per skill, descriptor evidenced ("you can now order in a café —
  that's A2 'Obtaining goods and services'"), next-step guidance in can-do
  language.

Rules: never lead with numbers the learner can't act on; always pair a result
with the next action; retries and help requests are shown as effort, never as
failure. Accessibility signals (slow-downs, text fallback) never appear in the
learner view as deficits.

## 2. Teacher (human or AI agent) — the adaptation report

Two renderings of the same content; produce both.

**Human-readable:** per learner and period — bands per skill/scale with trend;
rubric-category profile (which category caps the pass); pedagogical actions
already tried and their outcomes; recommended next adaptations (support
changes only — task and rubric never change); flagged incidents affecting
validity (low-ASR sessions excluded from scores).

**Machine-readable JSON** — the aggregated NLU→Pedagogy handoff contract
(per-turn → per-session → per-period), so an AI tutor can consume it directly:

```json
{
  "learner": "learner-8842",
  "period": { "from": "...", "to": "..." },
  "cefrLevel": "https://w3id.org/mllde/cefr/level/a2",
  "skills": [{
    "skill": "https://w3id.org/mllde/cefr/skill/speaking",
    "scales": [{
      "scale": "https://w3id.org/mllde/cefr/scale/obtaining-goods-services",
      "taskGate": { "attempts": 3, "completions": 2, "retriesToFirstPass": 1 },
      "rubricProfile": { "grammar-accuracy": 2.0, "vocabulary-range": 2.7,
        "pronunciation-phonological-control": 1.8, "intelligibility": 2.5,
        "interaction": 2.2 },
      "evidenceTier": "1-measurable-today"
    }],
    "pronunciation": { "targets": [{ "ipa": "r", "trend": "improving",
      "tier": "2-instrumented" }] }
  }],
  "pedagogyTried": [{ "action": "implicit-recast", "count": 14,
    "followedByImprovement": 9 }],
  "recommendations": [{ "type": "support-change",
    "detail": "more modelling before invited turns on /r/ targets" }],
  "validityFlags": [{ "incident": "low-asr-confidence", "sessions": 2,
    "handling": "excluded from scoring" }]
}
```

The AI teacher's adaptation loop: read `rubricProfile` floors → check
`pedagogyTried` (never repeat a failed strategy blindly) → adjust support →
next report verifies effect. The human teacher reads the same logic in prose.

## 3. LMS administrator → HR — KPI, ROI, incidents

**KPI section (proficiency & progress):** active learners; completion rate;
band-progression rate (learners advancing ≥1 band per period, verb
`progressed`); time-to-band; pass-floor distribution. Optionally attach the
ESCO language-skill URI so EU HR systems consuming ESCO can read results.

**ROI section (Kirkpatrick levels 1–4 + Phillips Level 5):** map evidence to
levels — reaction (UX signal), learning (band progression), behaviour (task
transfer), results (business measure the client names), then
**ROI (%) = (net programme benefits − programme costs) ÷ programme costs × 100**
(Phillips & Phillips, 2016). **Every claimed benefit states its evidence
tier** — where the evidence base is expert evaluation and UX testing rather
than cohort data, the report says so plainly and pairs the claim with the
xAPI measurement plan that will close the gap.

**Incident section (independent family — never folded into KPI):** per
incident type (registry): rate, severity distribution, affected sessions, and
the **resolution ledger** — incident → change made → post-change rate. This is
the system-improvement loop and the honest part of the ROI story: improvements
are demonstrated, not asserted.
