<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. profeanaeslava · profeanaeslavaedtech · UPV. Part of a PhD proposal. CEFR © Council of Europe. Full APA list: references/apa-references.md -->

# The MLLDE self-scaling rubric model

## The core pattern (from Voicemode — canonical for speaking)

Assessment is an **authentic task** (a mission: service encounter,
introduction, negotiation…), not a test. Two layers:

1. **Task gate (binary).** The task is completed appropriately →
   `<MISSION_COMPLETE>` (verb `completed`). Unlimited, non-punitive retries;
   retries are telemetry, not punishment.
2. **Performance rubric (graded).** Five categories, each banded **1–3 read
   against the level's descriptor**:

| Category | CEFR feature | Registry IRI slug |
| --- | --- | --- |
| Grammar | Accuracy | `rubric/grammar-accuracy` |
| Vocabulary | Range | `rubric/vocabulary-range` |
| Pronunciation | Phonological control | `rubric/pronunciation-phonological-control` |
| Intelligibility | Comprehensibility | `rubric/intelligibility` |
| Interaction | Interaction / fluency | `rubric/interaction` |

**Pass = task completed AND floors met: intelligibility ≥ 2 ∧ interaction ≥ 2.**

**Why "read against the descriptor" matters:** the same instrument covers
Pre-A1–C2 because band 3 means "consistent *for this level's can-do
descriptor*" — a 3 at A2 ≠ a 3 at C1. One rubric, applied live in one pass, in
any language. Never redesign it per level; only the descriptor it is read
against changes.

## Extending the pattern to the other four skills

Keep the two-layer shape (task gate + self-scaling categories + floors); swap
the categories to fit the channel.

**Writing** — gate: the written task fulfils its communicative purpose.
Categories: Grammar/Accuracy · Vocabulary/Range · **Orthographic control**
(replaces pronunciation) · **Coherence & cohesion** (replaces
intelligibility's role) · **Register & appropriateness** (replaces
interaction). Floors: coherence ≥ 2 ∧ appropriateness ≥ 2.

**Listening / Reading (reception)** — no production to band, so the rubric is
replaced by **comprehension evidence**: machine-scorable items (choice,
matching, ordering, gap-fill) mapped to the scale's descriptor. Metrics:
accuracy rate, level-appropriate text/audio difficulty, support used (replays,
slow-downs — process-support family, never a penalty). Pass threshold defined
per level in D1.

**Mediation** — gate: the mediation purpose is achieved (the recipient could
act on the relayed/explained content). Categories: production-channel rubric
(speaking or writing, per output channel) **plus** three mediation criteria:
**Content fidelity** (nothing essential lost or distorted) · **Audience
adaptation** (language adjusted to the recipient) · **Bridging strategy**
(reformulating, simplifying, summarising appropriately). Floors: intelligibility
(or coherence) ≥ 2 ∧ content fidelity ≥ 2.

## Item types and what telemetry can capture

- **Machine-scorable** (reception): every response auto-logged; tier 1.
- **AI-judge scored** (production, mediation): the agent bands the rubric live
  against the descriptor; log the bands *and* the judged evidence (transcript
  reference); tier 1 with the judge named in the statement context.
- **Voice-instrumented** (speaking): pronunciation attempts, phoneme scores,
  latency — tier 2/3 per `references/evidence-tiers-and-voice.md`.

## Non-negotiables inherited from MLLDE

Adaptation changes **support only** — never the task or the rubric. Feedback is
non-punitive (amber, "Don't give up!"), correction is by recast/modelling, and
every pedagogical action taken is logged with its IRI (dual telemetry).
