<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. profeanaeslava · profeanaeslavaedtech · UPV. Part of a PhD proposal. IPA © International Phonetic Association. Full APA list: references/apa-references.md -->

# Evidence tiers and the voice pipeline

## Why tiers exist

Every voice-derived metric is mediated by machinery: ASR (ears) → NLU
(understanding) → pronunciation scoring (GOP) → TTS (voice) → xAPI → LRS. A
score is only as trustworthy as the weakest machine that produced it, so every
claim carries a tier (registry: `evidence-tier/*`), and reports never state
more precision than the engine possesses. This is the module's honesty rule —
at product scale, where the evidence base is expert evaluation and UX testing
signal rather than cohort data, say so plainly.

## The three tiers

1. **Tier 1 — measurable today.** Task gates (`completed`), retries, rubric
   bands via live AI judgment against the descriptor, help requests,
   completion/progression events. No special instrumentation needed.
2. **Tier 2 — measurable with instrumentation.** Turn-taking latency
   (cognitive-load proxy), ASR-confidence-weighted scores, endpointing events,
   and per-phoneme scores obtained from a **vendor pronunciation-assessment
   API** running over the project's IPA-coded inventory (product example:
   Azure AI Speech Pronunciation Assessment — phoneme-level scores, IPA
   support, prosody).
3. **Tier 3 — pending the GOP build.** Bespoke per-phoneme phonological
   control scoring from a custom-built engine (the PhD's open research piece).
   Specify the metric now, reserve its dashboard slot and IRI, activate when
   engineering delivers.

Tier assignment is per-deployment: the same metric is tier 2 in an app with a
vendor scorer and tier 3 in one without. Record the assignment in D1.

## GOP solved in two halves

**Half 1 — linguistic data (the architect's half, solved by IPA).** The
project pack's IPA-coded target sound inventory: broad (phonemic)
transcription only; target features per level; **accepted variants** so
legitimate variation never lowers a score (a *seseo* speaker must never score
below a *distinción* speaker — intelligibility-first, not native-accent).
Suprasegmentals are separate lines anchored to *Prosodic features*.

**Half 2 — acoustic engineering (delegated).** Four jobs, specified as
requirements: (1) **forced alignment** — locate each sound segment in the
learner's audio against the expected IPA sequence; (2) **acoustic scoring** —
per-segment likelihood vs. a reference model (canonical method: Witt & Young,
2000); (3) **segment & variation delivery** — return the segments and the
variant actually produced; **the pedagogical layer, not the engine, decides
acceptability** against the inventory; (4) **prosody measurement** — reported
separately.

With half 1 in place the spec is vendor-neutral: plug in an off-the-shelf
scorer today (tier 2), swap in the bespoke GOP engine later (research goal)
without changing a single metric definition or IRI.

## Confidence handling rules

- Every scored voice statement carries `ext/asr-confidence`.
- Below the scoring threshold (set in D1; default 0.70): **do not score** —
  emit `incident/low-asr-confidence`, exclude the session from proficiency
  aggregates, and surface it in the teacher report's validity flags.
- Endpointing cut-offs and text-fallback activations are incidents *and*
  accessibility signals — they appear in the admin incident report and shape
  support adaptation, but never lower a learner's score.
