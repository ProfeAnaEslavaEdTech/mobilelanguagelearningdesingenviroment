<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. profeanaeslava · profeanaeslavaedtech · UPV. Part of a PhD proposal. xAPI © ADL/IEEE; SCORM © ADL. Full APA list: references/apa-references.md -->

# xAPI & SCORM specification guide

Single source of truth for identifiers: `assets/mllde-xapi-iri-registry.json`
(canonical base `https://w3id.org/mllde`; fallback
`https://profeanaeslava.com/xapi`). **Never mint an IRI ad hoc** — if a client
needs a new concept, propose a registry addition explicitly for AE's approval.

## Statement anatomy (MLLDE pattern)

Every statement: actor (learner or teaching agent) · verb (registry) · object
(activity with registry activity type) · result · context. Context always
carries: `ext/cefr-level`, `ext/cefr-skill`, `ext/cefr-scale`,
`ext/persona-pack`, `ext/evidence-tier`. Mediation adds `ext/output-channel`.

### Sample — speaking task completed (performance stream)

```json
{
  "actor": { "account": { "homePage": "https://client-app.example", "name": "learner-8842" } },
  "verb": { "id": "https://adlnet.gov/expapi/verbs/completed" },
  "object": {
    "id": "https://client-app.example/missions/cafe-order",
    "definition": { "type": "https://w3id.org/mllde/activity-type/mission" }
  },
  "result": {
    "success": true,
    "extensions": {
      "https://w3id.org/mllde/ext/rubric-scores": {
        "https://w3id.org/mllde/rubric/grammar-accuracy": 2,
        "https://w3id.org/mllde/rubric/vocabulary-range": 3,
        "https://w3id.org/mllde/rubric/pronunciation-phonological-control": 2,
        "https://w3id.org/mllde/rubric/intelligibility": 3,
        "https://w3id.org/mllde/rubric/interaction": 2
      },
      "https://w3id.org/mllde/ext/retries": 1
    }
  },
  "context": {
    "extensions": {
      "https://w3id.org/mllde/ext/cefr-level": "https://w3id.org/mllde/cefr/level/a2",
      "https://w3id.org/mllde/ext/cefr-skill": "https://w3id.org/mllde/cefr/skill/speaking",
      "https://w3id.org/mllde/ext/cefr-scale": "https://w3id.org/mllde/cefr/scale/obtaining-goods-services",
      "https://w3id.org/mllde/ext/persona-pack": "barcelona-a2",
      "https://w3id.org/mllde/ext/evidence-tier": "https://w3id.org/mllde/evidence-tier/1-measurable-today"
    }
  }
}
```

### Sample — pedagogical-action statement (pedagogy stream)

Actor = the teaching agent; verb = `mllde/verb/adapted` (or the performance
verb with `ext/pedagogical-action` in context for turn-level actions such as
`action/implicit-recast`). Always record strategy **and** outcome — this stream
is what lets a human or AI teacher see which interventions were already tried.

### Pronunciation statements

Verb `mllde/verb/pronounced`; result `ext/phoneme-scores`:
`[{ "ipa": "r", "score": 74, "confidence": 0.91, "acceptedVariants": ["ɾ"] }]`
plus `ext/asr-confidence`. Low ASR confidence → do not score; emit an incident
statement instead (below). Prosody is reported against
`cefr/scale/prosodic-features`, never merged into phoneme scores.

### Incident statements (independent family)

Object = the system component; context `ext/incident-type` (registry),
`ext/incident-severity`; later, `ext/incident-resolution` records
{change made, date, post-change rate} — the resolution ledger consumed by the
admin report.

## The dual stream, summarised

1. **Performance stream** — CEFR-anchored learner evidence.
2. **Pedagogy stream** — what the teaching side did (recast, scaffold,
   simplify, advance) and what happened next.
Statements in both streams about the same turn share a context `registration`
(session id) so reports can join them.

## SCORM mapping (compatibility layer — state the limits plainly)

| MLLDE concept | SCORM 1.2 | SCORM 2004 |
| --- | --- | --- |
| Task gate | `cmi.core.lesson_status` passed/failed | `cmi.completion_status` + `cmi.success_status` |
| Overall score | `cmi.core.score.raw` | `cmi.score.scaled` |
| Rubric bands (summary only) | `cmi.suspend_data` (opaque) | `cmi.objectives.n.*` (one objective per category) |

**SCORM cannot carry:** subskill granularity, turn-level voice detail, phoneme
scores, the pedagogy stream, incident telemetry. Any SCORM-only deployment
loses everything except the task-gate layer — say this verbatim in D3 so the
client chooses with eyes open. xAPI is primary; SCORM is fallback.

**cmi5.** When the client's LMS launches content LMS-style but an LRS is
available, use cmi5: LMS launch + defined minimum statements, with MLLDE
statements sent alongside ("cmi5 allowed" statements). One-minute intro for
stakeholders: Rustici Software's *cmi5 in 60 seconds* (see apa-references.md).

## LRS practicalities

Statements are immutable — corrections use xAPI voiding. Learner identity via
`account` (app user id), never personal email, supporting GDPR minimisation.
Recommend the client verify LRS conformance (ADL test suite) before go-live.
