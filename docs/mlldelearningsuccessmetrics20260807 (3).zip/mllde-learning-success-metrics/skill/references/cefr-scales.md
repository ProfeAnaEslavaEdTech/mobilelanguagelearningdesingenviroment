<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. profeanaeslava · profeanaeslavaedtech · UPV. Part of a PhD proposal. CEFR © Council of Europe, cited not redistributed. Full APA list: references/apa-references.md -->

# The five skills and their Companion Volume scales

The authoritative IRI for every concept below lives in
`assets/mllde-xapi-iri-registry.json` — read it when writing statements or
metric definitions; never retype an IRI from memory.

## The five MLLDE skills

| Skill | CV mode | Channel | IRI slug |
| --- | --- | --- | --- |
| Listening | reception | oral | `cefr/skill/listening` |
| Reading | reception | written | `cefr/skill/reading` |
| Speaking | production + interaction | oral | `cefr/skill/speaking` |
| Writing | production + interaction | written | `cefr/skill/writing` |
| Mediation | mediation | oral **or** written | `cefr/skill/mediation` |

**Mediation rule.** Mediation is MLLDE's fifth skill. Its output is always
realised through the oral or written channel, so every mediation metric and
statement carries two identifiers: the mediation scale IRI *and* the
output-channel skill IRI (`speaking` or `writing`). Its rubric = the
production-channel rubric + mediation-specific criteria: content fidelity,
audience adaptation, bridging strategy.

## Subskill scales per skill (Companion Volume 2020)

Levels run Pre-A1 → C2 (registry: `cefr/level/pre-a1` … `cefr/level/c2`).

**Listening:** Overall oral comprehension · Understanding conversation between
other people · Understanding as a member of a live audience · Understanding
announcements and instructions · Understanding audio media and recordings ·
Watching TV, film and video (audio-visual comprehension).

**Reading:** Overall reading comprehension · Reading correspondence · Reading
for orientation · Reading for information and argument · Reading instructions ·
Reading as a leisure activity.

**Speaking — production:** Overall oral production · Sustained monologue
(describing experience / giving information / putting a case) · Public
announcements · Addressing audiences.

**Speaking — interaction:** Overall oral interaction · Understanding an
interlocutor · Conversation · Informal discussion · Formal discussion ·
Goal-oriented co-operation · Obtaining goods and services (the classic MLLDE
service-encounter mission maps here) · Information exchange · Interviewing ·
Using telecommunications.

**Speaking — phonology (the pronunciation anchors):** Overall phonological
control · Sound articulation (per-phoneme/IPA metrics anchor here) · Prosodic
features (stress, rhythm, intonation — always separate metric lines).

**Writing:** Overall written production · Creative writing · Reports and
essays · Overall written interaction · Correspondence · Notes, messages and
forms · Online conversation and discussion · Goal-oriented online transactions
and collaboration · Orthographic control.

**Mediation:**
- *Mediating a text* — Relaying specific information · Explaining data (graphs,
  charts) · Processing text · Translating a written text · Note-taking ·
  Expressing a personal response to creative texts · Analysis and criticism of
  creative texts.
- *Mediating concepts* — Facilitating collaborative interaction with peers ·
  Collaborating to construct meaning · Managing interaction · Encouraging
  conceptual talk.
- *Mediating communication* — Facilitating pluricultural space · Acting as
  intermediary · Facilitating communication in delicate situations.

## Mapping an app's tasks to scales

For each task in the client's inventory, ask: *what does the learner actually
do with language to succeed?* Then pick the narrowest scale that matches.
Examples:

- Order food from an NPC waiter → **Obtaining goods and services** (speaking).
- Listen to a station announcement and choose the platform → **Understanding
  announcements and instructions** (listening).
- Read a hostel review and decide whether to book → **Reading for orientation**.
- Hear a voicemail in the target language and text a summary to a friend →
  **Relaying specific information** (mediation, written channel).
- Explain a metro map to a lost tourist → **Explaining data** (mediation, oral
  channel).

A task may evidence more than one scale; record a **primary** scale (the one
the pass decision is read against) and optional secondary scales. If a task
maps to no scale, either the task is not a language task or the inventory entry
is underspecified — flag it rather than forcing a mapping.
