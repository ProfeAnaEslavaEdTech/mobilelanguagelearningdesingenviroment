<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. profeanaeslava · profeanaeslavaedtech · UPV. Part of a PhD proposal. Full APA list: references/apa-references.md -->

# MLLDE Measurement Module — Project Pack

*One filled pack = one client application. The engine never changes; this file
does. Fill every field; write "NOT AVAILABLE — drafted by agent, pending
expert review" where the client cannot supply data.*

## 1. Identification
- **Client / product name:**
- **Prepared by / date:**
- **Target language(s):**
- **Learners' base language(s):**

## 2. Scope
- **CEFR levels in scope** (Pre-A1–C2):
- **Skills in scope** (listening / reading / speaking / writing / mediation):
- **Mediation present?** If yes, list mediation task types and output channel
  (oral / written) per task:

## 3. Task inventory
For each task/mission: name · description · **primary CV scale** (from
`references/cefr-scales.md`) · secondary scales · level · completion signal
(e.g. `<MISSION_COMPLETE>` token or equivalent):

| Task | Level | Primary scale | Secondary | Completion signal |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |

## 4. IPA-coded target sound inventory (required if speaking in scope)
Per level: target segments (broad IPA) · target suprasegmentals · **accepted
variants** (variation that must never lower a score) · source (client /
agent-drafted pending expert review):

| Level | Target features (IPA) | Accepted variants | Source |
| --- | --- | --- | --- |
|  |  |  |  |

## 5. Technical target
- **LMS / platform:**
- **Tracking route** (pure xAPI+LRS / cmi5 / SCORM 1.2 / SCORM 2004):
- **LRS available?** (vendor, conformance-tested?):
- **Pronunciation scoring available?** (none / vendor API — which / custom GOP):
- **Resulting evidence-tier ceiling for voice metrics** (1 / 2 / 3):

## 6. Personas
- **Independent learners** (self-directed use? game metaphor in product?):
- **Teachers** — human, AI agent, or both; cadence of adaptation reports:
- **LMS administrators** — reporting line to HR? business measure for ROI
  (the client names it): · ESCO alignment wanted? (y/n)

## 7. Evidence base today
What evidence currently exists (expert evaluation, UX testing, pilot data,
cohort data)? This sets the honesty line for every report:

## 8. Constraints & notes
Privacy/GDPR constraints, accessibility requirements, brand/immersion rules
(e.g. CEFR never named in-app), anything else that shapes measurement:
