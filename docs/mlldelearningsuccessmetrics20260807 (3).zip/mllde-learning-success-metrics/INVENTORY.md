<!--
  © 2026 Ana Eslava-Graterol. All Rights Reserved.
  Brand & website: profeanaeslava · GitHub: profeanaeslavaedtech · Universitat Politècnica de València.
  Part of the PhD proposal (MLLDE Measurement Module). Full APA 7th reference list:
  skill/references/apa-references.md (standing documentation rule applies).
-->

# INVENTORY — Consolidated repository · Inventario del repositorio consolidado

**Date · Fecha:** 2026-08-07 · **Prepared with:** Claude (Cowork session, AE supervising)
**Method · Método:** every candidate file was compared byte-for-byte (MD5); the canonical
version of each document was selected by version number, internal changelog and file date.

---

## 1. Sources compared · Fuentes comparadas

| Source | Verdict |
| --- | --- |
| `mlldelearningsuccessmetrics.zip` (umbrella engine, 2026-08-04 17:0x) | **CANONICAL** for root: README, CLAUDE, concept v3.3, glossary v1.0, registry v0.3.0, skill/ |
| `cefrlearningmetricsarchitectdraft.zip` (2026-08-04 14:0x) | **Obsolete entire** — registry v0.2.0-draft; everything else identical to umbrella |
| `docsvoiceformllderepo.zip` = `…_5.zip` (2026-08-02 15:1x) | Superseded (original edition, 17 files) |
| `…_1.zip` (adds explained.es) · `…_2.zip` (adds master 02-Aug, tool, knowledge ×2) | Superseded |
| **`…_4.zip` (2026-08-04 20:28–20:42, 52 files)** | **CANONICAL** for `docs/voice/` — superset: master 04-Aug, alignment reports ×2, Valencia, grace-gpt-upload, new-city-kit, chatgpt-knowledge ×3, tool, assets |
| Loose uploads (2026-08-07) | All byte-identical to one of the above; the two loose masters were the **old 02-Aug edition** (discarded) |

## 2. Canonical versions locked in · Versiones canónicas fijadas

| Document | Version kept | Discarded |
| --- | --- | --- |
| `registry/mllde-xapi-iri-registry.json` | **v0.3.0** (125 IRIs, changelog, 4 TK Coach incident types) | v0.2.0-draft (121 IRIs) |
| `glossary/mllde-glossary.md` | **v1.0** with the cmi5/Rustici video note + APA entry | copy lacking that note |
| `concept/…concept.md` | **v3.3** (single version found) | — |
| `docs/voice/Architecture-Voice-Design-MLLDE.master.md` | **04-Aug edition, 12 246 B** — declares the Measurement Module as second cross-layer module; points to the IPA inventories | 02-Aug edition, 11 116 B |
| `docs/voice/README.md` | **04-Aug edition** ("Voice — Architecture Voice Design for MLLDE", full folder map) | 02-Aug editions |
| `docs/voice/cities/seville.md` | 02-Aug 17:40 revision (5 567 B) | first draft (5 036 B) |
| `skill/` (SKILL.md, 7 references, project-pack template) | Single version across all sources — no conflict | — |

## 3. Structural decision · Decisión estructural

The Measurement Module is kept **once, at the repository root** (`concept/`,
`glossary/`, `registry/`, `skill/`), per the project's single-source-of-truth
governance. `docs/voice/measurement-module/README.md` is a pointer explaining how to
restore the embedded copy if `docs/voice/` ships standalone. The registry also
remains in `skill/assets/` (v0.3.0, identical) because the skill requires its own
asset copy — keep both in sync on every version bump.

## 4. New in this consolidation · Nuevo en esta consolidación

- `INVENTORY.md` (this file) — provenance record of the consolidation.
- `docs/voice/Voicemode-xAPI-justification.md` (2026-08-07) — formal justification of
  how MLLDE's voice mode is grounded in the xAPI language layer (PhD record).
- `docs/voice/measurement-module/README.md` — pointer to the module's canonical
  root location (replaces the embedded duplicate).

## 5. Known gaps · Huecos conocidos

- `LICENSE` and `NOTICE` are referenced by several file headers but were not among
  the uploads — add them at the repo root.
- Registry **v0.4 candidates remain PENDING AE approval** (six: grammar-drill,
  chunk-in-context, chunk-reuse convention, card-pack, card-pack-label,
  srs-schedule) — do not mint (see README.md · CLAUDE.md rule 2).
- `docs/gpt-records/` (the four GPT instance records cited by the master §5) was not
  uploaded and is not included.
