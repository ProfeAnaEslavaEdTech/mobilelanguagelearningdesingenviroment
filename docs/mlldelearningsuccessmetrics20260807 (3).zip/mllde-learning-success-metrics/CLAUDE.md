# CLAUDE.md — standing rules for this repository

You are working on the **MLLDE Measurement Module** (engine repo), © 2026 Ana
Eslava-Graterol (AE). When acting on measurement tasks, adopt the role defined in
`skill/cefr-learning-metrics-architect/SKILL.md` and follow its workflow and reference
files.

Non-negotiable rules (AE's standing decisions):

1. **Copyright + references in every artifact.** Every file produced here carries the
   copyright block and the full APA 7th reference list from
   `skill/cefr-learning-metrics-architect/references/apa-references.md`, plus source
   attribution for external claims. No artifact ships without them.
2. **IRIs come from `registry/mllde-xapi-iri-registry.json` only.** Never invent an
   identifier. New concepts are *proposed* to AE as a registry version bump and minted
   only after her explicit approval. Current pending set: the v0.4 candidates listed in
   README.md.
3. **No metric without a descriptor.** Every metric traces to a named CEFR Companion
   Volume scale IRI. Mediation is the fifth skill; its statements carry both the
   mediation scale IRI and the output-channel skill IRI (speaking or writing).
4. **Evidence honesty.** Every voice-derived claim carries an evidence tier (1 today ·
   2 instrumented · 3 pending GOP). Reports never claim more precision than the engine
   has. Below ASR confidence 0.70: flag as incident, do not score.
5. **Engine vs pack.** Nothing client-specific enters this repo. Client work fills a
   project pack (template in `skill/.../assets/project-pack-template.md`) in the
   client's own repo (e.g. tkcoach-first-application).
6. **Language.** Work and write in English, Companion Volume terminology. Learner-facing
   text never names the CEFR (dual-ledger rule).
7. **Say "adapt", not "train".** Learner data adapts the agent's per-learner strategy;
   do not describe it as training a model.

Contact / owner: Ana Eslava-Graterol — Learning Experience Designer | Language
Curriculum Developer · profeanaeslava@gmail.com · GitHub profeanaeslavaedtech.
