<!--
  Structural analysis of MLLDE and its use in Language Passport (Spanish).
  Analytical commentary by Claude for Ana Eslava-Graterol. Not a redistribution of
  the source docs; quotes are short and attributed. No app code.
-->

# MLLDE — Structural Analysis & Its Use in One App (Language Passport, Spanish)

*Analysis of five sources: MLLDE Curriculum Master, Theoretical Framework, the
Language Passport Lesson Builder (Destination Schema), and the Grace GPT Design
page. The `.docx` is the master's Word twin (same content per its own header).*

---

## 1. What the framework is — one method, four layers

MLLDE (**Mobile Language Learning Design Environment**) is not the app and not the
standard; it is a **method** positioned in a four-layer stack:

| Layer | Instance here | Answers |
| --- | --- | --- |
| **Standard** | CEFR (Council of Europe) | *what* to learn, *how far* (A1→C2 can-do) |
| **Method** | **MLLDE** | *how* to turn any target into a lesson |
| **Data** | Per-language content (**PCIC** for Spanish) | *which* words/grammar/functions/culture |
| **Product** | **Language Passport** | the first thing built with the method |

**Structural thesis (the load-bearing idea):** *CEFR is the destination, the
language data is the cargo, MLLDE is the reusable vehicle.* Everything else in the
design follows from this separation.

## 2. The core structural move — engine + data (separation of concerns)

The single most important architectural decision: **the lesson cycle is a shared
engine; a lesson is a data object (the "Destination Schema").** Building a new
lesson — or a whole new language — is *filling in data, not rewriting logic*.

This is textbook separation of concerns, and it is what makes the whole system
replicable. It shows up identically at three levels:

- **Curriculum level:** method (constant) vs. per-language content (variable).
- **App level:** the Lesson Builder is one fixed form; each city is a saved JSON.
- **AI level (my Grace work):** the engine files (identity, Voicemode, references,
  CEFR grid) are constant; `cities/<city>.md` are the data. **My per-city design is
  the same engine/data split, one level down.**

> **Consistency check:** the framework *claims* language-agnosticism and *implements*
> it structurally (engine/data). That alignment between stated principle and
> realised structure is the design's biggest strength.

## 3. The competence core (the ruler every lesson is measured by)

Borrowed wholesale from CEFR: **4 modes × 3 competences.**

- **Modes:** Reception · Production · Interaction · **Mediation**.
- **Competences:** Linguistic (grammar/vocab) · Sociolinguistic (register/culture)
  · Pragmatic (function/coherence).
- **Level rule:** Reception/Production/Interaction from **A1**; **Mediation from
  B2** only. *(A structural choice — CEFR allows simpler mediation earlier; MLLDE
  deliberately treats the mediation mode as upper-level.)*

Every lesson plan must state, **per mode**, which competences it builds and at
which level. This turns a fuzzy "make a lesson" into a **specifiable matrix** — the
backbone that keeps instances comparable.

## 4. The content layer for Spanish — the Plan curricular (PCIC)

MLLDE anchors the *method* to CEFR (universal) and the *content* to each language's
official CEFR-aligned reference. **For Spanish that is the Plan curricular del
Instituto Cervantes (PCIC).** Structurally, PCIC inventories are wired to
competences:

| PCIC inventory | Feeds competence | Status in the project |
| --- | --- | --- |
| Gramática (Glosario + Inventarios) | Linguistic | **held** |
| Funciones (Inventarios) | Pragmatic → Interaction | **held** |
| Nociones | Linguistic (vocabulary) | *to add* |
| Saberes/comportamientos + Referentes culturales | Sociolinguistic | *to add* |
| Tácticas y estrategias pragmáticas + Géneros discursivos | Pragmatic/discourse | *to add* |
| **Pronunciación y Ortografía** | Linguistic | ***to add*** |

**Structural gap worth flagging:** *Pronunciación* is the least-sourced inventory
— yet the new voice layer (pronunciation coaching, the 🎙️ button) depends on it.
The engine for pronunciation exists; its **Spanish data does not yet**. (See §9.)

## 5. The lesson pipeline (IPO) and the framework synthesis

The engine is an **IPO cycle** (Input → Processing → Output) staged with ESA and
wrapped in G-CLIL gamification. Each step maps to a mode, a competence, and the
framework(s) that "fire" there:

| Step | Mode | Competence | Fires |
| --- | --- | --- | --- |
| Arrival / hook | — | scenario | ESA Engage; CTL |
| Vocabulary (animated) | Reception | Linguistic | Mayer dual-coding; Lewis; IPO Input |
| Chunks | Reception/Production | Ling.+Prag. | Lewis; Kasper & Rose |
| Model dialogue | Reception | Ling.+Socioling. | IPO Input; CLIL Communication |
| Gap-fill / drag-match | Processing | Linguistic | IPO Processing; ESA Study→Activate |
| **Mission (NPC)** | **Interaction** | Prag.+Socioling. | CTL/REACT authentic task; IPO Output; G-CLIL |
| **Immediate Assessment "Don't give up!"** | **Production** | all three | IPO Output; REACT Transferring; formative assessment |
| Culture & pragmatics cards | — | Sociolinguistic | CLIL Culture; Kasper & Rose |
| Rewards | — | motivation | G-CLIL gamification ring |

**Cross-cutting (shape every step):** SAM (build process), Mobile Learning Design
(delivery), CEFR (targets), PCIC (Spanish content). The originality is explicitly
claimed as **the synthesis**, with each framework attributed to its author — a
clean IP posture.

## 6. The Destination Schema in practice — the Lesson Builder

The Lesson Builder HTML is the **concrete realisation of engine+data**: one fixed
12-section worksheet, each city saved as JSON. Its structure *is* the schema:

1. Lesson basics (title, scenario, city/country/flag, CEFR level, target language,
   **BCP-47 speech code `es-ES`** for TTS/ASR, length 5/10/15)
2. Learning objective (active verb + benefit + "excellent achievement")
3. CLIL 4Cs · 4. Narrative & identity (Hitchhiker→Ambassador; mentor) ·
5. Vocabulary (image + animation) · 6. Chunks (+ pragmatic function) ·
7. Model dialogue · 8. Processing drills (gap-fill + drag-match) ·
9. **NPC mission — with two tiers:** *Free* = offline branching script; *Pro* = the
   **AI system prompt** (Grace) · 10. Reflection (🎙️ oral / ✍️ written + rubric) ·
11. Culture & pragmatics cards · 12. Rewards & economy.

Two structural observations:
- **The Free/Pro split is where the AI attaches.** The Pro `m_proPrompt` field *is*
  Grace's per-city system prompt — i.e. the app already anticipates a per-city AI
  module. My `cities/<city>.md` design is the same idea, externalised and reusable.
- **Length drives quantity, not structure.** 5/10/15-min presets change how many
  vocab/chunks/cards, never the pipeline. Good — it keeps instances comparable.

## 7. The AI layer — Grace

Grace is a **Custom GPT on ChatGPT** (external to the PWA), documented by the GPT
Design page and instantiated per city via the builder's `m_proPrompt`. Role:
game-master + mentor + in-scene NPC. In MLLDE's three-layer engine language she is
the **Game Engine (behaviour)** layer; the world/economy is Game Design; the
curriculum/theory is the Knowledge Base.

**Single-source-of-truth risk:** Grace's system prompt currently exists in at least
three places — the GPT Design page, the builder's Barcelona/Sevilla `m_proPrompt`,
and the standalone `gracegptdesign.md`. They agree today, but three copies drift.
The modular engine files (one Voicemode, one identity) are the fix.

## 8. The two Spanish instances — same engine, different data

Both built destinations are **CEFR A1–A2, Spanish**, and structurally identical:

| | Barcelona — *De Tapas Por La Rambla* | Sevilla — *De Bares por Santa Cruz* |
| --- | --- | --- |
| Mission | order ≥2 tapas + ≥2 drinks politely | order ≥2 tapas + ≥2 drinks politely |
| CEFR scale | *Obtaining goods and services* | same + recommendation/preference |
| Funciones (PCIC) | pedir objetos/favor, ofrecer, info, gustos | + pedir recomendación, preguntar/expresar preferencia |
| Sociolinguistic | *nos pone…* vs *quiero* | *una caña* (local usage) |
| Vocabulary | patatas bravas, tortilla, cervecilla… | salmorejo, pescaíto frito, caña, tinto de verano… |

This is the framework's proof-of-concept: **the mission engine is byte-identical;
only the data object changes.** Sevilla's only *structural* addition is two extra
pragmatic functions (recommendation + preference). Well-controlled — though it also
flags a **content-variety risk**: two consecutive "order food politely" missions.
As levels scale, the schema should vary the *scenario type* (directions,
transactions, narration), not just the menu.

> **Note for my own deliverables:** the real Sevilla lesson is **"De Bares por
> Santa Cruz" (tapas)** — my earlier `cities/seville.md` draft used a café-breakfast
> placeholder. It should be replaced with this actual content. (I now have it.)

## 9. Mandatory standard — Immediate Assessment ("Don't give up!")

Every city must implement, at the output step, a non-negotiable component:
1. **Two output modes** — 🎙️ Speak / ✍️ Write (REACT transfer).
2. **Instant, specific check** vs. lesson data (vocab incl. wrong-language, spelling
   near-miss, known grammar confusions, required auxiliaries, min-length gate).
3. **Non-punitive feedback** — warm **amber + 🤔, never red**; specific; bilingual.
4. **Retry, always** — unlimited, celebrated.
5. **Mandatory escalation** — a "🌊 Pregúntale a Grace" button hands the sentence +
   error to Grace.
6. **Encouraging label** — "Don't give up!", never "fail".

Structurally this is *assessment as learning* baked into the engine, so every new
city inherits it. **This is exactly the socket the voice layer plugs into:** the
🎙️ Speak mode = my Voicemode "Pronunciation / Conversation" entry points; the
"Pregúntale a Grace" escalation = Grace TOP.

## 10. How the voice design maps onto MLLDE (fit check)

| MLLDE element | Voice-design counterpart (my modular set) |
| --- | --- |
| Method / Game Engine (behaviour) | `01-identity-behaviour`, `Voicemode` (constant) |
| Standard (CEFR) | `CEFR-self-assessment` grids; evaluation "under CEFR" |
| Data / Destination Schema | `cities/<city>.md` (per-city) |
| Immediate Assessment 🎙️ Speak | Voicemode entry **🗣️ Practicar mediante conversaciones** |
| (new) pronunciation focus | Voicemode entry **🎙️ Mejorar mi pronunciación** |
| Escalation → Grace | Grace TOP custom GPT |

**The voice layer is consistent with MLLDE** and extends it in one place: it makes
**pronunciation a first-class assessed channel**, which the framework names as a
competence but has **not yet sourced from PCIC (§4)**. That is the one real
dependency to close.

## 11. Structural verdict

**Strengths**
- Clean, genuinely-implemented **engine/data separation** at three levels.
- **Standard-anchored** (CEFR) → international comparability by construction.
- **Language-agnostic method + language-specific data** (PCIC) — a real, working
  abstraction, not a slogan.
- **Framework synthesis is explicit and attributed** — strong IP posture; the
  synthesis is the ownable contribution.
- **Mandatory components** (Mission + Immediate Assessment) enforce a quality floor
  every instance inherits.

**Structural risks / open edges**
1. **Pronunciation data gap** — the voice layer needs PCIC *Pronunciación y
   Ortografía*, which is "to add". Engine ready, data missing.
2. **Scenario monoculture at A1–A2** — Barcelona and Sevilla are the same mission;
   vary scenario *type* as the map grows.
3. **System-prompt duplication** — Grace's prompt lives in ≥3 files; converge on
   the single modular engine to prevent drift.
4. **Mediation deferred to B2** — coherent, but means the mode is untested until
   upper levels exist; worth a small B2 pilot to validate the schema there.
5. **Missing sociolinguistic/notional inventories** — three PCIC inventories still
   to add; culture cards currently hand-authored rather than inventory-driven.

**One-line verdict:** *MLLDE is a well-formed engine-plus-data method whose stated
language-agnosticism is actually realised in structure; the app proves it with two
interchangeable Spanish instances. The next structural work is data, not design —
finish the PCIC inventories (pronunciation first) and converge the duplicated AI
prompt into the single modular engine.*
