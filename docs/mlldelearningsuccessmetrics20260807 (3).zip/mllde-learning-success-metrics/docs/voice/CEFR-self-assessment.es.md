<!--
  Documento de referencia esencial — Diseño del GPT Grace (edición modular).
  Fuente: Consejo de Europa / Europass — Marco Común Europeo de Referencia para
  las lenguas (MCER), cuadro de autoevaluación. © Consejo de Europa.
  https://europass.europa.eu/en/common-european-framework-reference-language-skills
  Descriptores oficiales del MCER. PDF original en assets/CEFR-self-assessment.europass.pdf
  Edición en inglés: CEFR-self-assessment.en.md
-->

# MCER — Cuadro de autoevaluación (español) · *referencia esencial de evaluación*

> **Uso.** Es la **referencia canónica de evaluación para `Voicemode` y cualquier
> nivel, en cualquier idioma meta.** Los descriptores *saber-hacer* del MCER son
> neutrales respecto a la lengua: describen lo que el estudiante **es capaz de
> hacer**, no un idioma concreto, así que el mismo cuadro evalúa español, inglés,
> francés, etc. Grace evalúa **bajo estas directrices**, frente al descriptor del
> nivel del destino — pero nunca nombra el MCER al estudiante (inmersión; véase
> `01-identity-behaviour`).
>
> Seis niveles: **A1 · A2** (Usuario básico) — **B1 · B2** (Usuario independiente)
> — **C1 · C2** (Usuario competente). Fuente: Consejo de Europa / Europass (véase
> cabecera).

---

## COMPRENDER

### Comprensión auditiva
- **A1** — Reconozco palabras y expresiones muy básicas que se usan habitualmente, relativas a mí mismo, a mi familia y a mi entorno inmediato cuando se habla despacio y con claridad.
- **A2** — Comprendo frases y el vocabulario más habitual sobre temas de interés personal (información personal y familiar muy básica, compras, lugar de residencia, empleo). Soy capaz de captar la idea principal de avisos y mensajes breves, claros y sencillos.
- **B1** — Comprendo las ideas principales cuando el discurso es claro y normal y se tratan asuntos cotidianos que tienen lugar en el trabajo, en la escuela, durante el tiempo de ocio, etc. Comprendo la idea principal de muchos programas de radio o televisión que tratan temas actuales o asuntos de interés personal o profesional, cuando la articulación es relativamente lenta y clara.
- **B2** — Comprendo discursos y conferencias extensos e incluso sigo líneas argumentales complejas siempre que el tema sea relativamente conocido. Comprendo casi todas las noticias de la televisión y los programas sobre temas actuales. Comprendo la mayoría de las películas en las que se habla en un nivel de lengua estándar.
- **C1** — Comprendo discursos extensos incluso cuando no están estructurados con claridad y cuando las relaciones están sólo implícitas y no se señalan explícitamente. Comprendo sin mucho esfuerzo los programas de televisión y las películas.
- **C2** — No tengo ninguna dificultad para comprender cualquier tipo de lengua hablada, tanto en conversaciones en vivo como en discursos retransmitidos, aunque se produzcan a una velocidad de hablante nativo, siempre que tenga tiempo para familiarizarme con el acento.

### Comprensión de lectura
- **A1** — Comprendo palabras y nombres conocidos y frases muy sencillas, por ejemplo las que hay en letreros, carteles y catálogos.
- **A2** — Soy capaz de leer textos muy breves y sencillos. Sé encontrar información específica y predecible en escritos sencillos y cotidianos como anuncios publicitarios, prospectos, menús y horarios y comprendo cartas personales breves y sencillas.
- **B1** — Comprendo textos redactados en una lengua de uso habitual y cotidiano o relacionada con el trabajo. Comprendo la descripción de acontecimientos, sentimientos y deseos en cartas personales.
- **B2** — Soy capaz de leer artículos e informes relativos a problemas contemporáneos en los que los autores adoptan posturas o puntos de vista concretos. Comprendo la prosa literaria contemporánea.
- **C1** — Comprendo textos largos y complejos de carácter literario o basados en hechos, apreciando distinciones de estilo. Comprendo artículos especializados e instrucciones técnicas largas, aunque no se relacionen con mi especialidad.
- **C2** — Soy capaz de leer con facilidad prácticamente todas las formas de lengua escrita, incluyendo textos abstractos estructural o lingüísticamente complejos como, por ejemplo, manuales, artículos especializados y obras literarias.

## HABLAR

### Interacción oral
- **A1** — Puedo participar en una conversación de forma sencilla siempre que la otra persona esté dispuesta a repetir lo que ha dicho o a decirlo con otras palabras y a una velocidad más lenta y me ayude a formular lo que intento decir. Planteo y contesto preguntas sencillas sobre temas de necesidad inmediata o asuntos muy habituales.
- **A2** — Puedo comunicarme en tareas sencillas y habituales que requieren un intercambio simple y directo de información sobre actividades y asuntos cotidianos. Soy capaz de realizar intercambios sociales muy breves, aunque, por lo general, no puedo comprender lo suficiente como para mantener la conversación por mí mismo.
- **B1** — Sé desenvolverme en casi todas las situaciones que se me presentan cuando viajo donde se habla esa lengua. Puedo participar espontáneamente en una conversación que trate temas cotidianos de interés personal o que sean pertinentes para la vida diaria (por ejemplo, familia, aficiones, trabajo, viajes y acontecimientos actuales).
- **B2** — Puedo participar en una conversación con cierta fluidez y espontaneidad, lo que posibilita la comunicación normal con hablantes nativos. Puedo tomar parte activa en debates desarrollados en situaciones cotidianas explicando y defendiendo mis puntos de vista.
- **C1** — Me expreso con fluidez y espontaneidad sin tener que buscar de forma muy evidente las expresiones adecuadas. Utilizo el lenguaje con flexibilidad y eficacia para fines sociales y profesionales. Formulo ideas y opiniones con precisión y relaciono mis intervenciones hábilmente con las de otros hablantes.
- **C2** — Tomo parte sin esfuerzo en cualquier conversación o debate y conozco bien modismos, frases hechas y expresiones coloquiales. Me expreso con fluidez y transmito matices sutiles de sentido con precisión. Si tengo un problema, sorteo la dificultad con tanta discreción que los demás apenas se dan cuenta.

### Expresión oral
- **A1** — Utilizo expresiones y frases sencillas para describir el lugar donde vivo y las personas que conozco.
- **A2** — Utilizo una serie de expresiones y frases para describir con términos sencillos a mi familia y otras personas, mis condiciones de vida, mi origen educativo y mi trabajo actual o el último que tuve.
- **B1** — Sé enlazar frases de forma sencilla con el fin de describir experiencias y hechos, mis sueños, esperanzas y ambiciones. Puedo explicar y justificar brevemente mis opiniones y proyectos. Sé narrar una historia o relato, la trama de un libro o película y puedo describir mis reacciones.
- **B2** — Presento descripciones claras y detalladas de una amplia serie de temas relacionados con mi especialidad. Sé explicar un punto de vista sobre un tema exponiendo las ventajas y los inconvenientes de varias opciones.
- **C1** — Presento descripciones claras y detalladas sobre temas complejos que incluyen otros temas, desarrollando ideas concretas y terminando con una conclusión apropiada.
- **C2** — Presento descripciones o argumentos de forma clara y fluida y con un estilo que es adecuado al contexto y con una estructura lógica y eficaz que ayuda al oyente a fijarse en las ideas importantes y a recordarlas.

## ESCRIBIR

### Expresión escrita
- **A1** — Soy capaz de escribir postales cortas y sencillas, por ejemplo para enviar felicitaciones. Sé rellenar formularios con datos personales, por ejemplo mi nombre, mi nacionalidad y mi dirección en el formulario del registro de un hotel.
- **A2** — Soy capaz de escribir notas y mensajes breves y sencillos relativos a mis necesidades inmediatas. Puedo escribir cartas personales muy sencillas, por ejemplo agradeciendo algo a alguien.
- **B1** — Soy capaz de escribir textos sencillos y bien enlazados sobre temas que me son conocidos o de interés personal. Puedo escribir cartas personales que describen experiencias e impresiones.
- **B2** — Soy capaz de escribir textos claros y detallados sobre una amplia serie de temas relacionados con mis intereses. Puedo escribir redacciones o informes transmitiendo información o proponiendo motivos que apoyen o refuten un punto de vista concreto. Sé escribir cartas que destacan la importancia que le doy a determinados hechos y experiencias.
- **C1** — Soy capaz de expresarme en textos claros y bien estructurados exponiendo puntos de vista con cierta extensión. Puedo escribir sobre temas complejos en cartas, redacciones o informes resaltando lo que considero que son aspectos importantes. Selecciono el estilo apropiado para los lectores a los que van dirigidos mis escritos.
- **C2** — Soy capaz de escribir textos claros y fluidos en un estilo apropiado. Puedo escribir cartas, informes o artículos complejos que presentan argumentos con una estructura lógica y eficaz que ayuda al lector a fijarse en las ideas importantes y a recordarlas. Escribo resúmenes y reseñas de obras profesionales o literarias.

---

### Cómo `Voicemode` se mapea a este cuadro

El modo voz evalúa solo las competencias **orales** — **Comprensión auditiva** e
**Interacción / Expresión oral**. Las cinco categorías de la rúbrica de
`Voicemode` §5 se leen frente al descriptor del nivel del destino:

| Rúbrica de Voicemode | Área del cuadro MCER |
| --- | --- |
| Interacción | Interacción oral (descriptor del nivel) |
| Gramática · Vocabulario · Pronunciación · Inteligibilidad | Expresión oral + Comprensión auditiva (descriptor del nivel) |

Las filas de *Comprensión de lectura* y *Expresión escrita* son la referencia
para el modo texto / futuras tareas escritas.
