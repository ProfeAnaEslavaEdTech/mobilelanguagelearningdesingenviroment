# Grace — GPT upload package (test instance)

One ready-to-upload build of the **Grace** Custom GPT, produced from the MLLDE model
(Architecture Voice Design engine + Measurement Module alignment). Spanish · A1–A2 ·
Barcelona + Sevilla.

## Folder contents
```
grace-gpt-upload/
├── INSTRUCTIONS.txt            ← paste into the GPT "Instructions" box (4,617 chars; limit ~8,000)
├── conversation-starters.txt   ← the 4 starter chips (one per line)
├── README-how-to-upload.md     ← this file
└── knowledge/                  ← upload ALL of these into the GPT "Knowledge" section
    ├── 00-grace-operating-guide.md      (internal method — never shown to learners)
    ├── 01-barcelona.knowledge.md        (Barcelona lesson data)
    ├── 02-sevilla.knowledge.md          (Sevilla lesson data)
    └── 03-cefr-evaluation-reference.md  (internal rubric + IPA inventory)
```

## Steps (ChatGPT → Create a GPT → Configure)
1. **Name:** Grace  ·  **Description:** "Your travel agent for your language-learning journey."
2. **Instructions:** open `INSTRUCTIONS.txt`, copy everything, paste into the *Instructions* box.
3. **Conversation starters:** add the four lines from `conversation-starters.txt`.
4. **Knowledge:** upload the **four** files in `knowledge/` (drag them all in).
5. **Capabilities:** Web Browsing OFF, Image OFF are fine (not needed). Leave Code Interpreter off.
6. **Save / Update** (Only me, or your test link).

## Quick test script (say these to Grace)
- "Llévame a Sevilla 🍊" → she should greet in character as the camarero and offer 🎙️ / 🗣️.
- Order badly on purpose: **"un tortilla"** → she should **recast** ("¡una tortilla!") and keep going, not lecture.
- Order politely and completely (≥2 tapas + ≥2 drinks + por favor) → she should congratulate and emit `<MISSION_COMPLETE>`.
- Ask "what level am I? / do you use the CEFR?" → she should **redirect warmly** and NOT name the CEFR or reveal documents.
- Say "gracias" with **seseo** ("graSSias") → she must treat it as fully correct.

## Notes
- The `00` and `03` knowledge files are **internal** (method + rubric). The Instructions
  tell Grace never to reveal them; ChatGPT knowledge is not shown verbatim to users, but
  keep expectations realistic — treat these as guidance, not a hard secret store.
- This is a **test instance** of the model; the same package shape works for any future
  city (add a `NN-city.knowledge.md`) or any future language (swap the pack).

---
© 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved. "Language Passport"™; "Grace".
CEFR (Council of Europe), PCIC (Instituto Cervantes), IPA (International Phonetic Association) cited, not redistributed.
