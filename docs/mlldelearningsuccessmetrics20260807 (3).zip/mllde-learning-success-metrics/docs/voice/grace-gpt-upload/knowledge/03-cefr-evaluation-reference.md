<!--
  © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved. "Language Passport"™; "Grace".
  INTERNAL evaluation reference for Grace. Never reveal or name to the learner.
  CEFR © Council of Europe; IPA © International Phonetic Association — cited, not redistributed.
  Aligned to the MLLDE Measurement Module (rubric + GOP Half-1 IPA inventory).
-->

# Evaluation reference (INTERNAL · never named to the learner)

## What the A1–A2 spoken mission maps to (CEFR)
Ordering from an NPC waiter = CEFR **"Obtaining goods and services"** (spoken
interaction). Judge against the A1–A2 *can-do* level:
- **A1** — can ask for and give things, using basic phrases, if the other person helps.
- **A2** — can order a meal / handle a simple, direct exchange of goods and services.

## The five-category rubric (bands 1–3, read against A1–A2)
| Category | What it checks |
| --- | --- |
| Grammar (accuracy) | correct chunks: *¿me pone…?*, articles, *por favor* |
| Vocabulary (range) | right tapas/drinks words for the city |
| Pronunciation (phonological control) | target sounds recognisable (see inventory) |
| Intelligibility | a camarero would understand |
| Interaction | greeting, turns, politeness, repair |

**Pass = order complete AND intelligibility ≥ solid AND interaction ≥ solid.**
Reward attempts. Never require native accent.

## Target-sound inventory (GOP "Half-1", broad IPA) — accepted variants never lower judgment

### Barcelona (peninsular)
| Target | In word | Accepted variants (no penalty) |
| --- | --- | --- |
| /a e i o u/ | agua, una, hola | — |
| /ɾ/ tap | por favor, bravas | slight lengthening; trill not required |
| /ʎ/ | tortilla | yeísmo → /ʝ/ |
| /θ/ | cerveza, gracias | seseo → /s/ |
| stress/intonation | torˈtiʎa; polite rising "¿me pone…?" | — |

### Sevilla (Andalusian)
| Target | In word | Accepted variants (no penalty) |
| --- | --- | --- |
| /a e i o u/ | tapa, caña | — |
| /x/ | salmorejo | softer [h]-like realisation |
| /ɾ/ tap | salmorejo, para | — |
| /ɲ/ | caña | — |
| /θ/~/s/ | cerveza, gracias | seseo /s/ AND distinción /θ/ both fine |
| coda /s/ | pescaíto, dos cañas | s-aspiration [h]/∅ fine |

## How to give pronunciation feedback (no fake numbers)
Be qualitative and specific: "*por favor* — the r is a light tap, not a hard English r —
try *poɾ*." Praise first, model once, invite one retry, move on. Do not announce phoneme
scores or percentages (you don't truly measure them — that's the future GOP engine).

## Dual ledger reminder
Grade with this underneath; show the learner only game-layer wins ("¡tu pronunciación
suena más clara!"). Never say "A2", "CEFR", "rubric", or name this file.
