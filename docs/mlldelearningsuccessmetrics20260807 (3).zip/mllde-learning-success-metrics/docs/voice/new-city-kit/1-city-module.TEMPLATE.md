<!--
  © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved. "Language Passport"™; "Grace".
  NEW-CITY MODULE TEMPLATE (measurement-aligned). Copy to ../cities/<city>.md and fill.
  Engine files never change. IPA © International Phonetic Association; CEFR © Council of Europe — cited.
-->

# City Module — {{CITY}} · Level {{N}}  ·  *per-city content*

> The app loads one city module + an entry point (🎙️ / 🗣️). Grace's persona, voice
> rules, pronunciation method and CEFR rubric come from the shared engine. Fill every
> `{{placeholder}}`; delete guidance comments.

## 0. Metadata
| Field | Value |
| --- | --- |
| City / País | {{CITY}}, {{COUNTRY}} |
| Level # | {{N}} |
| CEFR level | {{A1 / A2 / …}} |
| DELE / PCIC level | {{DELE level + PCIC reference}} |
| Target language | {{e.g. Spanish}} |
| Base language (glosses) | {{e.g. English}} |
| Session length | {{5 / 10 / 15 min}} |
| NPC role (in scene) | {{e.g. camarero}} |

## 1. Scenario / setting
{{One or two sentences: where the learner is, who they talk to, the real situation.}}

## 2. Mission (authentic assessment)
- **Task:** {{what the learner must do out loud/in text}}
- **Success criteria:** {{measurable — e.g. "complete polite order of ≥2 X + ≥2 Y"}}
- **CEFR scale it maps to:** {{e.g. Obtaining goods and services (spoken interaction)}}

## 3. Vocabulary *(target — gloss)*  {{8–15 items, grouped by theme}}
- {{palabra}} — *{{gloss}}*

## 4. Chunks / functional exponents
- `{{chunk}}` — *{{gloss}}* *(function: {{requesting / thanking / …}})*

## 5. Grammar focus *(CEFR + DELE/PCIC for this level)*
- {{grammar point}} — *{{why the task needs it}}* — CEFR {{level}} / PCIC {{ref}}

## 6. Target-sound inventory (IPA, GOP "Half-1") — accepted variants never lower a score
| Target (broad IPA) | In word | Feature | Accepted variants (no penalty) |
| --- | --- | --- | --- |
| /{{…}}/ | {{example}} | {{e.g. tap, palatal nasal}} | {{e.g. seseo, yeísmo, s-aspiration}} |
> Prosody (stress/intonation) as separate lines. Per-phoneme scoring is **tier 3**
> until a scorer is integrated (then tier 2) — see `../Voicemode-measurement-alignment.md`.

## 7. Conversation starters — "Frases para iniciar una conversación"
- «{{frase}}» — *{{gloss}}*

## 8. Entry point 🎙️ "Mejorar mi pronunciación" → PRONUNCIATION mode
- **Drill set (say-after-me):** {{3–6 phrases from §4/§7}}
- **Priority sounds:** {{from §6}}
- **Level bar:** Pronunciation + Intelligibility vs. the CEFR {{level}} descriptor.

## 9. Entry point 🗣️ "Practicar mediante conversaciones" → CONVERSATION mode
- **Opening line (in character):** «{{Grace's first line}}»
- **Grace asks:** {{2–3 driving questions}}
- **Completion:** on meeting §2 → congratulate + `<MISSION_COMPLETE>`.

## 10. Graded hints
- **L1** encourage + point to the chunk: {{…}}
- **L2** model a partial: {{…}}
- **L3** more scaffolding: {{…}}
- **Solution** only if truly stuck and asked: {{…}}

## 11. Rewards
- Coins 🪙: {{+80 mission · +30 pronunciation · +30 reflection}}
- Stamp: {{city}} · Souvenir: {{item}} · Rank-up: {{if applicable}}

## 12. Culture / pragmatics note
{{One short, true cultural/pragmatic tip that makes the register natural here.}}

<!-- NOT here (comes from the engine): persona, voice rules, the pronunciation FEEDBACK
     METHOD, the 5-category rubric, evidence tiers, accessibility, immersion invariants,
     rewards mechanics, telemetry. Edit those once, in the engine — never per city. -->
