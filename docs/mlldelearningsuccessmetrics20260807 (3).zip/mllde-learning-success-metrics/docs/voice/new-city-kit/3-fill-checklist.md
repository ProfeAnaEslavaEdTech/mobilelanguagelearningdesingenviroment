<!--
  © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved. "Language Passport"™; "Grace".
  Completion checklist for a new city. Tick before you ship the destination.
-->

# New-City Fill Checklist

**City module (`cities/<city>.md`)**
- [ ] Metadata complete (city, level, DELE/PCIC, NPC, session length)
- [ ] Scenario + mission + success criteria written
- [ ] Mission mapped to a CEFR scale (e.g. *Obtaining goods and services*)
- [ ] 8–15 vocabulary items with glosses
- [ ] Chunks with pragmatic function
- [ ] 2–4 grammar points (CEFR + PCIC)
- [ ] IPA target-sound inventory **with accepted variants** (§6)
- [ ] Conversation starters
- [ ] Both entry points filled (🎙️ drill set · 🗣️ opening line + questions)
- [ ] Graded hints L1–L3 (+ solution)
- [ ] Rewards (coins · stamp · souvenir)
- [ ] Culture / pragmatics note

**ChatGPT knowledge (`chatgpt-knowledge/Grace-<City>.knowledge.md` + upload copy)**
- [ ] Same data copied across; "How Grace uses this file" header kept
- [ ] Evaluation + accepted-variants paragraph present
- [ ] File added to the Grace GPT's Knowledge (and numbered in `grace-gpt-upload/knowledge/`)

**Model quality gates (from the engine — verify, don't rewrite)**
- [ ] Intelligibility-first: no metric requires a native accent
- [ ] Accepted variants encoded (e.g. seseo/distinción, yeísmo, s-aspiration)
- [ ] Pass floors present (intelligibility + interaction)
- [ ] CEFR never named to the learner (dual ledger)
- [ ] No invented phoneme percentages (per-phoneme scoring is tier 3 / future)

**Register / launch**
- [ ] City added to the app map/level list
- [ ] The two buttons point at the new module
- [ ] (Optional) IRIs needed beyond the registry? → propose to AE, do not mint
