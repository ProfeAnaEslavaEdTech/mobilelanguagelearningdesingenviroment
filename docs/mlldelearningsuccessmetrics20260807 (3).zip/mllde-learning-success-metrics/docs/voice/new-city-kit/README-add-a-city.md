<!--
  © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved. "Language Passport"™; "Grace".
  New-City Kit — copy once per new destination. No coding required; fill the blanks.
  Aligned to Architecture Voice Design + the Measurement Module (IPA Half-1 inventory).
-->

# Add a City — the No-Code Kit

Adding a destination = **filling two templates**, never writing code. Copy this kit,
fill the `{{placeholders}}`, save the files into the right folders. The engine
(Grace's persona, voice rules, the CEFR rubric, telemetry) never changes.

## The 5 steps

1. **Copy** `1-city-module.TEMPLATE.md` → `../cities/<city>.md`
   *(replace `<city>` with a lowercase name, e.g. `valencia`.)*
2. **Fill** every `{{placeholder}}` in it — metadata, scenario, mission, vocabulary,
   chunks, grammar (CEFR + PCIC), the IPA target sounds, the two entry points, hints,
   rewards, culture. Guidance sits next to each field.
3. **Copy** `2-chatgpt-knowledge.TEMPLATE.md` → **both**:
   - `../chatgpt-knowledge/Grace-<City>.knowledge.md` (repo), and
   - `../grace-gpt-upload/knowledge/NN-<city>.knowledge.md` (upload package; `NN` = next number).
   Most of it is the same data you just filled — copy it across.
4. **Tick** `3-fill-checklist.md` to be sure nothing is missing (all 5 skills? IPA
   variants? floors?).
5. **Register** the city in the app map/level list and point its two buttons
   (🎙️ / 🗣️) at the new module. In the Grace GPT, just upload the new knowledge file.

## What you never touch
`01-identity-behaviour`, `Voicemode`, `references`, `CEFR-self-assessment`,
`measurement-module/`, `INSTRUCTIONS.txt`. Those are the **engine** — shared by every
city, in every language.

## Worked example already in the repo
`../cities/valencia.md` is a **third city, scaffolded** — metadata + scenario filled,
content marked `TODO` for you to complete. Use it as a live model of a half-filled kit.

---
© 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
CEFR (Council of Europe), PCIC (Instituto Cervantes), IPA (International Phonetic Association) cited, not redistributed.
