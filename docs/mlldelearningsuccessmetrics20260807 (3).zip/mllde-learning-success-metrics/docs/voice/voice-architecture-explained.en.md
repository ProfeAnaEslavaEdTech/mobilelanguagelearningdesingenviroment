<!--
  Copyright © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
  Plain-language explainer of the LLM Architecture Voice Design layer of MLLDE.
  Written for a non-engineer (language teacher / instructional designer).
  Referenced standards (CEFR, xAPI) © their owners.
-->

# Voice Architecture, Explained in Plain Language

*A companion note for the MLLDE **LLM Architecture Voice Design** layer. Written so
a language teacher — not an engineer — can read it. No code.*

---

## The one-paragraph version

A "voice track" for language learning has **three layers**. Picture a **restaurant**:
the **kitchen** (the technology the learner never sees), the **waiter + dining room**
(what the learner hears and feels), and the **nutritionist** (the teaching science
behind the menu). Your Grace / Voicemode work already lives in the *waiter* and
*nutritionist* layers. The "voice architecture" material is mostly about wiring up
the *kitchen* — and it maps almost one-to-one onto things you already do.

---

## Layer 1 — Technical Architecture ("the Engine" / the kitchen)

| Term | Plain meaning | You already… |
| --- | --- | --- |
| **ASR** (Automatic Speech Recognition) | the app's **ears** — turns speech into text | used Whisper (an ASR) to transcribe your audios |
| **NLU** (Natural Language Understanding) | the **"what did they mean?"** step — finds the *intent* ("ordering food") and *slots* (item = tortilla) | do this by hand when you design missions |
| **Pronunciation scoring / GOP** (Goodness of Pronunciation) | a **pronunciation meter** (0–100) per sound — flags e.g. a soft *rr* instead of a trill | this is your "still-to-source" pronunciation piece |
| **TTS** (Text-to-Speech) | the app's **voice** — speaks the reply, can slow down or warm up | your Voicemode pacing rules |
| **xAPI → LRS** | the **logbook / gradebook** — records each turn as a standard statement, sent to a Learning Record Store | your LRS + xAPI tracks, applied to voice |

## Layer 2 — Voice & Conversation Design ("the Interface" / the waiter)

| Term | Plain meaning | In your work |
| --- | --- | --- |
| **VUI** (Voice User Interface) | designing for voice only — no screen — so an anxious learner isn't overwhelmed | Voicemode's short turns, accessibility |
| **Persona** | the character ("Mateo, a Madrid guide") | **Grace** — Mateo is just another Grace |
| **Recast / error recovery** | the good-teacher move: reply *"¡Sí, **una** tortilla!"* — correct by **modelling**, without stopping to lecture | your graded hints / "Don't give up!" |
| **Turn-taking / endpointing** | knowing when the learner has **finished** vs. just paused, so the app doesn't cut them off | Voicemode "pause and listen" |

## Layer 3 — Pedagogy ("the Science" / the nutritionist)

| Term | Plain meaning | In your work |
| --- | --- | --- |
| **CEFR alignment** | match expected vocabulary/grammar to A1–C2 | your evaluation-under-CEFR |
| **Comprehensible input / i+1** | keep language one step above current level (Krashen) | your intentional-repetition principle |
| **Feedback timing** | *when* to correct vs. let it flow (protect "flow state") | your immersion-first design |

---

## What the "Mateo" sample was showing

A **script with the machinery exposed**: on top, a normal chat (order a tortilla →
no onion left → learner asks what *"acabado"* means). Under each turn, the engine's
hidden work: what it heard, what it understood, the grammar slip it caught
(*un → una*), the pronunciation score, and **the teaching decision** ("recast, don't
lecture; define the word in simpler Spanish, not English"). The whole point:
**three layers working at once, invisibly**, while the learner just has a nice chat —
the "not-a-robot-teacher" goal, which is your immersion-first design.

## The two "blueprints," decoded

- **Dialogue tree (state machine)** = a **flowchart of the conversation** ("if grammar
  error → recast + curveball; if they ask a word → scaffold; if they accept → wrap
  up"). It stops the chat hitting a dead end. Your Barcelona "Free-tier branching
  script" is a small version.
- **NLU-to-Pedagogy schema** = a **fill-in-the-blanks form** two parts of the system
  agree to use: the "understanding" part fills it (transcript, intent, errors,
  scores); the "teaching" part reads it and decides what to do. Same idea as your
  **Destination Schema** — a fixed shape, filled with data.

## The xAPI telemetry part

Standard xAPI logs only simple things (pass/fail, a score). To track *language*
detail — which sound degraded, which grammar category, whether help was asked — it
adds **custom extensions** (extra fields you define). The example records
pronunciation per sound, the grammar error **and how it was handled** (recast, not a
drill), vocabulary-help requests, and **turn-taking latency** (long pauses = the
learner is translating in their head = cognitive load). That's the data a **teacher
dashboard** would show, and the signal for "ready to move B1 → B2."

---

## Only six genuinely new words for you

Everything else you already own. The real new vocabulary is just:
**ASR · NLU · TTS · GOP · endpointing · SSML.** That's the whole "engine" gap.

## How deep *you* need to go

You are the **architect** (design + pedagogy) — you do **not** need to become a
speech engineer. Your job: specify *what* the engine must do and *how success is
judged*; collaborate with a developer for the internals (the DSP / acoustic-model
math). If you want one friendly on-ramp, the **Hugging Face Audio Course** is the
best. The suggested capstone (Whisper → phoneme scores → catch a gender error →
route feedback) is a **"later, with a developer"** demo goal, not something to
hand-code yourself now.

## Honest note on the pasted samples

The code snippets are **illustrative sketches, not runnable**. For instance, in the
telemetry examples every extension key is the same placeholder address
(`https://learning.ai` / `https://telemetry.io`) — real xAPI needs a **distinct**
address per field. Good that you saved it as a *concept*, not as final code.

---

## Where this fits in MLLDE

This "voice track" is essentially the **engineering description of the LLM Voice
Architecture layer** in the MLLDE + Voice diagram — the orange band that spans all
four layers. Restated from the kitchen side, it is the **same** new contribution
your PhD proposes:

> Recast = your graded hints · Persona = Grace · i+1 = your Krashen principle ·
> CEFR leveling = your evaluation · xAPI = your LRS track.

**Bottom line:** you are not starting a new field — you are giving an engineering
vocabulary to a design you already built.
