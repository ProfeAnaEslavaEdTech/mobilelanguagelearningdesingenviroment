<!--
  Copyright © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). Todos los derechos reservados.
  Explicación en lenguaje sencillo de la capa LLM Architecture Voice Design de MLLDE.
  Escrita para un perfil no técnico (docente de idiomas / diseñadora instruccional).
  Estándares citados (MCER, xAPI) © sus titulares. Edición en inglés: voice-architecture-explained.en.md
-->

# La arquitectura de voz, explicada en lenguaje sencillo

*Nota complementaria para la capa **LLM Architecture Voice Design** de MLLDE.
Escrita para una docente de idiomas — no para una ingeniera. Sin código.*

---

## La versión de un párrafo

Un "track" de voz para aprender idiomas tiene **tres capas**. Imagina un
**restaurante**: la **cocina** (la tecnología que el estudiante nunca ve), el
**camarero + la sala** (lo que el estudiante oye y siente) y la **nutricionista**
(la ciencia pedagógica tras la carta). Tu trabajo con Grace / Voicemode ya vive en
las capas del *camarero* y de la *nutricionista*. El material de "arquitectura de
voz" trata sobre todo de montar la *cocina* — y coincide casi uno a uno con cosas
que ya haces.

---

## Capa 1 — Arquitectura técnica ("el Motor" / la cocina)

| Término | Significado sencillo | Tú ya… |
| --- | --- | --- |
| **ASR** (reconocimiento de voz) | los **oídos** de la app — convierte el habla en texto | usaste Whisper (un ASR) para transcribir tus audios |
| **NLU** (comprensión del lenguaje) | el paso **"¿qué quiso decir?"** — halla la *intención* ("pedir comida") y los *slots* (ítem = tortilla) | lo haces a mano al diseñar misiones |
| **Puntuación de pronunciación / GOP** | un **medidor de pronunciación** (0–100) por sonido — detecta p. ej. una *rr* floja en vez de vibrante | es tu pieza de pronunciación "aún por incorporar" |
| **TTS** (texto a voz) | la **voz** de la app — dice la respuesta, puede ir más lento o más cálida | tus reglas de ritmo de Voicemode |
| **xAPI → LRS** | el **cuaderno / libro de notas** — registra cada turno como un enunciado estándar, enviado a un Learning Record Store | tus tracks de LRS + xAPI, aplicados a la voz |

## Capa 2 — Diseño de voz y conversación ("la Interfaz" / el camarero)

| Término | Significado sencillo | En tu trabajo |
| --- | --- | --- |
| **VUI** (interfaz de voz) | diseñar solo para la voz — sin pantalla — para no abrumar a un estudiante nervioso | turnos cortos y accesibilidad de Voicemode |
| **Persona** | el personaje ("Mateo, un guía de Madrid") | **Grace** — Mateo es otra Grace |
| **Recast / recuperación del error** | el gesto de buen docente: responder *"¡Sí, **una** tortilla!"* — corregir **modelando**, sin parar a dar una regla | tus pistas graduadas / "Don't give up!" |
| **Toma de turnos / endpointing** | saber cuándo el estudiante **terminó** vs. solo hizo una pausa, para no cortarlo | el "pausa y escucha" de Voicemode |

## Capa 3 — Pedagogía ("la Ciencia" / la nutricionista)

| Término | Significado sencillo | En tu trabajo |
| --- | --- | --- |
| **Alineación con el MCER** | ajustar el vocabulario/gramática esperados a A1–C2 | tu evaluación-bajo-MCER |
| **Input comprensible / i+1** | mantener la lengua un paso por encima del nivel actual (Krashen) | tu principio de repetición intencionada |
| **Momento del feedback** | *cuándo* corregir vs. dejar fluir (proteger el "estado de flujo") | tu diseño centrado en la inmersión |

---

## Qué mostraba el ejemplo de "Mateo"

Un **guion con la maquinaria a la vista**: arriba, una charla normal (pedir una
tortilla → no hay cebolla → el estudiante pregunta qué significa *"acabado"*).
Bajo cada turno, el trabajo oculto del motor: qué oyó, qué entendió, el desliz de
gramática que detectó (*un → una*), la puntuación de pronunciación y **la decisión
pedagógica** ("recast, no des una regla; define la palabra en español más simple,
no en inglés"). La idea central: **tres capas trabajando a la vez, invisibles**,
mientras el estudiante solo tiene una charla agradable — el objetivo
"no-profesor-robot", que es tu diseño centrado en la inmersión.

## Los dos "planos", descifrados

- **Árbol de diálogo (máquina de estados)** = un **diagrama de flujo de la
  conversación** ("si hay error de gramática → recast + giro; si preguntan una
  palabra → andamiaje; si aceptan → cerrar"). Evita callejones sin salida. Tu
  "guion ramificado del nivel Free" de Barcelona es una versión pequeña.
- **Esquema NLU→Pedagogía** = un **formulario a rellenar** que dos partes del
  sistema acuerdan usar: la parte de "comprensión" lo rellena (transcripción,
  intención, errores, puntuaciones); la parte de "enseñanza" lo lee y decide qué
  hacer. Misma idea que tu **Destination Schema** — una forma fija, rellena con datos.

## La parte de telemetría xAPI

El xAPI estándar solo registra cosas simples (aprobado/suspenso, una nota). Para
capturar detalle *lingüístico* — qué sonido decayó, qué categoría de gramática, si
se pidió ayuda — añade **extensiones personalizadas** (campos extra que tú defines).
El ejemplo registra la pronunciación por sonido, el error de gramática **y cómo se
gestionó** (recast, no un drill), las peticiones de ayuda de vocabulario y la
**latencia de turno** (pausas largas = el estudiante traduce en su cabeza = carga
cognitiva). Esos son los datos que mostraría un **panel para docentes**, y la señal
de "listo para pasar de B1 a B2".

---

## Solo seis palabras realmente nuevas para ti

Todo lo demás ya lo dominas. El vocabulario nuevo de verdad es solo:
**ASR · NLU · TTS · GOP · endpointing · SSML.** Ese es todo el hueco del "motor".

## Cuánto necesitas profundizar tú

Tú eres la **arquitecta** (diseño + pedagogía) — **no** necesitas convertirte en
ingeniera de voz. Tu labor: especificar *qué* debe hacer el motor y *cómo se juzga
el éxito*; colaborar con una persona desarrolladora para las tripas (las
matemáticas de DSP / modelos acústicos). Si quieres una entrada amable, el **Hugging
Face Audio Course** es el mejor punto de partida. El capstone propuesto (Whisper →
puntuación de fonemas → detectar un error de género → enrutar el feedback) es una
meta de demostración para **"más adelante, con una persona desarrolladora"**, no
algo que debas programar tú ahora.

## Nota honesta sobre los ejemplos pegados

Los fragmentos de código son **bocetos ilustrativos, no ejecutables**. Por ejemplo,
en los ejemplos de telemetría cada clave de extensión usa la misma dirección de
marcador (`https://learning.ai` / `https://telemetry.io`) — el xAPI real necesita
una dirección **distinta** por campo. Bien hecho al guardarlo como *concepto*, no
como código final.

---

## Dónde encaja esto en MLLDE

Este "track de voz" es, en esencia, la **descripción en clave de ingeniería de la
capa LLM Voice Architecture** del diagrama MLLDE + Voz — la banda naranja que cruza
las cuatro capas. Reformulado desde la cocina, es la **misma** contribución nueva
que propone tu doctorado:

> Recast = tus pistas graduadas · Persona = Grace · i+1 = tu principio de Krashen ·
> nivelación MCER = tu evaluación · xAPI = tu track de LRS.

**En resumen:** no estás empezando un campo nuevo — le estás dando un vocabulario
de ingeniería a un diseño que ya construiste.
