<!--
  © 2026 Ana Eslava-Graterol. All Rights Reserved.
  Brand & website: profeanaeslava · GitHub: profeanaeslavaedtech · Universitat Politècnica de València.
  Part of the PhD proposal (MLLDE Measurement Module).
-->

# Measurement Module — canonical location · ubicación canónica

**EN.** In this consolidated repository the MLLDE Measurement Module lives **once**,
at the repository root, following the project's own single-source-of-truth
governance ("one concept, one IRI"):

| What | Where |
| --- | --- |
| Concept (v3.3) | `../../../concept/cefr-learning-metrics-architect-concept.md` |
| IRI registry (v0.3.0 — single source of truth) | `../../../registry/mllde-xapi-iri-registry.json` |
| Glossary (v1.0) | `../../../glossary/mllde-glossary.md` |
| Skill (SKILL.md + references + assets) | `../../../skill/` |

The voice engine's alignment to the module — evidence tiers, dual telemetry, IPA
target-sound inventories — is specified in `../Voicemode-measurement-alignment.md`
and `../MEASUREMENT-alignment-report.md`.

**ES.** En este repositorio consolidado el Módulo de Medición vive **una sola vez**,
en la raíz (ver tabla). Si `docs/voice/` necesita viajar como paquete independiente,
copia aquí el contenido de la raíz (`concept/`, `glossary/`, `registry/`, `skill/`)
para restaurar la edición autónoma.
