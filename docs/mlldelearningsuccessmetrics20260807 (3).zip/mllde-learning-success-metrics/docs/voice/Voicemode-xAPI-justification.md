<!--
  © 2026 Ana Eslava-Graterol. All Rights Reserved.
  Brand & website: profeanaeslava · GitHub: profeanaeslavaedtech · Universitat Politècnica de València.
  Part of the PhD proposal (MLLDE Measurement Module). CEFR © Council of Europe;
  xAPI © ADL/IEEE; IPA © International Phonetic Association; ESCO © European Union —
  cited standards, not redistributed. Full APA 7th list: ../../skill/references/apa-references.md.
-->

# Justification — MLLDE's Voice Mode is now grounded in the xAPI language layer

**Claim.** MLLDE's voice mode (`Voicemode`, v1.1) is no longer only a *delivery*
design: every voice interaction it specifies is now **evidenced, logged and
reportable** through the MLLDE xAPI language vocabulary ("xAPI Language eLearning" —
the first published IRI vocabulary for CEFR-based language learning). Voice mode and
the Measurement Module are two halves of one claim: *how the lesson is delivered by
voice* (Architecture Voice Design) and *how success in that voice lesson is proven*
(Measurement Module). This document justifies the claim, for the PhD record and for
any technical reviewer.

---

## 1. The gap this closes

Before the alignment (see `MEASUREMENT-alignment-report.md`), the voice engine
produced rich pedagogy but **activity data only**: a lesson could be delivered
perfectly and leave no auditable record that learning occurred. Industry evaluation
(TK Coach, 2026-08) showed exactly where that fails: reports claiming success with
no underlying evidence, sessions that never close, tutors doing the learner's task.
Each failure is now a **named, countable incident IRI** in the registry (v0.3).

## 2. Why xAPI is the right evidence substrate for voice

1. **Granularity.** SCORM reports a course result; a voice lesson needs turn-level
   facts — a spoken turn, its ASR confidence, its latency, a pronunciation attempt.
   xAPI statements describe events at any granularity (*actor–verb–object* +
   result + context), which is why the voice telemetry is expressed in xAPI and
   SCORM is kept only as the compatibility layer for the task-gate result.
2. **Standardisation.** xAPI is codified as **IEEE 9274.1.1-2023** — a stable,
   citable standard, not a passing technology. Statements flow to any conformant
   LRS; cmi5 bridges LMS launching.
3. **A vocabulary gap MLLDE fills.** No official IRI vocabulary existed for CEFR
   skills, subskills or mediation, and no language-learning xAPI profile exists in
   ADL's registry (research finding, 2026-08-04). MLLDE therefore mints its own
   namespace (`https://w3id.org/mllde`, 125 IRIs, v0.3.0) — reuse-first, one
   concept one IRI. **Voice mode is the first consumer of that vocabulary.**

## 3. How Voicemode v1.1 is bound to the xAPI layer (the six upgrades)

| Upgrade (Voicemode-measurement-alignment.md) | xAPI binding |
| --- | --- |
| 1 · Evidence tiers on every voice metric | `ext/evidence-tier` on every statement; reports never claim more precision than the pipeline possesses |
| 2 · Intelligibility-first, accepted variants | `ext/phoneme-scores.acceptedVariants` — seseo/yeísmo never lower a score |
| 3 · IPA target-sound inventories (GOP Half-1) | the data slot `ext/phoneme-scores {ipa, score, confidence, acceptedVariants}` is named from day one — "the gradebook column exists before the microscope is bought" |
| 4 · Dual telemetry — log the teaching act | `verb/adapted` + `ext/pedagogical-action` (recast, scaffold, model-invite, simplify, advance) |
| 5 · Confidence handling + incident family | `ext/asr-confidence`; below 0.70 → `incident/low-asr-confidence`, flag not score; incidents are their own family with a resolution ledger |
| 6 · Mediation reserved as fifth skill | statements carry both the mediation scale IRI and the output-channel skill IRI |

Every rubric band, retry, help request and pronunciation attempt in a Voicemode
session therefore resolves to registry IRIs — no metric without a named CEFR
Companion Volume descriptor scale, no report without statements.

## 4. What the grounding makes possible

- **Auditable proficiency claims**: a pass = task gate + intelligibility ≥ 2 +
  interaction ≥ 2, read against the level descriptor — reconstructable from the LRS.
- **Three persona reports from one data layer**: learner dual ledger (game visible,
  CEFR underneath), teacher adaptation report (prose + JSON), admin KPI/ROI with
  the incident resolution ledger (Kirkpatrick; Phillips Level 5).
- **Phase safety**: Phase 1 (rubric-level voice assessment, tiers 1–2) and Phase 2
  (per-phoneme GOP, tier 3→2) write into slots and IRIs that never change.
- **Replicability**: a new destination or client is a filled project pack (cities +
  IPA inventory + registry); running the Measurement Module skill against it yields
  deliverables D1–D4.

## 5. PhD framing

The two cross-layer modules are claimed together as the proposal's contribution:
**Architecture Voice Design** (a replicable, CEFR-anchored architecture for LLM
conversational agents with pronunciation as a first-class, assessed channel) and the
**Measurement Module** (a replicable, CEFR-anchored measurement architecture with
mediation as fifth skill and voice evidence graded by confidence tier). The xAPI
language vocabulary is the publishable artefact that binds them: the venue for
publication is ADL's profile server after formal JSON-LD profile validation.

**Evidence honesty (standing rule).** At product scale the current evidence base is
UPV expert evaluation and UX testing signal, not cohort retention data; every report
states this plainly and pairs it with the SCORM/xAPI measurement language.

---

*Prepared 2026-08-07 as part of the repository consolidation (see `../../INVENTORY.md`).
Sources: Architecture-Voice-Design-MLLDE.master.md (04-Aug ed.) · Voicemode-measurement-alignment.md ·
MEASUREMENT-alignment-report.md · concept v3.3 · registry v0.3.0. APA 7th references:
../../skill/references/apa-references.md.*
