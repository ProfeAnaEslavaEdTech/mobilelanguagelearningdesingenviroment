<!--
  Copyright © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
  Proprietary and confidential. "Language Passport"™; the character "Grace".
  PER-CITY MODULE — populated. Engine files unchanged. Instance of _TEMPLATE.city.md.
-->

# City Module — Barcelona · Level 1  ·  *per-city content*

> Loaded with an entry point (🎙️ pronunciation or 🗣️ conversation). Persona, voice
> rules, pronunciation method and CEFR rubric come from the shared engine.

## 0. Metadata
| Field | Value |
| --- | --- |
| **City / País** | Barcelona, España |
| **Level #** | 1 |
| **CEFR level** | A1–A2 |
| **DELE / PCIC level** | DELE A1–A2 · PCIC A1–A2 (*peticiones en un bar; fórmulas de cortesía*) |
| **Target language** | Spanish |
| **Base language (glosses)** | English |
| **Session length** | 5 / 10 / 15 min |
| **NPC role (in scene)** | *camarero* (waiter) at a La Rambla tapas bar |

## 1. Scenario / setting
The learner is at a tapas bar on **La Rambla, Barcelona**. Grace plays the
**camarero** and coaches as Grace. It's a real service encounter: greet, order
tapas and drinks politely, close the exchange.

## 2. Mission (authentic assessment)
- **Task:** order **at least 2 tapas + 2 drinks politely**, with a greeting,
  `nos pone…` / `¿me pone…?`, and `por favor`.
- **Success criteria:** a complete, polite order (≥2 tapas + ≥2 drinks) in natural
  register, before energy ("hambre") runs out.

## 3. Vocabulary  *(Spanish — gloss)*
**Tapas:** patatas bravas — *fried potatoes, spicy sauce* · tortilla — *potato omelette* · pinchos — *small skewers/bites* · croquetas — *croquettes* · aceitunas — *olives*
**Bebidas:** cervecilla / una caña — *small beer* · agua (con/sin gas) — *water (sparkling/still)* · vino tinto — *red wine* · un café — *a coffee*
**Cortesía:** hola / buenas — *hi* · por favor — *please* · gracias — *thank you* · ¿cuánto es? — *how much is it?*

## 4. Language chunks / functional exponents
- `¿me pone…?` — *can I have…? (lit. "will you put me…")*
- `nos pone…` — *can you bring us…* (for two people)
- `¿y para beber?` — *and to drink?*
- `¿algo más?` / `nada más, gracias` — *anything else? / nothing more, thanks*
- `una de {patatas bravas}` — *a portion of {…}*

## 5. Grammar focus  *(CEFR + DELE/PCIC A1–A2)*
- **Present of `poner` in the courtesy request** `¿me/nos pone…?` — the polite
  ordering formula — CEFR A1 / PCIC *pedir en un bar*.
- **Indefinite articles + quantities** `un/una/unas`, `una de…, dos cañas` — CEFR A1.
- **`para` + infinitive/noun** `¿y para beber?` — function: purpose — CEFR A2.
- **Courtesy register** `por favor`, `gracias`, `¿me pone?` vs. bare imperative —
  pragmatic appropriateness — CEFR A2 / Kasper & Rose.

## 6. Target sounds / pronunciation focus
- Spanish **pure vowels** /a e i o u/ — *agua, una, hola*
- Tapped **r** — *cerveza, por favor, tortilla* (the single-tap r)
- **ll / y** — *tortilla, cervecilla*
- Soft **c / z** (peninsular /θ/) — *cerveza, gracias*

## 7. Conversation starters — "Frases para iniciar una conversación"
- «Hola, buenas.» — *Hi there.*
- «¿Me pone una caña, por favor?» — *Can I have a small beer, please?*
- «Nos pone dos de patatas bravas.» — *Two portions of patatas bravas for us.*
- «¿Y para beber? Un agua sin gas, por favor.» — *And to drink? A still water, please.*

## 8. Entry point 🎙️ "Mejorar mi pronunciación"  → PRONUNCIATION mode
- **Drill set (say-after-me):** «por favor» · «¿me pone una caña?» · «patatas bravas» · «gracias, ¿cuánto es?»
- **Priority sounds:** tapped **r** (por favor, bravas), **ll** (tortilla), soft **c/z** (cerveza, gracias), pure vowels.
- **Level bar:** score Pronunciation + Intelligibility against the CEFR **A1–A2**
  phonological-control descriptor — *understood by a camarero*, not native-perfect.

## 9. Entry point 🗣️ "Practicar mediante conversaciones"  → CONVERSATION mode
- **Opening line (in character):** «¡Hola, bienvenida! ¿Qué te pongo?» — *Hi, welcome! What can I get you?*
- **Grace asks:** ¿Qué quieres comer? · ¿Y para beber? · ¿Algo más?
- **Completion:** on a complete polite order (≥2 tapas + ≥2 drinks, greeting +
  `por favor`) → congratulate + `<MISSION_COMPLETE>`.

## 10. Graded hints
- **L1** encourage + point to the chunk: *"¡Empieza con un saludo! (start with a greeting)"*
- **L2** model a partial: *"Decimos «¿me pone unas…?» — we say 'can I have some…?'"*
- **L3** more scaffolding: *"«¿Me pone unas patatas bravas y una caña, por favor?»"* (still let them add the second tapa/drink)
- **Solution** only if truly stuck and asked: full model order.

## 11. Rewards
- Coins 🪙: +80 mission · +30 pronunciation drill · +30 reflection.
- **Stamp:** Barcelona · **Souvenir:** a paper *abanico* / La Rambla postcard · **Rank-up:** Hitchhiker → next rank.

## 12. Culture / pragmatics note
In a Spanish bar, `¿me pone…?` is warmer and more natural than a bare *"quiero"*;
a simple `hola/buenas` before ordering is expected courtesy, not optional.
