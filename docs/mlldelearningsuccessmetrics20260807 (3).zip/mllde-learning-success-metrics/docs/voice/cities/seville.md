<!--
  Copyright © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
  Proprietary and confidential. "Language Passport"™; the character "Grace".
  PER-CITY MODULE — populated from the real lesson "De Bares por Santa Cruz".
  Instance of _TEMPLATE.city.md. Engine files unchanged.
-->

# City Module — Sevilla · Level 2  ·  *per-city content*

> Loaded with an entry point (🎙️ pronunciation or 🗣️ conversation). Persona, voice
> rules, pronunciation method and CEFR rubric come from the shared engine.

## 0. Metadata
| Field | Value |
| --- | --- |
| **City / País** | Sevilla, España |
| **Level #** | 2 |
| **CEFR level** | A1–A2 |
| **DELE / PCIC level** | DELE A1–A2 · PCIC A1–A2 (*pedir en un bar; recomendación; preferencia*) |
| **Target language** | Spanish |
| **Base language (glosses)** | English |
| **Session length** | 5 / 10 / 15 min |
| **NPC role (in scene)** | *camarero* at a bar in the Barrio de Santa Cruz |

## 1. Scenario / setting
Evening in the **Barrio de Santa Cruz, Sevilla** — orange trees, tiled patios, the
Giralda glowing above. The learner steps into an Andalusian bar. Grace plays the
**camarero** and coaches as Grace: order tapas and drinks, ask for a recommendation,
close the exchange.

## 2. Mission (authentic assessment)
- **Task:** order **at least 2 tapas + 2 drinks politely**, with a greeting,
  `¿me pone…?` / `para mí…`, and `por favor`; optionally ask `¿qué me recomienda?`.
- **Success criteria:** a complete, polite order (≥2 tapas + ≥2 drinks) in natural
  register, before energy runs out.

## 3. Vocabulary  *(Spanish — gloss)*
**Tapas:** el salmorejo — *cold tomato-and-bread soup* · el pescaíto frito — *fried little fish* · la tapa — *a small dish* · las aceitunas — *olives*
**Bebidas:** una caña — *a small draught beer* · un tinto de verano — *red wine with lemon soda* · un mosto — *grape must (non-alcoholic)* · el agua
**Cortesía / útil:** la cuenta — *the bill* · ¿cuánto es? — *how much is it?* · ¿qué me recomienda? — *what do you recommend?*

## 4. Language chunks / functional exponents
- `¿me pone…?` — *can I have…?*
- `para mí, …` — *for me, …*
- `¿qué me recomienda?` — *what do you recommend?* (asking for a recommendation)
- `¿y para beber?` — *and to drink?*
- `¿algo más?` / `nada más, gracias` — *anything else? / nothing more, thanks*

## 5. Grammar focus  *(CEFR + DELE/PCIC A1–A2)*
- **`poner` in the courtesy request** `¿me pone…?` — the polite ordering formula — CEFR A1 / PCIC *pedir en un bar*.
- **Articles + noun–adjective agreement** `un/una/unas`, *pescaíto **frito*** — CEFR A1 (PCIC: el sustantivo, el adjetivo, el artículo).
- **`de` in the noun phrase** *tinto **de** verano* — preposition linking nouns — CEFR A2.
- **Asking for a recommendation / preference** `¿qué me recomienda?`, `para mí…`, `prefiero…` — PCIC *pedir recomendación / expresar preferencia* — CEFR A2.

## 6. Target sounds / pronunciation focus
- Spanish **pure vowels** /a e i o u/ — *agua, tapa, caña*
- **j / g(e,i)** = [x] — *salmore**j**o, reco**mie**nda* (throaty h-sound)
- Tapped **r** — *salmorejo, reco**r**dar, pesca**í**to* (single-tap r)
- **ñ** — *ca**ñ**a*
- *(Receptive note, don't require at A1–A2:* Andalusian **seseo** and **s-aspiration** — *pescaíto*, *do**s** cañas*.)

## 7. Conversation starters — "Frases para iniciar una conversación"
- «Hola, buenas.» — *Hi there.*
- «¿Me pone una caña, por favor?» — *Can I have a small beer, please?*
- «Para mí, un salmorejo y una tapa de pescaíto.» — *For me, a salmorejo and a dish of fried fish.*
- «¿Qué me recomienda?» — *What do you recommend?*

## 8. Entry point 🎙️ "Mejorar mi pronunciación"  → PRONUNCIATION mode
- **Drill set (say-after-me):** «por favor» · «¿me pone una caña?» · «salmorejo» · «¿qué me recomienda?»
- **Priority sounds:** the **j** in *salmorejo/recomienda*, tapped **r**, **ñ** in *caña*, pure vowels.
- **Level bar:** score Pronunciation + Intelligibility against the CEFR **A1–A2**
  phonological-control descriptor — *understood by a camarero*, not native-perfect.

## 9. Entry point 🗣️ "Practicar mediante conversaciones"  → CONVERSATION mode
- **Opening line (in character):** «¡Hola! ¿Qué le pongo?» — *Hi! What can I get you?*
- **Grace asks:** ¿Qué quiere comer? · ¿Y para beber? · ¿Algo más?  *(offers `¿qué me recomienda?` if the learner hesitates)*
- **Completion:** on a complete polite order (≥2 tapas + ≥2 drinks, greeting +
  `por favor`) → congratulate + `<MISSION_COMPLETE>`.

## 10. Graded hints
- **L1** encourage + point to the chunk: *"¡Empieza con un saludo! (start with a greeting)"*
- **L2** model a partial: *"Decimos «¿me pone…?» o «para mí…»."*
- **L3** more scaffolding: *"«¿Me pone un salmorejo y una caña, por favor?»"* (still let them add the second tapa/drink)
- **Solution** only if truly stuck and asked: full model order.

## 11. Rewards
- Coins 🪙: +80 mission · +30 pronunciation drill · +30 reflection.
- **Stamp:** Sevilla · **Souvenir:** an *azulejo* tile 🔷 / Giralda postcard · **Rank-up:** on the mastery path.

## 12. Culture / pragmatics note
In Sevilla, order a small draught beer as **«una caña»** — *«una cerveza»* is fine,
but locals almost always say *caña*. And **salmorejo** is the thicker, creamier
cordobés–sevillano cousin of gazpacho, topped with jamón and egg.
