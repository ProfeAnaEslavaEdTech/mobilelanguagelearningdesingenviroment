<!--
  Copyright © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
  Proprietary and confidential. "Language Passport"™; the character "Grace".
  PER-CITY MODULE TEMPLATE. Copy this file to cities/<city>.md and fill it in.
  This is the ONLY file you add/edit to ship a new city. The shared engine
  (01-identity-behaviour, Voicemode, references, CEFR-self-assessment) never changes.
-->

# City Module — {{CITY}} · Level {{N}}  ·  *per-city content*

> **How this file is used.** The app loads exactly one city module at a time and
> hands it to Grace together with the chosen **entry point** (🎙️ pronunciation or
> 🗣️ conversation). Grace's persona, voice rules, pronunciation method and CEFR
> evaluation come from the **shared engine** — this file supplies only what is
> *specific to this city and level*. Fill every `{{placeholder}}`; delete the
> guidance comments. **Adding a new city = copying this template once.**

## 0. Metadata
| Field | Value |
| --- | --- |
| **City / País** | {{CITY}}, {{COUNTRY}} |
| **Level #** | {{N}} (destination order on the map) |
| **CEFR level** | {{A1 / A2 / B1 / …}} |
| **DELE / PCIC level** | {{matching DELE level + Instituto Cervantes PCIC reference}} |
| **Target language** | {{e.g. Spanish}} |
| **Base language (glosses)** | {{e.g. English}} |
| **Session length** | {{5 / 10 / 15 min}} |
| **NPC role (in scene)** | {{e.g. camarero, taquillero, guía}} |

## 1. Scenario / setting
{{One or two sentences: where the learner is, who they talk to, the situation.
 Keep it a real, everyday communicative situation for this city.}}

## 2. Mission (authentic assessment)
- **Task:** {{what the learner must accomplish out loud/in text}}
- **Success criteria:** {{measurable, e.g. "complete a polite order of ≥2 X + ≥2 Y"}}

## 3. Vocabulary  *(target language — gloss)*
{{8–15 items grouped by theme}}
- {{palabra}} — *{{gloss}}*
- …

## 4. Language chunks / functional exponents
{{The ready-made phrases for the task — the lexical-approach chunks}}
- `{{chunk}}` — *{{gloss}}*
- …

## 5. Grammar focus  *(CEFR + DELE/PCIC for this level)*
{{The 2–4 grammar points appropriate to the CEFR/DELE level — taken from the
 Instituto Cervantes PCIC inventory for {{level}}. Keep to what the task needs.}}
- {{grammar point}} — *{{why it's needed for the task}}* — CEFR {{level}} / PCIC {{ref}}
- …

## 6. Target sounds / pronunciation focus
{{The phonemes, stress or intonation features this city's phrases exercise —
 drives the 🎙️ pronunciation entry point.}}
- {{sound/feature}} — heard in *{{example word}}*
- …

## 7. Conversation starters — "Frases para iniciar una conversación"
{{The exact phrases the app shows as conversation starters in this city.}}
- «{{frase}}» — *{{gloss}}*
- …

## 8. Entry point 🎙️ "Mejorar mi pronunciación"  → PRONUNCIATION mode
{{What Grace drills here. Runs the shared Voicemode pronunciation ladder
 (Notice → Model → Invite → Move on) over THESE phrases/sounds.}}
- **Drill set (say-after-me phrases):** {{3–6 phrases from §4/§7}}
- **Priority sounds:** {{from §6}}
- **Level bar:** score Pronunciation + Intelligibility against CEFR {{level}} phonological-control descriptor.

## 9. Entry point 🗣️ "Practicar mediante conversaciones"  → CONVERSATION mode
{{Grace runs the §1 scenario as the NPC (the §2 mission), free/guided conversation
 using §3–§5, graded hints from §10, ending in <MISSION_COMPLETE>.}}
- **Opening line (in character):** «{{Grace's first line}}»
- **Grace asks:** {{the 2–3 driving questions}}
- **Completion:** on meeting §2 success criteria → congratulate + `<MISSION_COMPLETE>`.

## 10. Graded hints  *(city-specific wording; method is shared)*
- **L1** encourage + point to the chunk: {{…}}
- **L2** model a partial: {{…}}
- **L3** more scaffolding: {{…}}
- **Solution** only if truly stuck and asked: {{…}}

## 11. Rewards
- Coins 🪙: {{e.g. +80 mission · +30 pronunciation · +30 reflection}}
- **Stamp:** {{city stamp}} · **Souvenir:** {{city souvenir}} · **Rank-up:** {{if applicable}}

## 12. Culture / pragmatics note  *(side quest — optional)*
{{One short, true cultural/pragmatic tip that makes the register natural here.}}

---
<!--
  NOT in this file (comes from the shared engine, do not duplicate):
  Grace's persona & tone, voice interaction rules, the pronunciation FEEDBACK
  METHOD, the 5-category CEFR rubric, accessibility, safety/immersion invariants,
  rewards mechanics, player-state. Edit those once, in the engine — never per city.
-->
