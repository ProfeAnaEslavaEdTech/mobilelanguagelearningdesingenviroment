<!--
  © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved. "Language Passport"™; "Grace".
  PER-CITY MODULE — ⚠️ SCAFFOLD (metadata + scenario filled; content = TODO). Instance of the New-City Kit.
  Fill the TODO blanks; delete the ⚠️ markers when done. Engine files never change.
-->

# City Module — Valencia · Level 3  ·  *per-city content*  ⚠️ SCAFFOLD (fill me)

> Metadata and scenario are set; the linguistic content is **TODO** — fill from the
> New-City Kit. Suggested drafts are marked *(draft — confirm)*.

## 0. Metadata
| Field | Value |
| --- | --- |
| City / País | Valencia, España |
| Level # | 3 |
| CEFR level | A1–A2 |
| DELE / PCIC level | DELE A1–A2 · PCIC A1–A2 (*pedir en una horchatería; cantidades*) |
| Target language | Spanish |
| Base language (glosses) | English |
| Session length | 5 / 10 / 15 min |
| NPC role (in scene) | *camarero/a* at a horchatería in the Barrio del Carmen |

## 1. Scenario / setting
A warm afternoon in **Valencia**. The learner ducks into a classic **horchatería** near
the Mercado Central. Grace plays the **camarero/a** and coaches as Grace: order the local
speciality politely and close the exchange. *(Alternative scene to pick: a bar for
**agua de Valencia**, or a lunch counter for **paella / esmorzaret**.)*

## 2. Mission (authentic assessment)
- **Task:** order **≥2 items + ≥2 drinks politely** (greeting, `¿me pone…?` / `para mí…`, `por favor`).
- **Success criteria:** complete, polite order before energy runs out.
- **CEFR scale it maps to:** *Obtaining goods and services* (spoken interaction).

## 3. Vocabulary *(Spanish — gloss)*  ⚠️ TODO (8–15 items)
*(draft — confirm/expand)*
- la horchata — *tiger-nut drink* · los fartons — *sweet glazed buns (for dipping)* · la chufa — *tiger nut*
- el agua de Valencia — *cava-and-orange cocktail* · el zumo de naranja — *orange juice* · el agua
- la paella (valenciana) — *paella* · el esmorzaret — *mid-morning snack/sandwich* · la cuenta — *the bill*
- {{add more: ¿cuánto es?, gracias, …}}

## 4. Chunks / functional exponents  ⚠️ TODO
- `¿me pone…?` — *can I have…?* *(requesting)*
- `para mí, …` — *for me, …* *(ordering)*
- `¿me lo pone frío?` — *can you make it cold?* *(preference — draft)*
- {{add: ¿y para beber?, ¿algo más?, nada más gracias}}

## 5. Grammar focus *(CEFR + DELE/PCIC A1–A2)*  ⚠️ TODO
- `¿me pone…?` — polite ordering formula (verb *poner*) — A1 · PCIC *pedir en un bar*
- articles + quantities: `un/una/unos`, `una de fartons` — A1
- {{add 1–2 more, e.g. adjective agreement, `con/sin` for options}}

## 6. Target-sound inventory (IPA, "Half-1") — accepted variants never lower a score  ⚠️ TODO
*(draft — confirm)*
| Target (broad) | In word | Feature | Accepted variants (no penalty) |
| --- | --- | --- | --- |
| /a e i o u/ | horchata, agua | pure vowels | — |
| /tʃ/ | horchata /oɾˈtʃata/, chufa | voiceless post-alveolar affricate | — |
| /ɾ/ tap | horchata, farton, naranja | alveolar tap | — |
| /θ/ ~ /s/ | Valencia, zumo | (distinción /θ/) | **seseo /s/** fully accepted |
| /x/ | naranja | velar fricative | softer [h] accepted |
| stress | orˈtʃata · farˈton | correct stress | — |
> Prosody as separate lines. Per-phoneme scoring is **tier 3** until a scorer is integrated.

## 7. Conversation starters — "Frases para iniciar una conversación"  ⚠️ TODO
- «Hola, buenas.» — *Hi there.*
- «¿Me pone una horchata con fartons, por favor?» — *(draft)*
- {{add 1–2}}

## 8. Entry point 🎙️ "Mejorar mi pronunciación" → PRONUNCIATION mode  ⚠️ TODO
- **Drill set (say-after-me):** «por favor» · «una horchata» · «fartons» · «¿cuánto es?» *(draft)*
- **Priority sounds:** /tʃ/ (horchata), tap /ɾ/, seseo /θ/~/s/.
- **Level bar:** Pronunciation + Intelligibility vs. the CEFR A1–A2 descriptor.

## 9. Entry point 🗣️ "Practicar mediante conversaciones" → CONVERSATION mode  ⚠️ TODO
- **Opening line (in character):** «¡Hola! ¿Qué le pongo?» *(draft)*
- **Grace asks:** ¿Qué quiere tomar? · ¿Y para beber? · ¿Algo más?
- **Completion:** on a complete polite order → congratulate + `<MISSION_COMPLETE>`.

## 10. Graded hints  ⚠️ TODO
- **L1** {{"¡Empieza con un saludo!"}}
- **L2** {{"Decimos «¿me pone…?»"}}
- **L3** {{"«¿Me pone una horchata y unos fartons, por favor?»"}}
- **Solution** only if truly stuck and asked.

## 11. Rewards  ⚠️ TODO
- Coins 🪙: +80 mission · +30 pronunciation · +30 reflection.
- Stamp: Valencia · Souvenir: {{e.g. a Fallas ninot / azulejo}} · Rank-up: as configured.

## 12. Culture / pragmatics note  ⚠️ TODO
{{e.g. horchata + fartons is the classic valenciano merienda; horchata is made from
*chufa* (tiger nut); "agua de Valencia" is a cava-and-orange cocktail, not water!}}
