<!--
  © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
  profeanaeslava · profeanaeslavaedtech · UPV. Part of a PhD proposal.
  Voicemode v1.1 — alignment with the MLLDE Measurement Module (docs/voice/measurement-module/).
  CEFR © Council of Europe; xAPI © ADL/IEEE; IPA © International Phonetic Association;
  ESCO © European Union. Cited standards, not redistributed. APA list:
  measurement-module/references/apa-references.md.
-->

# Voicemode v1.1 — Measurement-Module alignment

**What this is.** An upgrade layer that raises the Architecture Voice Design engine
(`Voicemode`, `references`, `cities/`) to the rigour of the **MLLDE Measurement
Module** (the skill now in `docs/voice/measurement-module/`, which cites Voicemode
as its canonical speaking rubric). Nothing here changes the learner experience; it
makes every voice claim **honest, CEFR-traceable and machine-loggable**. IRIs are
quoted from `measurement-module/assets/mllde-xapi-iri-registry.json` — the single
source of truth; never retype an IRI from memory.

---

## The six upgrades

### 1. Evidence tiers on every voice metric
Every voice-derived number now carries a tier (`ext/evidence-tier`), because a score
is only as trustworthy as the weakest machine that made it (ASR → NLU → GOP → TTS):

- **Tier 1 — measurable today:** task gate (`completed`), retries, rubric bands (live
  AI judgment against the descriptor), help requests.
- **Tier 2 — instrumented:** turn-latency, ASR-confidence-weighted scores,
  per-phoneme scores from a **vendor** pronunciation API over our IPA inventory.
- **Tier 3 — pending the GOP build:** bespoke per-phoneme phonological control (the
  PhD's open piece). *Specify the metric and reserve its IRI now; activate later.*

Tier is **per-deployment** — the same metric is tier 2 with a vendor scorer, tier 3
without. Reports never claim more precision than the tier allows.

### 2. Intelligibility-first + accepted variants (never lower a score)
Pronunciation targets **intelligible, appropriate** speech, not native accent.
Legitimate variation must never reduce a score: a *seseo* speaker never scores below
a *distinción* speaker. Accepted variants are encoded **per phoneme** in the IPA
inventory (below) and travel in `ext/phoneme-scores.acceptedVariants`.

### 3. IPA-coded target-sound inventory per destination (GOP "Half-1")
The architect's half of GOP is **linguistic data**: a broad (phonemic) target-sound
inventory per level, with accepted variants and separate prosody lines. With this in
place the spec is vendor-neutral — plug in a scorer today (tier 2), swap the bespoke
GOP later (tier 3) **without changing a metric or IRI**. Draft inventories for the
two live destinations are in §"IPA inventories" below (flag for expert review).

### 4. Dual telemetry — record the teaching act, not only the learner act
Alongside the learner's performance statement, log **what the agent did**, using
`verb/adapted` + `ext/pedagogical-action`:

| Pedagogical action | IRI slug |
| --- | --- |
| Implicit recast (correct by modelling, flow preserved) | `action/implicit-recast` |
| Model + invite retry (pronunciation ladder) | `action/model-invite` |
| Scaffold (graded hint, never the answer first) | `action/scaffold` |
| Simplify / slow down / repeat (penalty-free) | `action/simplify` |
| Advance — reduce support, raise challenge (i+1) | `action/advance` |

This stream is what lets an AI teacher adapt without repeating a failed strategy.

### 5. Confidence handling + the incident family (own metrics, never a penalty)
- Every scored voice statement carries `ext/asr-confidence`.
- Below threshold (D1 default **0.70**): **do not score** → emit
  `incident/low-asr-confidence`, exclude the session from proficiency aggregates,
  surface it as a teacher validity flag.
- Endpointing cut-offs and text-fallback activations are **incidents *and*
  accessibility signals** (`incident/endpointing-cutoff`,
  `incident/text-fallback-activation`) — they shape support, never lower a score.
- Incidents are their **own family** with a resolution ledger; never folded into KPIs.

### 6. Mediation reserved as the fifth skill (B2+)
Voicemode today is A1–A2 (Reception · Production · Interaction). **Mediation**
(`cefr/skill/mediation`) enters at B2 and always carries **two** IRIs — the mediation
scale *and* the output-channel skill (`speaking`/`writing`) — plus the criteria
Content fidelity · Audience adaptation · Bridging strategy. Reserve the slot now.

---

## IPA inventories (GOP Half-1) — draft, flag for expert review

Broad/phonemic transcription. Accepted variants **never lower a score**. Prosody is
separate (anchored to CEFR *Prosodic features*, `cefr/scale/prosodic-features`).
Per-phoneme scoring is **tier 3** until a scorer is integrated (then tier 2).

### Barcelona — "De Tapas Por La Rambla" (peninsular, A1–A2)
| Target (broad) | In word | Feature | Accepted variants (no penalty) |
| --- | --- | --- | --- |
| /a e i o u/ | agua, una, hola | pure monophthongs, no reduction | — |
| /ɾ/ (tap) | por favor /poɾ faˈβoɾ/, bravas | single alveolar tap | slight lengthening; trill not required |
| /ʎ/ | tortilla /toɾˈti.ʎa/ | palatal lateral | **yeísmo** → /ʝ/ (or [dʒ]/[ʒ]) |
| /θ/ | cerveza /θeɾˈβe.θa/, gracias | interdental (distinción) | **seseo** → /s/ |
| /b d ɡ/→[β ð ɣ] | bravas, agua, cuenta | soft approximant between vowels | stop realisation accepted |
| prosody | paˈtatas ˈbɾaβas · torˈtiʎa | correct lexical stress | — |
| prosody | «¿me pone…?» | polite rising request contour | — |

### Sevilla — "De Bares por Santa Cruz" (Andalusian, A1–A2)
| Target (broad) | In word | Feature | Accepted variants (no penalty) |
| --- | --- | --- | --- |
| /a e i o u/ | tapa, caña, agua | pure vowels | — |
| /x/ | salmorejo /sal.moˈɾe.xo/ | voiceless velar fricative | softer [h]-like realisation |
| /ɾ/ (tap) | salmorejo, para, pescaíto | alveolar tap | — |
| /ɲ/ | caña /ˈka.ɲa/ | palatal nasal | — |
| /θ/ ~ /s/ | cerveza, gracias | **seseo is the local norm** | seseo /s/ **and** distinción /θ/ both fine; ceceo accepted receptively |
| coda /s/ | pescaíto, dos cañas | — | **s-aspiration [h] / ∅** (Andalusian) — receptive at A1–A2 |
| prosody | sal.moˈɾe.xo · pes.kaˈi.to | correct stress | — |

> **Rule:** the pedagogical layer (not the scoring engine) decides acceptability
> against this inventory — the engine returns the segment and the variant produced.

---

## IRI mapping (what to log) — from the registry

| Concept | IRI slug (base `https://w3id.org/mllde/…`) |
| --- | --- |
| Level / skill / scale | `cefr/level/*` · `cefr/skill/*` · `cefr/scale/*` |
| Service-encounter mission maps to | `cefr/scale/obtaining-goods-services` |
| Phonology anchors | `cefr/scale/overall-phonological-control` · `cefr/scale/sound-articulation` · `cefr/scale/prosodic-features` |
| Rubric (5) | `rubric/grammar-accuracy · vocabulary-range · pronunciation-phonological-control · intelligibility · interaction` |
| Verbs | `verbs/completed · passed · failed · progressed · asked`; minted `verb/pronounced · verb/adapted` |
| Activity types | `activity-type/mission · conversation-scenario · pronunciation-drill · spoken-turn · learning-unit` |
| Result ext | `ext/rubric-scores · phoneme-scores · asr-confidence · turn-latency-ms · retries · grammar-error` |
| Context ext | `ext/cefr-level · cefr-skill · cefr-scale · persona-pack · evidence-tier · pedagogical-action · help-request` |
| Incidents (v0.3 — 11) | `incident/asr-failure · low-asr-confidence · endpointing-cutoff · text-fallback-activation · completion-token-failure · offtopic-redirect · unresolved-help-request` + **v0.3:** `tutor-task-substitution · report-without-evidence · session-not-finalized · access-denied` |

## Dual ledger (learner-facing)
The learner sees the **game layer** (stamps, coins, ranks, "clearer speech" wins);
the **CEFR layer** runs underneath and is revealed on demand/at milestones ("you can
now order in a café — that's A2 *Obtaining goods and services*"). The CEFR is never
named in-scene (immersion invariant). Retries, help and accessibility signals show as
**effort, never deficit**.

## Phase framing (AE, 2026-08-04)
The IRI registry removes all architectural risk from deferring acoustics — *"the
gradebook column exists before the microscope is bought."* **Phase 1** = speaking &
assessment at **rubric level with real voice** (tiers 1–2). **Phase 2** = acoustic
engineering writes per-phoneme numbers into slots (`ext/phoneme-scores`) named since
day one (tier 3 → 2). No metric or IRI changes between phases.

## How this connects to the deliverables
The Measurement Module skill turns a **project pack** into four documents — **D1**
metrics framework · **D2** assessment blueprint · **D3** xAPI/SCORM spec · **D4**
persona reports. **Language Passport's project pack = the `cities/` modules + these
IPA inventories + the IRI registry.** Run the skill against that pack to generate D1–D4.
*(Engine now aligned to Measurement Module concept v3.3 / registry v0.3.)*

---

*Frameworks & standards cited per `measurement-module/references/apa-references.md`.
IPA inventories are drafts prepared for expert review, not validated data.*
