<!--
  © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
  profeanaeslava · profeanaeslavaedtech · UPV. Part of a PhD proposal.
  Alignment & advancement report: docs/voice engine vs. the authoritative
  MLLDE Learning Success Metrics package (concept v3.3 / registry v0.3).
  Standards (CEFR, PCIC, xAPI, ESCO, IPA) cited, not redistributed.
  APA list: measurement-module/skill/references/apa-references.md.
-->

# Alignment & Advancements Report — Measurement Module

**Scope.** Compare what the repo held (`docs/voice/`, incl. the v0.2 measurement
skill I integrated earlier) against the **authoritative upload**
(`mllde-learning-success-metrics` — concept **v3.3**, registry **v0.3**), align the
documents, and report what advanced. **No code changed** (HTML tool and diagram
untouched); only the documentation/registry engine was aligned.

---

## 1. Version state — before vs now

| | Repo before | Authoritative upload | Repo after alignment |
| --- | --- | --- | --- |
| Measurement skill | `cefr-learning-metrics-architect` (skill only) | same skill, wrapped in a full engine repo | **replaced** with the full package |
| IRI registry | **v0.2.0-draft** (121 IRIs) | **v0.3.0** (125 IRIs) + changelog | **v0.3.0** |
| Concept paper | — (none) | **concept v3.3** (formal PhD definition) | present |
| Governance | — | `README.md` + `CLAUDE.md` (standing rules) | present |
| Jury glossary | — | `glossary/mllde-glossary.md` (v1.0) | present |
| Voice-engine alignment | `Voicemode-measurement-alignment.md` v1.1 | — | updated to v0.3 + phase framing |

## 2. Advancements in the authoritative version

**A. Registry v0.2 → v0.3 (+4 incident IRIs, approved by AE).** From a *TK Coach*
hands-on evaluation, four new incident types were minted:
`incident/tutor-task-substitution` (the tutor did the learner's task — pedagogy-fidelity
violation, target 0), `incident/report-without-evidence` (a claim with no underlying
statements — false positive by design 0), `incident/session-not-finalized` (open session
corrupts time-on-task/completion), `incident/access-denied` (learner/teacher blocked —
onboarding/permissions). A `changelog` field now lives in the registry.

**B. Formal PhD framing (concept v3.3).** The Measurement Module is now stated as the
**second cross-layer module**, a peer to **Architecture Voice Design**, together
completing the four-layer stack: Voice Design answers *how the lesson is delivered*;
Measurement answers ***how success is evidenced, logged and reported***. It is claimed
as a distinct PhD contribution.

**C. Phase framing — "the gradebook column exists before the microscope is bought."**
Phase 1 = speaking & assessment at **rubric level with real voice** (tiers 1–2);
Phase 2 = **acoustic engineering** (GOP) writing per-phoneme numbers into slots named
since day one (tier 3 → 2). The registry removes the architectural risk of deferring
acoustics — no metric or IRI changes between phases.

**D. GOP-in-two-halves is now a dated AE decision (2026-08-04)**, with the vendor
example (Azure AI Speech Pronunciation Assessment) and the reference (Witt & Young, 2000)
fixed; Half-1 (IPA inventory) is the architect's, Half-2 (acoustics) delegated.

**E. IRI research finding elevated to citable IP.** "No official IRI vocabulary exists
for CEFR skills/subskills/mediation; no language-learning xAPI profile exists in ADL's
registry" → MLLDE mints its own namespace (`https://w3id.org/mllde`), publishable at the
ADL profile server after validation. This is now framed as a research contribution.

**F. New standing governance rules (`CLAUDE.md`):**
1. **Copyright + full APA list on *every* artifact** (not just a short notice).
2. **IRIs only from the registry**; new concepts are proposed as a version bump and
   minted only on AE approval. **v0.4 candidates are pending — do not mint:**
   `activity-type/grammar-drill`, `ext/chunk-in-context`, chunk-reuse transfer convention,
   `activity-type/card-pack`, `ext/card-pack-label`, `ext/srs-schedule`.
3. **"Say *adapt*, not *train*."** Learner data adapts per-learner strategy; never
   describe it as training a model.
4. **Engine vs. client repo separation** — nothing client-specific enters the engine
   repo; each client app (e.g. *TK Coach*, `tkcoach-first-application`) fills a project
   pack in its **own** repo.

**G. A named first client — TK Coach.** The skill was tested once end-to-end against TK
Coach (2026-08-04); the formal eval loop is not yet run.

## 3. What I aligned (documents only)

1. **Replaced** `docs/voice/measurement-module/` (v0.2 skill-only) with the full
   authoritative package (README · CLAUDE · concept v3.3 · glossary · registry **v0.3**
   · skill). Incident count in the repo registry is now **11**.
2. **Updated `Voicemode-measurement-alignment.md`:** incident list → 11 (the 4 new
   ones), added the **Phase 1/2 framing**, marked it aligned to concept v3.3 / registry v0.3.
3. **This report** records the delta.

## 4. Remaining alignment gaps (recommendations — not yet applied)

These are consistency items to decide on; I did **not** change them (no code / awaiting
your go):

1. **Standing documentation rule vs. the voice docs.** The authoritative rule requires
   the **full APA 7th list + copyright** on *every* artifact. My voice-engine files
   (`Voicemode`, `references`, `cities/*`, `01-identity-behaviour`, the explainer, the
   HTML tool) carry a short copyright header but **not** the full APA list. → *Action:*
   add a shared `references/apa.md` and reference it from each, or embed the list.
2. **"Adapt, not train."** Some voice materials use "training" language (e.g. the
   **ChatGPT knowledge** files and the worksheet are about *training a Custom GPT*). In
   the metrics context this should read **adapt**; in the GPT-authoring context "train a
   GPT" is the product's own term — worth a consistent wording decision.
3. **Engine vs. client-repo separation.** The authoritative model says the **engine**
   repo holds nothing client-specific, while clients (Language Passport, TK Coach) fill a
   pack in their **own** repo. Right now `docs/voice/` mixes the **engine**
   (measurement-module, Voicemode) with **Language-Passport-specific packs** (`cities/`,
   `chatgpt-knowledge/`). → *Decision:* either treat `cities/` as Language Passport's
   project pack (clearly labelled client data) or split the engine into its own repo, as
   TK Coach already is.
4. **Positioning in the master doc & diagram.** The master doc references the Measurement
   Module under §7; the authoritative framing makes it a **peer cross-layer module** to
   Voice Design. → *Action (doc):* update the master to present **two** cross-layer
   modules; *(diagram is code — deferred per "don't code yet").* 
5. **v0.4 IRIs are pending** — if the app needs grammar-drills, chunk-in-context tracking,
   card-packs or SRS scheduling, those IRIs must be **approved by AE** before use.

## 5. One-line status

*The repo's measurement engine is now aligned to the authoritative concept v3.3 /
registry v0.3; the voice engine references it correctly and adopts the phase framing.
Open items are documentation-consistency (APA list, wording) and repo-governance
(engine vs. client separation), not measurement-model gaps.*

---

*Standards & frameworks cited per
`measurement-module/skill/references/apa-references.md`.*
