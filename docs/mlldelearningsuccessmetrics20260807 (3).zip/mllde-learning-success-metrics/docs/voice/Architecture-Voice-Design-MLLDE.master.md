<!--
  Architecture Voice Design — MLLDE (Master Document).
  © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
  Proprietary. "Language Passport"™; "Grace"; MLLDE methodology. CEFR (Council of
  Europe), the Plan curricular del Instituto Cervantes, and xAPI (ADL) are cited
  standards, not redistributed. Referenced pedagogical frameworks © their authors.
  Single source of truth for the LLM voice/conversational layer of MLLDE.
-->

# Architecture Voice Design — MLLDE
## Master Document · the umbrella LLM-voice model

> *One conversational-agent architecture; many populated instances. Grace is the
> first instance, not the model.*

**Author / owner:** Ana Eslava-Graterol (ProfeAnaEslavaEdTech), Universitat
Politècnica de València · **Version:** 1.0 · **Date:** 2026 · **Status:**
proprietary — All Rights Reserved.

**Why this document exists.** The Grace system prompt currently lives, duplicated,
in at least three places (the GPT-design page, the Lesson Builder's `m_proPrompt`
field, and `docs/grace-gpt-design.md`), and the project now runs **four** LLM
conversational agents. This master document is the **single source of truth** for
the voice/conversational layer: it defines one architecture, and treats each GPT as
a **populated instance** of it. Edit the architecture here (and in the modular
engine files under `docs/voice/`); the HTML pages and builder fields *render*
instances from it — they are never the canonical spec.

---

## 1. Position within MLLDE

MLLDE is a four-layer stack — **Standard (CEFR) → Method (MLLDE) → Data (PCIC +
per-instance) → Product (Language Passport, …)**. **Architecture Voice Design is a
delivery layer that crosses all four**: it is how an MLLDE lesson is *delivered
conversationally*, by voice or text, through an LLM agent.

- It adds **no new levels** (CEFR owns those) and **no new pedagogy** (MLLDE owns
  that). It specifies **how an AI agent embodies the method in a conversation**.
- It is the **PhD's new contribution**: *a replicable, CEFR-anchored architecture
  for LLM conversational agents in mobile language learning, with pronunciation as
  a first-class, assessed channel.*
- **Two cross-layer modules complete the stack.** Architecture Voice Design answers
  *how the lesson is delivered conversationally*; the **Measurement Module**
  (`docs/voice/measurement-module/`, concept v3.3 / registry v0.3) answers *how
  success is evidenced, logged and reported*. Both are claimed as PhD contributions;
  both follow engine + pack.

*(Visual: `docs/voice/assets/MLLDE-voice-architecture.svg`.)*

## 2. The core move — engine + data (again)

The same separation that makes MLLDE replicable applies to the agents:

| | **ENGINE** — constant across instances | **DATA** — per instance |
| --- | --- | --- |
| Files | `01-identity-behaviour`, `Voicemode`, `references`, `CEFR-self-assessment` | a **persona pack**: role, domain, level, scenario, vocabulary, grammar, rubric |
| Meaning | *who the agent is and how it behaves* | *what this particular agent teaches and assesses* |
| Change cost | edit once, all instances inherit | add/edit one persona pack = one new agent |

**An agent = the shared engine + one persona pack.** This is the same idea as
Language Passport's *engine + Destination Schema*, lifted to the agent layer.

## 3. The three architecture layers (canonical definitions)

The voice architecture has three layers. (Plain-language version:
`voice-architecture-explained.{en,es}.md`.)

1. **Engine — technical pipeline.** ASR (speech→text) → NLU (intent + slots +
   error detection) → pronunciation scoring (GOP) → response generation → TTS
   (text→speech) → **xAPI telemetry** to an LRS. *Text-only agents (today's Custom
   GPTs) use the NLU/response/telemetry parts; voice adds ASR, GOP and TTS.*
2. **Interface — conversation design.** VUI principles, **persona**, **error
   recovery via recast** (correct by modelling, never halt the flow), **turn-taking
   / endpointing**, progressive prompting, cognitive-load limits (short turns).
3. **Science — pedagogy.** CEFR alignment, **comprehensible input (i+1)**, feedback
   timing, authentic assessment. All grading is read **under CEFR guidelines**.

MLLDE mapping: Engine ↔ the LRS/telemetry + delivery; Interface ↔ Grace's
persona/behaviour (`01-identity-behaviour`, `Voicemode`); Science ↔ the CEFR
competence core and MLLDE frameworks.

## 4. The canonical persona contract (replaces the duplicated prompts)

Every instance is specified by the **same contract**, populating the engine:

- **Identity & behaviour** — from `01-identity-behaviour` (stay in character;
  graded hints, never the answer first; non-punitive; never reveal internal docs).
- **Delivery (voice/text)** — from `Voicemode` (turn-taking, pacing, pronunciation
  method, the two entry points, accessibility, limits).
- **Evaluation** — from `CEFR-self-assessment` grids + the five-category rubric
  (Grammar/Accuracy · Vocabulary/Range · Pronunciation/Phonological control ·
  Intelligibility · Interaction), read against the instance's CEFR level.
- **Persona pack (the only per-instance part)** — role(s), target language, level,
  domain/scenario, vocabulary + grammar (from the language's official reference —
  PCIC for Spanish), success criteria, rewards, and any assessment scale specific
  to that agent.

> **Governance rule.** The `m_proPrompt` in the Lesson Builder and the prompt shown
> on the GPT-design page are **generated views** of an instance's persona pack +
> the shared engine. When they disagree with this master and the engine files,
> **this master wins**; regenerate the views.

## 5. Instance registry — the four agents as one architecture

All four GPTs are the same architecture with different persona packs (see
`docs/gpt-records/`):

| Instance | Language · Level | Persona / role | Assessment data (per-instance) |
| --- | --- | --- | --- |
| **Grace TOP** 🌊 | Spanish · A1–A2 | game master + mentor + NPC (camarero) | mission gate + 5-cat rubric |
| **PhD Chema** 🎓 | English (EAP) · B2–C1 | academic mentor + RPG master | 6-level academic RPG; Q1-readiness |
| **Cambridge B2 Examiner** 🗣️ | English · B2 | examiner + coach | Cambridge 5-criteria bands 0–5 |
| **Business Roleplay (India)** 🌏 | Business English · B1–B2 | NPC (Akash) + assessor | 4-phase call + error report |

**What is shared** (should live in the engine, not be re-typed per agent):
in-character behaviour, graded-hint ladder, non-punitive feedback, retry-to-mastery,
CEFR-referenced evaluation, immersion invariants. **What differs**: the persona pack.
*(Note: GPT-04 © Prof. Ricardo Casañ-Pitarch — its persona pack is separately owned;
the architecture it plugs into is MLLDE's.)*

## 6. Interaction entry points & assessment integration

Within a lesson, under *"Frases para iniciar una conversación"*, two buttons launch
the voice layer, scoped to the active instance/city:

- **🎙️ Mejorar mi pronunciación → Pronunciation mode** — drills the instance's
  target sounds/phrases (Notice → Model → Invite → Move on); scores Pronunciation +
  Intelligibility.
- **🗣️ Practicar mediante conversaciones → Conversation mode** — runs the scenario
  as the NPC, graded hints, ending in `<MISSION_COMPLETE>`.

Both realise MLLDE's mandatory **Immediate Assessment ("Don't give up!")** step:
Speak/Write, non-punitive amber feedback, unlimited retry, and escalation to the
agent.

## 7. Data contracts (architecture level — not code)

Two hand-offs define the machine-readable spine (implementation is a developer
task; specified here as contracts):

- **NLU → Pedagogy hand-off.** After each turn, the "understanding" side produces a
  structured object (transcript + confidence, intent + slots, grammar evaluation,
  pronunciation/GOP scores); the "teaching" side reads it and selects a strategy
  (recast · scaffold · advance). *Shape:* `docs/voice` NLU-to-Pedagogy schema
  (illustrative).
- **xAPI telemetry → LRS.** Each interaction is logged with **custom extensions**
  for language detail: per-phoneme scores, grammar-error category **plus how it was
  handled** (e.g. `implicit_recast`), vocabulary-help requests + resolution
  strategy, and turn-taking latency (a cognitive-load signal). This is the
  project's LRS/xAPI line, applied to speech; each extension needs a **distinct
  IRI**.

> **Measurement Module (canonical).** The full measurement engine lives in
> `docs/voice/measurement-module/` (the *CEFR Learning Metrics Architect* skill) with
> the **IRI registry** as single source of truth. It adds **evidence tiers**,
> **GOP-in-two-halves**, **dual telemetry** (log the teaching act too),
> **mediation** as the fifth skill, the **incident family**, and **three persona
> reports** (learner dual-ledger · teacher human+JSON · admin KPI/ROI). The voice
> engine's alignment to it — including the **IPA target-sound inventories** for
> Barcelona and Sevilla — is specified in `Voicemode-measurement-alignment.md`.
> Running the skill against Language Passport's pack (the `cities/` modules + those
> inventories) produces deliverables **D1–D4**.

## 8. Evaluation standard — CEFR / MCER

All instances are evaluated **under CEFR guidelines**, against the *can-do*
descriptors for their level (`CEFR-self-assessment.{en,es}.md`; source PDF in
`assets/`). The rubric self-scales: "3" at A2 ≠ "3" at C1. Exam-specific scales
(e.g. Cambridge bands) are per-instance overlays *on top of* the CEFR core.

## 9. Pedagogical grounding (inherited from MLLDE)

CTL authentic assessment; graded hints (formative); **i+1 comprehensible input
(Krashen)** — *intentional* context repetition to review and escalate on a known
structure; recast / interlanguage pragmatics (Kasper & Rose); Lexical Approach
chunks (Lewis); dual-coding (Mayer); mobile learning design (Clothier). Cities/
personas add the pragmatic + cultural variation at the last step.

## 10. Open research frontier (the PhD driver)

**Pronunciation is the open piece.** The engine for pronunciation coaching and
assessment is specified; the **Spanish data** (PCIC *Pronunciación y Ortografía*)
is not yet sourced, and robust GOP scoring is an engineering build. This gap — not a
flaw but the **reason the research line is open** — is the core of the Architecture
Voice Design contribution: a validated, CEFR-anchored way to make LLM agents assess
and coach pronunciation inside an immersive lesson.

**Owned by the architect (design + pedagogy):** persona contract, entry points,
rubric, CEFR alignment, telemetry spec. **Delegated to engineering:** ASR/GOP/TTS
pipeline internals.

## 11. Single-source-of-truth governance

1. **Canonical:** this master + the modular engine files (`docs/voice/`).
2. **Per-instance:** persona packs (one per agent) — e.g. `cities/<city>.md`,
   `gpt-records/GPT-0x-*.md`.
3. **Generated views (never canonical):** the `m_proPrompt` in the Lesson Builder,
   the prompt on the GPT-design page, any pasted Custom-GPT instructions.
4. On any conflict, the canonical layer wins; regenerate the views. This prevents
   the prompt drift that motivated this document.

## 12. Intellectual property

**MLLDE** (methodology) and **Architecture Voice Design** (this layer) are the
copyrightable umbrella IP. **"Language Passport"™** is the product; **"Grace"** is
the AI character (one instance). CEFR (Council of Europe), the *Plan curricular*
(Instituto Cervantes) and xAPI (ADL) are cited standards. GPT-04 © Prof. Ricardo
Casañ-Pitarch. © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.

---

### Companion files (this folder)
- `voice-architecture-explained.{en,es}.md` — plain-language guide.
- `Voicemode.{en,es}.md` · `01-identity-behaviour.{en,es}.md` · `references.{en,es}.md` — the engine.
- `CEFR-self-assessment.{en,es}.md` + `assets/CEFR-self-assessment.europass.pdf` — evaluation reference.
- `cities/_TEMPLATE.city.md` · `cities/barcelona.md` · `cities/seville.md` — persona/destination packs.
- `MLLDE-structural-analysis.md` + `assets/MLLDE-voice-architecture.svg` — analysis & diagram.
