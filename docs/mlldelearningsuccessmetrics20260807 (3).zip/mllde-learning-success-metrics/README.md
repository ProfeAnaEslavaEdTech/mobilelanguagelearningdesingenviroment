# MLLDE — Language Learning Success Metrics (Umbrella)

© 2026 Ana Eslava-Graterol. All Rights Reserved. Brand & website: **profeanaeslava** ·
GitHub: **profeanaeslavaedtech** · Universitat Politècnica de València.
All information forms part of a PhD proposal. CEFR (Council of Europe), PCIC (Instituto
Cervantes), xAPI (ADL/IEEE), ESCO (European Union) and IPA (International Phonetic
Association) are cited standards, not redistributed.

This repository is the **engine**: the MLLDE Measurement Module — a replicable,
CEFR-anchored measurement architecture for language-learning products. It is
app-agnostic. Client applications (e.g. TK Coach, in its own repository) each fill one
*project pack*; this engine never changes per client.

## Structure

```
mllde-learning-success-metrics/
├── README.md            ← you are here
├── CLAUDE.md            ← standing rules for Claude Code sessions in this repo
├── concept/
│   └── cefr-learning-metrics-architect-concept.md   ← the module, formally defined (v3.3)
├── glossary/
│   └── mllde-glossary.md          ← jury-facing glossary (audience: linguists)
├── registry/
│   └── mllde-xapi-iri-registry.json   ← v0.3 · 125 distinct IRIs · single source of truth
└── skill/
    └── cefr-learning-metrics-architect/   ← the Claude skill (agent role)
        ├── SKILL.md
        ├── references/   (cefr-scales, rubric-model, xapi-scorm-spec,
        │                  personas-reporting, evidence-tiers-and-voice,
        │                  glossary, apa-references)
        └── assets/       (registry copy, project-pack template)
```

## The module in one paragraph

Five skills (reading, writing, listening, speaking, **mediation**) anchored to CEFR
Companion Volume descriptor scales; an authentic **task gate** plus a **self-scaling
rubric** (bands read against the level descriptor; pass floors); **dual xAPI telemetry**
(performance stream + pedagogical-action stream) under one IRI namespace
(`https://w3id.org/mllde`); **three evidence tiers** governing every voice-derived
claim; three-persona reporting (learner dual ledger · teacher human/AI JSON · admin
KPI/ROI with an independent incident family and resolution ledger).

## Version state (2026-08-04)

- Registry **v0.3** — four incident IRIs approved by AE (tutor-task-substitution,
  report-without-evidence, session-not-finalized, access-denied).
- Registry **v0.4 candidates — PENDING AE approval, do not mint**: activity-type/grammar-drill ·
  ext/chunk-in-context · chunk-reuse transfer convention · activity-type/card-pack ·
  ext/card-pack-label · ext/srs-schedule.
- Skill tested once end-to-end (TK Coach application, 2026-08-04); formal eval loop
  not yet run.
