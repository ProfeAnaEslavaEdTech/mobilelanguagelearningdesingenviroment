# Skill Concept — `cefr-learning-metrics-architect` (v3.3)

**© 2026 Ana Eslava-Graterol. All Rights Reserved.**
Brand & website: **profeanaeslava** · GitHub: **profeanaeslavaedtech** · UPV (Universitat Politècnica de València).
**All information in this document and its companion artifacts forms part of a PhD proposal.** MLLDE methodology; "Language Passport"™; "Grace".
CEFR (Council of Europe), PCIC (Instituto Cervantes), xAPI (ADL/IEEE), ESCO (European Union) and IPA (International Phonetic Association) are cited standards, not redistributed.

**Standing documentation rule (AE demand, 2026-08-04):** every artifact of this project — the JSON registry, every Markdown document, the project memory, and every future deliverable — must always carry (a) the full copyright block above, (b) the complete APA 7th reference list, and (c) explicit source attribution for any claim taken from an external standard or product. No artifact ships without references and copyright.

**Companion artifacts:**
- `registry/mllde-xapi-iri-registry.json` — MLLDE xAPI IRI Registry (v0.3, 125 distinct IRIs; changelog inside).
- `glossary/mllde-glossary.md` — Glossary of technical terms for the PhD jury (linguists, not AI engineers).

---

## What the skill is

A Claude skill that turns the model into a specialist AI agent: a **Learning Success Metrics Designer** for language-learning apps, grounded in the CEFR Companion Volume (Council of Europe, 2020) / MCER Volumen complementario. Invoked per client project; produces a replicable metrics package. It operationalises the **Measurement Module of MLLDE**, generalised for any client app in any EU language. English-only working language and outputs.

## The Measurement Module of MLLDE (formal definition — PhD proposal)

MLLDE is a four-layer stack — **Standard (CEFR) → Method (MLLDE) → Data (PCIC + per-instance) → Product** — with **Architecture Voice Design** as the cross-layer delivery module (how an MLLDE lesson is delivered conversationally by an LLM agent). The **Measurement Module** is the second cross-layer module and completes the architecture: where the existing engine files answer *who the agent is* (`01-identity-behaviour`), *how the lesson is delivered* (`Voicemode`), *against what standard* (`CEFR-self-assessment`) and *why, pedagogically* (`references`), the Measurement Module answers ***how success is evidenced, logged and reported***.

Its components:

1. **CEFR anchoring rules** — every metric traces to a named Companion Volume descriptor scale (no metric without a descriptor).
2. **The self-scaling rubric model** — authentic task gate + five categories banded 1–3 read against the level's descriptor, with pass floors.
3. **The MLLDE xAPI IRI registry** — one distinct identifier per concept (skills incl. mediation, subskill scales, levels, verbs, activity types, extensions, rubric categories, pedagogical actions, evidence tiers, incident types); first published IRI vocabulary for CEFR constructs.
4. **The dual telemetry stream** — performance statements + pedagogical-action statements (the system records the teaching act, not only the learner act).
5. **The three evidence tiers** — honesty rules governing every claim derived from voice data.
6. **Persona report schemas** — learner dual ledger, teacher (human/AI) adaptation report, admin KPI/ROI with the independent incident family and resolution ledger.
7. **Governance: engine + project pack** — the module's rules are constant; each app instance fills one project pack.

Like Architecture Voice Design, the Measurement Module adds no new levels (CEFR owns those) and no new pedagogy (MLLDE owns that); it specifies how learning success is measured, made interoperable (xAPI/SCORM → LRS), and reported to three personas. It is claimed in the PhD proposal as a contribution alongside Architecture Voice Design: *a replicable, CEFR-anchored measurement architecture for language-learning products, with mediation included as a fifth skill and pronunciation evidence graded by confidence tier.*

## Five skills in scope

Reading, writing, listening, speaking, **and mediation as a fifth skill** (AE decision). Mediation output is always written or oral, so it reuses the production-channel rubrics plus mediation-specific criteria from the Companion Volume (content fidelity, audience adaptation, bridging strategy). Every mediation statement carries both its mediation scale IRI and the output-channel skill IRI.

## Voice is the primary language input

Speaking (and oral mediation) are the most richly instrumented channel, mediated by the machine pipeline (ASR → NLU → GOP → TTS → xAPI/LRS). Every voice-derived metric carries a confidence dimension and one of **three evidence tiers**:

1. **Measurable today** — task completion (`<MISSION_COMPLETE>` gate), retries, rubric bands via LLM judgment, help requests.
2. **Measurable with instrumentation** — turn-taking latency, ASR-confidence-weighted scores, vendor pronunciation-assessment APIs over an IPA-coded inventory.
3. **Pending the GOP build** — bespoke per-phoneme phonological control scoring (open research piece of the PhD).

Evidence honesty applies throughout: at product scale the current evidence base is UPV expert evaluation and UX testing signal, not cohort retention data — reports state this plainly and pair it with the SCORM/xAPI measurement language.

## Solving GOP in two halves (AE decision, 2026-08-04)

**Half 1 — Linguistic data (owned by the architect, solved by IPA).** The project pack requires an **IPA-coded target sound inventory** per language and level: broad (phonemic) transcription of target words/chunks, target features per level (segments, stress, intonation), and **accepted variants** encoding legitimate variation (e.g. *seseo*/*distinción* — a Latin American speaker must never score lower than a Peninsular one; intelligibility-first). Suprasegmentals are separate metric lines anchored to the Companion Volume *Prosodic features* scale, never folded into phoneme scores. The client provides the inventory or the agent drafts it for expert (AE) review. IPA reference: International Phonetic Association (1999).

**Half 2 — Acoustic engineering (delegated; what the engine must do).** Four jobs, specified as requirements: (1) **forced alignment** — locate each sound segment against the expected IPA sequence; (2) **acoustic scoring (GOP proper)** — per-segment likelihood vs a reference model (Witt & Young, 2000); (3) **segment and variation delivery** — return segments and the variant actually produced; **the pedagogical layer, not the engine, decides acceptability**; (4) **prosody measurement** — reported separately.

**Why the two halves close the gap.** With the IPA inventory the spec is engine-ready and **vendor-neutral**: an off-the-shelf scorer plugs in today (product example: Azure AI Speech Pronunciation Assessment — phoneme-level scores, IPA support, prosody), moving phoneme metrics from tier 3 to tier 2; a custom GOP build can replace it later. With both halves specified, xAPI statements carry true phoneme-level results (`phoneme-scores`: {ipa, score, confidence, acceptedVariants}) mappable to any conformant LRS. **Phase framing (AE, 2026-08-04): the IRI registry removes all architectural risk from deferring acoustics — the scales, the data slot and the tier label exist from day one ("the gradebook column exists before the microscope is bought"). Phase 1 = speaking & assessment at rubric level with real voice; Phase 2 = acoustic engineering writes numbers into slots named since day one.**

## The four deliverables (separate documents, per client project)

- **D1 — CEFR Alignment & Metrics Framework.** Per skill × band (Pre-A1–C2) × subskill scale: metric name, definition, formula, data source, threshold, descriptor scale IRI, evidence tier. Metric taxonomy: **proficiency / process-support / pedagogical-action / incident** families.
- **D2 — Assessment Blueprint & Rubrics.** Task gate + five-category self-scaling rubric (bands 1–3 read against the level's descriptor; pass floors: intelligibility ≥2 ∧ interaction ≥2), extended to writing, reading, listening, mediation.
- **D3 — xAPI & SCORM Technical Specification.** The MLLDE xAPI profile on the IRI registry (canonical base `https://w3id.org/mllde`). Dual telemetry stream. SCORM 1.2/2004 carries only the task-gate layer — stated plainly; cmi5 as LMS-launch bridge.
- **D4 — Persona Reporting Pack.** Learner dual ledger (game layer visible, CEFR underneath, never named in-app) · teacher (human or AI) report in prose + JSON (aggregated NLU→Pedagogy contract) · admin→HR KPI/ROI (Kirkpatrick levels; Phillips Level 5: ROI% = (net benefits − costs) ÷ costs × 100) + independent incident family with resolution ledger; optional ESCO URI alignment for EU HR systems.

## Architecture (engine + pack)

- **Metrics engine (constant):** CEFR anchoring rules, self-scaling rubric model, IRI registry/profile, report schemas, evidence-tier rules.
- **Project pack (per client):** language, levels, skills, task inventory, **IPA-coded target sound inventory (required)**, LMS target, personas. New app = one filled pack.

## IRI research finding (2026-08-04)

No official IRI vocabulary exists for CEFR skills, subskills or mediation — the Council of Europe publishes descriptors as documents, not linked data. No language-learning xAPI profile exists in ADL's authored-profiles registry. ESCO language-skill URIs are per-language UUIDs (alignment metadata only). MLLDE therefore mints its own namespace — reuse-first, one concept one IRI — in `registry/mllde-xapi-iri-registry.json`. The registry is citable, publishable IP of the PhD (venue: ADL profile server after formal profile validation).

## IP position

Copyright holder: **Ana Eslava-Graterol** personally; brand/website **profeanaeslava**; GitHub **profeanaeslavaedtech**. All material is part of her PhD proposal. External standards cited, never redistributed.

## References (APA 7th)

Advanced Distributed Learning Initiative. (2017). *xAPI profiles specification* (Version 1.0). GitHub. https://adlnet.github.io/xapi-profiles/

Advanced Distributed Learning Initiative. (n.d.). *ADL xAPI profile server*. Retrieved August 4, 2026, from https://profiles.adlnet.gov/

Advanced Distributed Learning Initiative. (n.d.). *Companion specification for xAPI vocabularies*. GitBook. https://adl.gitbooks.io/companion-specification-for-xapi-vocabularies/

Advanced Distributed Learning Initiative. (n.d.). *xapi-authored-profiles* [Repository]. GitHub. Retrieved August 4, 2026, from https://github.com/adlnet/xapi-authored-profiles

Council of Europe. (2020). *Common European Framework of Reference for Languages: Learning, teaching, assessment — Companion volume*. Council of Europe Publishing. https://www.coe.int/lang-cefr

European Commission. (n.d.). *ESCO: European Skills, Competences, Qualifications and Occupations*. Retrieved August 4, 2026, from https://esco.ec.europa.eu/

Europass. (n.d.). *Common European Framework of Reference for language skills* [Self-assessment grid]. European Union. Retrieved August 4, 2026, from https://europass.europa.eu/en/common-european-framework-reference-language-skills

IEEE. (2023). *IEEE standard for learning technology — JSON data model format and RESTful web service for learner experience data tracking and access (xAPI)* (IEEE Std 9274.1.1-2023). IEEE Standards Association.

International Phonetic Association. (1999). *Handbook of the International Phonetic Association: A guide to the use of the International Phonetic Alphabet*. Cambridge University Press.

Kirkpatrick, J. D., & Kirkpatrick, W. K. (2016). *Kirkpatrick's four levels of training evaluation*. ATD Press.

Krashen, S. D. (1985). *The input hypothesis: Issues and implications*. Longman.

Microsoft. (n.d.). *Use pronunciation assessment* [Documentation]. Microsoft Learn. Retrieved August 4, 2026, from https://learn.microsoft.com/en-us/azure/ai-services/speech-service/how-to-pronunciation-assessment

Phillips, J. J., & Phillips, P. P. (2016). *Handbook of training evaluation and measurement methods* (4th ed.). Routledge.

Rustici Software. (n.d.). *cmi5 in 60 seconds* [Video]. YouTube. Retrieved August 4, 2026, from https://www.youtube.com/watch?v=XxsO2RTakmM

Witt, S. M., & Young, S. J. (2000). Phone-level pronunciation scoring and assessment for interactive language learning. *Speech Communication, 30*(2–3), 95–108. https://doi.org/10.1016/S0167-6393(99)00044-8
