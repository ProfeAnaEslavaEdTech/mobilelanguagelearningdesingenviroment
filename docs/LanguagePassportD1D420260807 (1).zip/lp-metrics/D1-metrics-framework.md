<!--
  © 2026 Ana Eslava-Graterol. All Rights Reserved. Brand & website: profeanaeslava ·
  GitHub: profeanaeslavaedtech · Universitat Politècnica de València. This document applies
  the MLLDE Measurement Module (PhD proposal). MLLDE methodology; "Language Passport"™;
  "Grace". CEFR (Council of Europe), PCIC (Instituto Cervantes), xAPI (ADL/IEEE), ESCO (EU)
  and IPA (International Phonetic Association) are cited standards, not redistributed.
-->

# D1 — CEFR Alignment & Metrics Framework · Language Passport™ / Grace

*Scope: Spanish A1–A2, speaking-first (city modules Barcelona · Sevilla · Valencia ⚠️).
IRIs: registry v0.3.0, base `https://w3id.org/mllde/`. Evidence-tier ceiling today: **1**
(no LRS or pronunciation scorer deployed yet); tier-2/3 metrics are specified with slots
reserved. ASR scoring threshold: **0.70** (below → incident, not score).*

## 1. Metric families

Every metric belongs to exactly one family: **proficiency** (outcomes) ·
**process-support** (effort signals, never penalties) · **pedagogical-action** (what the
teaching side did and whether it worked) · **incident** (system failures, own family,
never folded into KPIs).

## 2. Proficiency metrics — speaking (interaction)

Primary scale: **Obtaining goods and services** (`cefr/scale/obtaining-goods-services`);
secondary: `understanding-interlocutor`, `conversation`, `information-exchange` (Sevilla).

| Metric | Definition / formula | Source | Threshold | Tier |
| --- | --- | --- | --- | --- |
| Mission pass rate | passes ÷ completed attempts; **pass = gate AND intelligibility ≥ 2 AND interaction ≥ 2**, bands read against the A1/A2 descriptor | verbs `completed`→`passed`/`failed` + `ext/rubric-scores` | per-cohort target set at pilot | 1 |
| Task-gate completion | missions reaching `<MISSION_COMPLETE>` ÷ attempts (`attempted`) | performance stream | — | 1 |
| Rubric band profile | mean band per category (5 categories, 1–3) per scale and period | `ext/rubric-scores` | floors: intelligibility ≥ 2 ∧ interaction ≥ 2 | 1 |
| Band progression | learners advancing ≥1 band per period (A1→A2 readiness) | verb `progressed` | — | 1 |
| Time-to-band | median days from first `attempted` to sustained floor-passing at level | statement timestamps | — | 1 |

## 3. Proficiency metrics — pronunciation (phonology anchors)

| Metric | Scale IRI | Definition | Tier |
| --- | --- | --- | --- |
| Phonological-control band | `cefr/scale/overall-phonological-control` | rubric category `pronunciation-phonological-control`, banded 1–3 vs A1–A2 descriptor by AI judge | **1** |
| Model-imitation success | `cefr/scale/overall-phonological-control` | successful say-after-me imitations ÷ drill turns (verb `pronounced`) | 1 |
| Per-phoneme score | `cefr/scale/sound-articulation` | `ext/phoneme-scores` {ipa, score 0–100, confidence, acceptedVariants} against the pack's IPA inventory; **accepted variants (seseo, yeísmo…) never lower a score** | **3** today → 2 with vendor scorer |
| Prosody line | `cefr/scale/prosodic-features` | stress/intonation targets (e.g. *orˈtʃata*, polite rising request contour) — separate line, never merged into phoneme scores | 3 → 2 |

## 4. Proficiency metrics — listening (embedded reception)

| Metric | Scale IRI | Definition | Tier |
| --- | --- | --- | --- |
| Interlocutor comprehension | `cefr/scale/understanding-interlocutor` | learner responds appropriately to Grace's in-character turns (AI-judged per turn, verb `interacted`) | 1 |
| Support-free comprehension rate | same | turns understood without repeat/slow-down request ÷ total turns | 1 |

## 5. Process-support metrics (never penalties)

| Metric | Source | Tier |
| --- | --- | --- |
| Retries to first pass | `ext/retries` (non-punitive mastery loop) | 1 |
| Help requests + resolution strategy | verb `asked` + `ext/help-request` | 1 |
| Turn-taking latency (cognitive-load proxy) | `ext/turn-latency-ms` | **2** (requires instrumentation) |
| Support usage (repeats, slow-downs, text fallback) | pedagogy stream + incident signals | 1–2 |

## 6. Pedagogical-action metrics (the teaching act, logged)

| Metric | Definition | Source | Tier |
| --- | --- | --- | --- |
| Actions per strategy | count per `action/implicit-recast · model-invite · scaffold · simplify · advance` | `verb/adapted` + `ext/pedagogical-action` | 1 |
| Strategy effectiveness | actions followed by improvement in the targeted category ÷ actions | joined streams (shared `registration`) | 1 |
| Tutor-contract fidelity | `incident/tutor-task-substitution` count — **target 0** | incident stream | 1 |

## 7. Incident family (own family + resolution ledger)

Types in scope (registry v0.3): `asr-failure` · `low-asr-confidence` · `endpointing-cutoff` ·
`text-fallback-activation` · `completion-token-failure` · `offtopic-redirect` ·
`unresolved-help-request` · `tutor-task-substitution` · `report-without-evidence` ·
`session-not-finalized` · `access-denied`. Metrics: rate per type, severity distribution,
affected sessions, and the **resolution ledger** (incident → change made → post-change
rate). Validity rule: `low-asr-confidence` sessions are excluded from proficiency
aggregates and surfaced as teacher validity flags. Targets 0 by design:
`tutor-task-substitution`, `report-without-evidence`.

## 8. Verification

Every metric above cites a named Companion Volume scale IRI (rule 3), carries its tier
(rule 4), and uses registry-v0.3.0 identifiers only (rule 2). Mediation: no metrics
activated at A1–A2; slot reserved.

---

## References (APA 7th)

Advanced Distributed Learning Initiative. (2017). *xAPI profiles specification* (Version 1.0). GitHub. https://adlnet.github.io/xapi-profiles/

Advanced Distributed Learning Initiative. (n.d.). *ADL xAPI profile server*. Retrieved August 4, 2026, from https://profiles.adlnet.gov/

Advanced Distributed Learning Initiative. (n.d.). *Companion specification for xAPI vocabularies*. GitBook. https://adl.gitbooks.io/companion-specification-for-xapi-vocabularies/

Advanced Distributed Learning Initiative. (n.d.). *xapi-authored-profiles* [Repository]. GitHub. Retrieved August 4, 2026, from https://github.com/adlnet/xapi-authored-profiles

Council of Europe. (2020). *Common European Framework of Reference for Languages: Learning, teaching, assessment — Companion volume*. Council of Europe Publishing. https://www.coe.int/lang-cefr

European Commission. (n.d.). *ESCO: European Skills, Competences, Qualifications and Occupations*. Retrieved August 4, 2026, from https://esco.ec.europa.eu/

Europass. (n.d.). *Common European Framework of Reference for language skills* [Self-assessment grid]. European Union. Retrieved August 4, 2026, from https://europass.europa.eu/en/common-european-framework-reference-language-skills

IEEE. (2023). *IEEE standard for learning technology — JSON data model format and RESTful web service for learner experience data tracking and access (xAPI)* (IEEE Std 9274.1.1-2023). IEEE Standards Association.

International Phonetic Association. (1999). *Handbook of the International Phonetic Association: A guide to the use of the International Phonetic Alphabet*. Cambridge University Press.

Kirkpatrick, J. D., & Kirkpatrick, W. K. (2016). *Kirkpatrick's four levels of training evaluation*. ATD Press.

Krashen, S. D. (1985). *The input hypothesis: Issues and implications*. Longman.

Microsoft. (n.d.). *Use pronunciation assessment* [Documentation]. Microsoft Learn. Retrieved August 4, 2026, from https://learn.microsoft.com/en-us/azure/ai-services/speech-service/how-to-pronunciation-assessment

Phillips, J. J., & Phillips, P. P. (2016). *Handbook of training evaluation and measurement methods* (4th ed.). Routledge.

Rustici Software. (n.d.). *cmi5 in 60 seconds* [Video]. YouTube. Retrieved August 4, 2026, from https://www.youtube.com/watch?v=XxsO2RTakmM

Witt, S. M., & Young, S. J. (2000). Phone-level pronunciation scoring and assessment for interactive language learning. *Speech Communication, 30*(2–3), 95–108. https://doi.org/10.1016/S0167-6393(99)00044-8
