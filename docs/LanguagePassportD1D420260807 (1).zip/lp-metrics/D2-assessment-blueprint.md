<!--
  © 2026 Ana Eslava-Graterol. All Rights Reserved. Brand & website: profeanaeslava ·
  GitHub: profeanaeslavaedtech · Universitat Politècnica de València. This document applies
  the MLLDE Measurement Module (PhD proposal). MLLDE methodology; "Language Passport"™;
  "Grace". CEFR (Council of Europe), PCIC (Instituto Cervantes), xAPI (ADL/IEEE), ESCO (EU)
  and IPA (International Phonetic Association) are cited standards, not redistributed.
-->

# D2 — Assessment Blueprint & Rubrics · Language Passport™ / Grace

*Assessment is an authentic task, never a test. Two layers everywhere: a binary
**task gate** + a **self-scaling rubric** read against the level's descriptor.
Unlimited, non-punitive retries ("Don't give up!"); amber feedback; correction by
recast. Grace coaches — she never performs the learner's task.*

## 1. The task gates (per mission)

| Mission | Gate criteria (binary, all required) | Signal |
| --- | --- | --- |
| Barcelona L1 — tapas bar, La Rambla | greeting · ≥2 tapas + ≥2 drinks ordered · polite formula (`¿me pone…?`/`nos pone…`) · `por favor` · exchange closed | `<MISSION_COMPLETE>` |
| Sevilla L2 — bar, Santa Cruz | greeting · ≥2 tapas + ≥2 drinks · polite formula (`¿me pone…?`/`para mí…`) · `por favor` (optional: `¿qué me recomienda?` — enriches Interaction band, never gates) | `<MISSION_COMPLETE>` |
| Valencia L3 ⚠️ scaffold | greeting · ≥2 items + ≥2 drinks · polite formula · `por favor` | `<MISSION_COMPLETE>` |

Gate quality rule: the completion token is emitted only when the criteria are met in the
transcript — **no production, no statements, no pass** (`incident/report-without-evidence`
target 0; token parse failures → `incident/completion-token-failure`).

## 2. The speaking rubric (canonical, self-scaling)

Five categories, banded **1–3 against the A1/A2 descriptor** (a 3 at A2 ≠ a 3 at C1):

| Category | Registry IRI slug | A1–A2 reading anchor |
| --- | --- | --- |
| Grammar / Accuracy | `rubric/grammar-accuracy` | courtesy formula `¿me pone…?`, articles/quantities, `para` + purpose |
| Vocabulary / Range | `rubric/vocabulary-range` | mission lexis (tapas/bebidas/cortesía) deployed in context |
| Pronunciation / Phonological control | `rubric/pronunciation-phonological-control` | intelligible to the *camarero*; targets per city IPA inventory; **accepted variants never lower the band** |
| Intelligibility | `rubric/intelligibility` | message understood without undue strain — **pass floor ≥ 2** |
| Interaction | `rubric/interaction` | initiates, responds, closes the exchange — **pass floor ≥ 2** |

**Pass = gate passed ∧ intelligibility ≥ 2 ∧ interaction ≥ 2.** Scored live by the AI
judge (Grace's assessment pass) against the descriptor; bands + transcript reference
logged (tier 1, judge named in statement context).

## 3. Pronunciation ladder (drill assessment)

Notice → Model → Invite → Move on. Each invited imitation = one `pronounced` turn scored
on Pronunciation + Intelligibility only; success = "understood by a camarero", never
native-accent. Per-phoneme detail activates at tier 2/3 into slots already reserved
(`ext/phoneme-scores`); prosody (stress, request contour) is its own line.

## 4. Reception evidence (listening, embedded)

No production to band: comprehension is evidenced by appropriate responses to Grace's
in-character turns (machine-loggable per turn) and by support usage (repeats, slow-downs
— process-support, never a penalty). Pass threshold per level set in D1 §4.

## 5. Writing & mediation — pattern reserved, not activated

Out of A1–A2 scope. When activated: writing gate + categories (Orthographic control ·
Coherence & cohesion · Register) with floors coherence ≥ 2 ∧ appropriateness ≥ 2;
mediation gate (recipient could act on the content) + production rubric + Content
fidelity · Audience adaptation · Bridging strategy, floors intelligibility/coherence ≥ 2
∧ content fidelity ≥ 2. Statements will carry mediation scale IRI + output-channel IRI.

## 6. Item types → telemetry capture

| Item type | Used in | Scoring | Tier |
| --- | --- | --- | --- |
| AI-judge scored (rubric) | missions, conversation mode | live banding vs descriptor; bands + evidence logged | 1 |
| Voice-instrumented | pronunciation drills, spoken turns | phoneme/prosody/latency slots | 2–3 (reserved) |
| Machine-scorable | future reception items | auto-logged | 1 |

## 7. Adaptation rule (inherited, non-negotiable)

Adaptation changes **support only** — graded hints L1→L3 (never the full answer first;
solution only if truly stuck and asked), modelling, simplification, i+1 advance. The task
and the rubric never change. Every action is logged with its IRI (dual telemetry, D3).

---

## References (APA 7th)

Advanced Distributed Learning Initiative. (2017). *xAPI profiles specification* (Version 1.0). GitHub. https://adlnet.github.io/xapi-profiles/

Advanced Distributed Learning Initiative. (n.d.). *ADL xAPI profile server*. Retrieved August 4, 2026, from https://profiles.adlnet.gov/

Advanced Distributed Learning Initiative. (n.d.). *Companion specification for xAPI vocabularies*. GitBook. https://adl.gitbooks.io/companion-specification-for-xapi-vocabularies/

Advanced Distributed Learning Initiative. (n.d.). *xapi-authored-profiles* [Repository]. GitHub. Retrieved August 4, 2026, from https://github.com/adlnet/xapi-authored-profiles

Council of Europe. (2020). *Common European Framework of Reference for Languages: Learning, teaching, assessment — Companion volume*. Council of Europe Publishing. https://www.coe.int/lang-cefr

European Commission. (n.d.). *ESCO: European Skills, Competences, Qualifications and Occupations*. Retrieved August 4, 2026, from https://esco.ec.europa.eu/

Europass. (n.d.). *Common European Framework of Reference for language skills* [Self-assessment grid]. European Union. Retrieved August 4, 2026, from https://europass.europa.eu/en/common-european-framework-reference-language-skills

IEEE. (2023). *IEEE standard for learning technology — JSON data model format and RESTful web service for learner experience data tracking and access (xAPI)* (IEEE Std 9274.1.1-2023). IEEE Standards Association.

International Phonetic Association. (1999). *Handbook of the International Phonetic Association: A guide to the use of the International Phonetic Alphabet*. Cambridge University Press.

Kirkpatrick, J. D., & Kirkpatrick, W. K. (2016). *Kirkpatrick's four levels of training evaluation*. ATD Press.

Krashen, S. D. (1985). *The input hypothesis: Issues and implications*. Longman.

Microsoft. (n.d.). *Use pronunciation assessment* [Documentation]. Microsoft Learn. Retrieved August 4, 2026, from https://learn.microsoft.com/en-us/azure/ai-services/speech-service/how-to-pronunciation-assessment

Phillips, J. J., & Phillips, P. P. (2016). *Handbook of training evaluation and measurement methods* (4th ed.). Routledge.

Rustici Software. (n.d.). *cmi5 in 60 seconds* [Video]. YouTube. Retrieved August 4, 2026, from https://www.youtube.com/watch?v=XxsO2RTakmM

Witt, S. M., & Young, S. J. (2000). Phone-level pronunciation scoring and assessment for interactive language learning. *Speech Communication, 30*(2–3), 95–108. https://doi.org/10.1016/S0167-6393(99)00044-8
