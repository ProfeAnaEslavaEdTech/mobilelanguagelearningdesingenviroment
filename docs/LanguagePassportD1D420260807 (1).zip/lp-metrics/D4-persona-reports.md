<!--
  © 2026 Ana Eslava-Graterol. All Rights Reserved. Brand & website: profeanaeslava ·
  GitHub: profeanaeslavaedtech · Universitat Politècnica de València. This document applies
  the MLLDE Measurement Module (PhD proposal). MLLDE methodology; "Language Passport"™;
  "Grace". CEFR (Council of Europe), PCIC (Instituto Cervantes), xAPI (ADL/IEEE), ESCO (EU)
  and IPA (International Phonetic Association) are cited standards, not redistributed.
-->

# D4 — Persona Reporting Pack · Language Passport™ / Grace

*Three lenses over one LRS data layer (performance + pedagogy + incident streams).
A report is a query over statements — no statements, no claim.*

## 1. Learner — the dual ledger (immersion preserved)

**Game layer (visible):** passport **stamps** (Barcelona · Sevilla · Valencia), coins 🪙
(+80 mission · +30 pronunciation · +30 reflection), souvenirs (abanico, azulejo…),
**ranks** (Hitchhiker → …), streaks, "clearer speech" wins (successful model imitations).

**CEFR layer (underneath, revealed at milestones or on demand, in can-do language —
the CEFR is never named in-scene):** *"You can now order in a Spanish bar — greeting,
ordering politely and closing the exchange."* (evidenced: A2 *Obtaining goods and
services*). Next step framed as the next mission, never as a score.

Rules: every result pairs with a next action; retries and help requests display as
**effort, never failure**; accessibility signals (slow-downs, text fallback) never appear
as deficits; self-set card-pack levels (when cards ship) display separately from
evidenced levels — shown both, never merged.

## 2. Teacher (Grace as AI teacher; human optional) — the adaptation report

**Human-readable (prose):** per learner and period — bands per scale with trend; which
rubric category caps the pass (e.g. pronunciation 1.8 while intelligibility 2.5);
pedagogical actions already tried and outcomes; recommended **support-only** changes;
validity flags (low-ASR sessions excluded).

**Machine-readable JSON (consumed by Grace directly):**

```json
{
  "learner": "learner-8842",
  "period": { "from": "2026-08-01", "to": "2026-08-31" },
  "cefrLevel": "https://w3id.org/mllde/cefr/level/a2",
  "skills": [{
    "skill": "https://w3id.org/mllde/cefr/skill/speaking",
    "scales": [{
      "scale": "https://w3id.org/mllde/cefr/scale/obtaining-goods-services",
      "taskGate": { "attempts": 3, "completions": 2, "retriesToFirstPass": 1 },
      "rubricProfile": { "grammar-accuracy": 2.0, "vocabulary-range": 2.7,
        "pronunciation-phonological-control": 1.8, "intelligibility": 2.5,
        "interaction": 2.2 },
      "evidenceTier": "1-measurable-today"
    }],
    "pronunciation": { "targets": [{ "ipa": "ɾ", "trend": "improving",
      "tier": "3-pending-gop" }] }
  }],
  "pedagogyTried": [{ "action": "implicit-recast", "count": 14,
    "followedByImprovement": 9 }],
  "recommendations": [{ "type": "support-change",
    "detail": "more modelling before invited turns on /ɾ/ targets (Barcelona drill set)" }],
  "validityFlags": [{ "incident": "low-asr-confidence", "sessions": 2,
    "handling": "excluded from scoring" }]
}
```

Grace's loop: read `rubricProfile` floors → check `pedagogyTried` (never blindly repeat a
failed strategy) → adjust **support only** → next report verifies effect. This is
"adaptation", never "training" (GDPR + buyer-promise safety).

## 3. Product owner (admin seat) — KPI, ROI, incidents

Language Passport is B2C today: AE occupies the admin seat; no HR reporting line, so ESCO
alignment is **off** (available later for B2B: attach the ESCO language-skill URI so EU
HR systems can consume results).

**KPI:** active learners · mission completion rate · pass-floor distribution ·
band-progression rate (`progressed`) · time-to-band · per-city funnel (Barcelona →
Sevilla → Valencia).

**ROI frame (honest):** Kirkpatrick L1 reaction (UX signal — exists today) · L2 learning
(band progression — activates with the LRS) · L3 behaviour (chunk reuse across missions)
· L4 results (product measure AE names, e.g. retention/completion) · **Phillips L5:
ROI (%) = (net programme benefits − programme costs) ÷ programme costs × 100.** Every
claimed benefit states its evidence tier; today's evidence base is **UPV expert
evaluation and UX testing signal, not cohort data** — reports say so plainly and pair
each claim with the xAPI plan that closes the gap.

**Incident section (own family, never folded into KPI):** rate + severity per registry
type; **resolution ledger** (incident → change → post-change rate). Watch items with
target 0: `tutor-task-substitution`, `report-without-evidence`. Session hygiene:
`session-not-finalized` rate guards time-on-task validity.

---

## References (APA 7th)

Advanced Distributed Learning Initiative. (2017). *xAPI profiles specification* (Version 1.0). GitHub. https://adlnet.github.io/xapi-profiles/

Advanced Distributed Learning Initiative. (n.d.). *ADL xAPI profile server*. Retrieved August 4, 2026, from https://profiles.adlnet.gov/

Advanced Distributed Learning Initiative. (n.d.). *Companion specification for xAPI vocabularies*. GitBook. https://adl.gitbooks.io/companion-specification-for-xapi-vocabularies/

Advanced Distributed Learning Initiative. (n.d.). *xapi-authored-profiles* [Repository]. GitHub. Retrieved August 4, 2026, from https://github.com/adlnet/xapi-authored-profiles

Council of Europe. (2020). *Common European Framework of Reference for Languages: Learning, teaching, assessment — Companion volume*. Council of Europe Publishing. https://www.coe.int/lang-cefr

European Commission. (n.d.). *ESCO: European Skills, Competences, Qualifications and Occupations*. Retrieved August 4, 2026, from https://esco.ec.europa.eu/

Europass. (n.d.). *Common European Framework of Reference for language skills* [Self-assessment grid]. European Union. Retrieved August 4, 2026, from https://europass.europa.eu/en/common-european-framework-reference-language-skills

IEEE. (2023). *IEEE standard for learning technology — JSON data model format and RESTful web service for learner experience data tracking and access (xAPI)* (IEEE Std 9274.1.1-2023). IEEE Standards Association.

International Phonetic Association. (1999). *Handbook of the International Phonetic Association: A guide to the use of the International Phonetic Alphabet*. Cambridge University Press.

Kirkpatrick, J. D., & Kirkpatrick, W. K. (2016). *Kirkpatrick's four levels of training evaluation*. ATD Press.

Krashen, S. D. (1985). *The input hypothesis: Issues and implications*. Longman.

Microsoft. (n.d.). *Use pronunciation assessment* [Documentation]. Microsoft Learn. Retrieved August 4, 2026, from https://learn.microsoft.com/en-us/azure/ai-services/speech-service/how-to-pronunciation-assessment

Phillips, J. J., & Phillips, P. P. (2016). *Handbook of training evaluation and measurement methods* (4th ed.). Routledge.

Rustici Software. (n.d.). *cmi5 in 60 seconds* [Video]. YouTube. Retrieved August 4, 2026, from https://www.youtube.com/watch?v=XxsO2RTakmM

Witt, S. M., & Young, S. J. (2000). Phone-level pronunciation scoring and assessment for interactive language learning. *Speech Communication, 30*(2–3), 95–108. https://doi.org/10.1016/S0167-6393(99)00044-8
