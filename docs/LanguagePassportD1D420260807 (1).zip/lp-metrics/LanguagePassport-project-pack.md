<!--
  © 2026 Ana Eslava-Graterol. All Rights Reserved. Brand & website: profeanaeslava ·
  GitHub: profeanaeslavaedtech · Universitat Politècnica de València. This document applies
  the MLLDE Measurement Module (PhD proposal). MLLDE methodology; "Language Passport"™;
  "Grace". CEFR (Council of Europe), PCIC (Instituto Cervantes), xAPI (ADL/IEEE), ESCO (EU)
  and IPA (International Phonetic Association) are cited standards, not redistributed.
-->

# MLLDE Measurement Module — Project Pack · **Language Passport™ / Grace**

*Filled 2026-08-07 by the Metrics Architect from the repository's own sources
(cities modules, Voicemode-measurement-alignment.md, Architecture Voice Design
master). Status: drafted by agent — **pending AE expert review** where flagged.*

## 1. Identification
- **Client / product name:** Language Passport™ (AE's own product — first MLLDE instance); AI tutor: **Grace**.
- **Prepared by / date:** Metrics Architect (Claude) under AE supervision · 2026-08-07.
- **Target language(s):** Spanish (peninsular; Andalusian variety in Sevilla module).
- **Learners' base language(s):** English (glosses).

## 2. Scope
- **CEFR levels in scope:** A1–A2 (city modules levels 1–3).
- **Skills in scope:** **Speaking** (production + interaction — primary, voice-first) with its phonology scales; **Listening** as embedded reception inside interaction (*Understanding an interlocutor*). Reading and writing: out of MVP scope. 
- **Mediation present?** Not at A1–A2. **Slot reserved** (fifth skill, enters at B2+): future statements will carry both the mediation scale IRI and the output-channel skill IRI. No mediation metrics are activated in this pack.

## 3. Task inventory

| Task | Level | Primary scale | Secondary | Completion signal |
| --- | --- | --- | --- | --- |
| Barcelona L1 — order ≥2 tapas + ≥2 drinks politely (greeting, `¿me pone…?`, `por favor`) | A1–A2 | `cefr/scale/obtaining-goods-services` | `understanding-interlocutor` · `conversation` | `<MISSION_COMPLETE>` → verb `completed` |
| Sevilla L2 — order ≥2 tapas + ≥2 drinks politely; optional `¿qué me recomienda?` | A1–A2 | `cefr/scale/obtaining-goods-services` | `understanding-interlocutor` · `information-exchange` | `<MISSION_COMPLETE>` |
| Valencia L3 ⚠️ SCAFFOLD — order ≥2 items + ≥2 drinks at a horchatería | A1–A2 | `cefr/scale/obtaining-goods-services` | `understanding-interlocutor` | `<MISSION_COMPLETE>` |
| Pronunciation drills per city (Notice → Model → Invite → Move on) | A1–A2 | `cefr/scale/overall-phonological-control` | `sound-articulation` · `prosodic-features` | drill turn logged (verb `pronounced`) |

All IRI slugs resolve under `https://w3id.org/mllde/` per registry v0.3.0.

## 4. IPA-coded target sound inventory (speaking in scope — required)

| Level | Target features (IPA) | Accepted variants (never lower a score) | Source |
| --- | --- | --- | --- |
| A1–A2 Barcelona | pure vowels /a e i o u/ · tap /ɾ/ (*por favor, bravas*) · /ʎ/ (*tortilla*) · /θ/ (*cerveza, gracias*) · intervocalic [β ð ɣ] · lexical stress · polite rising request contour | **yeísmo** /ʎ/→/ʝ/ ([dʒ]/[ʒ]) · **seseo** /θ/→/s/ · stop realisation of [β ð ɣ] · trill not required for /ɾ/ | Voicemode-measurement-alignment.md — **agent-drafted, pending expert review** |
| A1–A2 Sevilla | pure vowels · /x/ (*salmorejo*) · tap /ɾ/ · /ɲ/ (*caña*) · /θ/~/s/ · lexical stress | **seseo is the local norm** — /s/ and /θ/ both fine; ceceo accepted receptively · softer [h] for /x/ · coda-/s/ aspiration receptive at A1–A2 | same — **pending expert review** |
| A1–A2 Valencia ⚠️ | pure vowels · /tʃ/ (*horchata, chufa*) · tap /ɾ/ · /θ/~/s/ (*Valencia, zumo*) · /x/ (*naranja*) · stress (*orˈtʃata, farˈton*) | **seseo** fully accepted · softer [h] for /x/ | valencia.md scaffold — **agent-drafted, pending expert review** |

Prosody = separate metric lines (`cefr/scale/prosodic-features`), never folded into phoneme scores. Per-phoneme scoring is tier 3 until a scorer is integrated (then tier 2).

## 5. Technical target
- **LMS / platform:** none today — the product runs as app + Custom-GPT instances (Grace). No LMS launch context.
- **Tracking route:** **pure xAPI + LRS** (primary). SCORM/cmi5: not applicable until an LMS-hosted deployment exists; D3 states the SCORM limits for that eventuality.
- **LRS available?** NOT AVAILABLE — to be selected; recommend ADL conformance-tested vendor before go-live.
- **Pronunciation scoring available?** None today. Vendor API (e.g. Azure AI Speech Pronunciation Assessment) = upgrade path; custom GOP = PhD Phase 2.
- **Resulting evidence-tier ceiling for voice metrics:** **Tier 1 today** (task gates, retries, AI-judge rubric bands, help requests). Tier 2 upon instrumentation (latency, ASR confidence, vendor phoneme scores). Tier 3 slots reserved.

## 6. Personas
- **Independent learners:** yes — self-directed; game metaphor = **stamps · coins 🪙 · souvenirs · ranks** (Hitchhiker → …). Dual-ledger rule applies; CEFR never named in-app.
- **Teachers:** **AI agent (Grace)** — adaptation report consumed as JSON per session/period; human teacher optional (reads the prose rendering).
- **LMS administrators:** none today (B2C). The **product owner (AE)** occupies the admin seat: KPI + incident/resolution ledger. ESCO alignment: **not required now** (no HR reporting line); optional for future B2B.

## 7. Evidence base today
UPV expert evaluation and UX testing signal — **no cohort retention data**. This is the honesty line: every report states it plainly and pairs claims with the xAPI measurement plan that will close the gap.

## 8. Constraints & notes
- **Immersion:** CEFR never named in learner-facing surfaces (dual ledger).
- **GDPR-by-design:** actor = `account` app user id, never personal email; statements immutable (corrections via voiding); learner data **adapts** Grace's per-learner strategy — never described as "training".
- **Accessibility:** text fallback and slow-downs are support + incident signals, never score penalties.
- **Tutor contract:** Grace coaches, never performs the learner's task (`incident/tutor-task-substitution` target = 0).
- **IP:** engine © Ana Eslava-Graterol; this filled pack and learner data belong to the product instance.

---

## References (APA 7th)

Advanced Distributed Learning Initiative. (2017). *xAPI profiles specification* (Version 1.0). GitHub. https://adlnet.github.io/xapi-profiles/

Advanced Distributed Learning Initiative. (n.d.). *ADL xAPI profile server*. Retrieved August 4, 2026, from https://profiles.adlnet.gov/

Advanced Distributed Learning Initiative. (n.d.). *Companion specification for xAPI vocabularies*. GitBook. https://adl.gitbooks.io/companion-specification-for-xapi-vocabularies/

Advanced Distributed Learning Initiative. (n.d.). *xapi-authored-profiles* [Repository]. GitHub. Retrieved August 4, 2026, from https://github.com/adlnet/xapi-authored-profiles

Council of Europe. (2020). *Common European Framework of Reference for Languages: Learning, teaching, assessment — Companion volume*. Council of Europe Publishing. https://www.coe.int/lang-cefr

European Commission. (n.d.). *ESCO: European Skills, Competences, Qualifications and Occupations*. Retrieved August 4, 2026, from https://esco.ec.europa.eu/

Europass. (n.d.). *Common European Framework of Reference for language skills* [Self-assessment grid]. European Union. Retrieved August 4, 2026, from https://europass.europa.eu/en/common-european-framework-reference-language-skills

IEEE. (2023). *IEEE standard for learning technology — JSON data model format and RESTful web service for learner experience data tracking and access (xAPI)* (IEEE Std 9274.1.1-2023). IEEE Standards Association.

International Phonetic Association. (1999). *Handbook of the International Phonetic Association: A guide to the use of the International Phonetic Alphabet*. Cambridge University Press.

Kirkpatrick, J. D., & Kirkpatrick, W. K. (2016). *Kirkpatrick's four levels of training evaluation*. ATD Press.

Krashen, S. D. (1985). *The input hypothesis: Issues and implications*. Longman.

Microsoft. (n.d.). *Use pronunciation assessment* [Documentation]. Microsoft Learn. Retrieved August 4, 2026, from https://learn.microsoft.com/en-us/azure/ai-services/speech-service/how-to-pronunciation-assessment

Phillips, J. J., & Phillips, P. P. (2016). *Handbook of training evaluation and measurement methods* (4th ed.). Routledge.

Rustici Software. (n.d.). *cmi5 in 60 seconds* [Video]. YouTube. Retrieved August 4, 2026, from https://www.youtube.com/watch?v=XxsO2RTakmM

Witt, S. M., & Young, S. J. (2000). Phone-level pronunciation scoring and assessment for interactive language learning. *Speech Communication, 30*(2–3), 95–108. https://doi.org/10.1016/S0167-6393(99)00044-8
