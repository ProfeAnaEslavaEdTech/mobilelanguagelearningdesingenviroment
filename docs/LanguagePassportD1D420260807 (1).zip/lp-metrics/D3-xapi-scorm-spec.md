<!--
  © 2026 Ana Eslava-Graterol. All Rights Reserved. Brand & website: profeanaeslava ·
  GitHub: profeanaeslavaedtech · Universitat Politècnica de València. This document applies
  the MLLDE Measurement Module (PhD proposal). MLLDE methodology; "Language Passport"™;
  "Grace". CEFR (Council of Europe), PCIC (Instituto Cervantes), xAPI (ADL/IEEE), ESCO (EU)
  and IPA (International Phonetic Association) are cited standards, not redistributed.
-->

# D3 — xAPI & SCORM Technical Specification · Language Passport™ / Grace

*Identifiers: registry v0.3.0 only (`https://w3id.org/mllde/`; fallback
`https://profeanaeslava.com/xapi`). Never mint an IRI ad hoc — new concepts are proposed
to AE as a registry bump. Tracking route: **pure xAPI + LRS**. Actor identity: `account`
app user id, never personal email (GDPR minimisation); statements immutable, corrections
via voiding; LRS to pass ADL conformance before go-live.*

## 1. Statement anatomy

Every statement: actor · verb (registry) · object (registry activity type) · result ·
context. Context always carries `ext/cefr-level`, `ext/cefr-skill`, `ext/cefr-scale`,
`ext/persona-pack` (`barcelona-a2` · `seville-a2` · `valencia-a2`), `ext/evidence-tier`.
Both streams about one turn share a context `registration` (session id).

## 2. Performance stream — mission completed (Barcelona)

```json
{
  "actor": { "account": { "homePage": "https://languagepassport.app", "name": "learner-8842" } },
  "verb": { "id": "https://adlnet.gov/expapi/verbs/completed" },
  "object": {
    "id": "https://languagepassport.app/missions/barcelona-tapas-order",
    "definition": { "type": "https://w3id.org/mllde/activity-type/mission" }
  },
  "result": {
    "success": true,
    "extensions": {
      "https://w3id.org/mllde/ext/rubric-scores": {
        "https://w3id.org/mllde/rubric/grammar-accuracy": 2,
        "https://w3id.org/mllde/rubric/vocabulary-range": 3,
        "https://w3id.org/mllde/rubric/pronunciation-phonological-control": 2,
        "https://w3id.org/mllde/rubric/intelligibility": 3,
        "https://w3id.org/mllde/rubric/interaction": 2
      },
      "https://w3id.org/mllde/ext/retries": 1
    }
  },
  "context": {
    "registration": "session-uuid",
    "extensions": {
      "https://w3id.org/mllde/ext/cefr-level": "https://w3id.org/mllde/cefr/level/a2",
      "https://w3id.org/mllde/ext/cefr-skill": "https://w3id.org/mllde/cefr/skill/speaking",
      "https://w3id.org/mllde/ext/cefr-scale": "https://w3id.org/mllde/cefr/scale/obtaining-goods-services",
      "https://w3id.org/mllde/ext/persona-pack": "barcelona-a2",
      "https://w3id.org/mllde/ext/evidence-tier": "https://w3id.org/mllde/evidence-tier/1-measurable-today"
    }
  }
}
```

`passed`/`failed` follow the same shape; **`passed` requires gate + floors** (D2). `failed`
is non-punitive and always pairs with unlimited retry. Spoken turns log `interacted` on
`activity-type/spoken-turn`; help requests log `asked` + `ext/help-request`.

## 3. Pronunciation statements

Verb `https://w3id.org/mllde/verb/pronounced` on `activity-type/pronunciation-drill`:

```json
"result": {
  "extensions": {
    "https://w3id.org/mllde/ext/phoneme-scores": [
      { "ipa": "ɾ", "score": 74, "confidence": 0.91, "acceptedVariants": [] },
      { "ipa": "θ", "score": 68, "confidence": 0.88, "acceptedVariants": ["s"] }
    ],
    "https://w3id.org/mllde/ext/asr-confidence": 0.91
  }
}
```

Tier today: rubric-level only (tier 1) — `phoneme-scores` is the **reserved tier-3 slot**
(tier 2 once a vendor scorer runs over the pack's IPA inventories). `acceptedVariants`
encodes seseo/yeísmo etc. — the pedagogical layer decides acceptability, never the engine.
Prosody reports against `cefr/scale/prosodic-features`, never merged. **ASR confidence
< 0.70 → do not score**; emit the incident instead (§5).

## 4. Pedagogy stream — the teaching act

Actor = Grace (agent account). Verb `https://w3id.org/mllde/verb/adapted` for path/support
adaptations; turn-level actions ride the performance verb with
`ext/pedagogical-action` = `action/implicit-recast` · `model-invite` · `scaffold` ·
`simplify` · `advance`. Always record strategy **and** outcome; join to the learner's
statements via shared `registration`. This stream is what lets Grace adapt without
repeating a failed strategy — and it makes `incident/tutor-task-substitution` countable
(target 0).

## 5. Incident statements (independent family)

Object = the failing component; context carries `ext/incident-type` (registry v0.3, 11
types), `ext/incident-severity` (low/medium/high/blocking); resolution recorded later in
`ext/incident-resolution` {change, date, post-change rate} — the ledger consumed by the
admin report. Session lifecycle: "End lesson" finalises the session; sessions left open
emit `incident/session-not-finalized` (protects time-on-task and completion data).

## 6. SCORM mapping — compatibility layer (limits stated plainly)

| MLLDE concept | SCORM 1.2 | SCORM 2004 |
| --- | --- | --- |
| Task gate | `cmi.core.lesson_status` passed/failed | `cmi.completion_status` + `cmi.success_status` |
| Overall score | `cmi.core.score.raw` | `cmi.score.scaled` |
| Rubric bands (summary only) | `cmi.suspend_data` (opaque) | `cmi.objectives.n.*` (one per category) |

**SCORM cannot carry: subskill granularity, turn-level voice detail, phoneme scores, the
pedagogy stream, incident telemetry. Any SCORM-only deployment loses everything except
the task-gate layer.** xAPI is primary; SCORM is fallback. Language Passport today has no
LMS, so no SCORM package ships; this section exists so any future LMS client chooses with
eyes open. **cmi5**: if an LMS launch context ever applies, use cmi5 (LMS launch + minimum
statements) with MLLDE statements sent alongside as "cmi5 allowed" (one-minute intro:
Rustici Software, n.d.).

## 7. Registry discipline

All IRIs above exist in registry v0.3.0. The six v0.4 candidates (grammar-drill,
chunk-in-context, chunk-reuse convention, card-pack, card-pack-label, srs-schedule)
remain **PENDING AE APPROVAL — do not mint**; if engineering needs them, implement behind
flags with non-final IRIs per the Tolk-eti precedent.

---

## References (APA 7th)

Advanced Distributed Learning Initiative. (2017). *xAPI profiles specification* (Version 1.0). GitHub. https://adlnet.github.io/xapi-profiles/

Advanced Distributed Learning Initiative. (n.d.). *ADL xAPI profile server*. Retrieved August 4, 2026, from https://profiles.adlnet.gov/

Advanced Distributed Learning Initiative. (n.d.). *Companion specification for xAPI vocabularies*. GitBook. https://adl.gitbooks.io/companion-specification-for-xapi-vocabularies/

Advanced Distributed Learning Initiative. (n.d.). *xapi-authored-profiles* [Repository]. GitHub. Retrieved August 4, 2026, from https://github.com/adlnet/xapi-authored-profiles

Council of Europe. (2020). *Common European Framework of Reference for Languages: Learning, teaching, assessment — Companion volume*. Council of Europe Publishing. https://www.coe.int/lang-cefr

European Commission. (n.d.). *ESCO: European Skills, Competences, Qualifications and Occupations*. Retrieved August 4, 2026, from https://esco.ec.europa.eu/

Europass. (n.d.). *Common European Framework of Reference for language skills* [Self-assessment grid]. European Union. Retrieved August 4, 2026, from https://europass.europa.eu/en/common-european-framework-reference-language-skills

IEEE. (2023). *IEEE standard for learning technology — JSON data model format and RESTful web service for learner experience data tracking and access (xAPI)* (IEEE Std 9274.1.1-2023). IEEE Standards Association.

International Phonetic Association. (1999). *Handbook of the International Phonetic Association: A guide to the use of the International Phonetic Alphabet*. Cambridge University Press.

Kirkpatrick, J. D., & Kirkpatrick, W. K. (2016). *Kirkpatrick's four levels of training evaluation*. ATD Press.

Krashen, S. D. (1985). *The input hypothesis: Issues and implications*. Longman.

Microsoft. (n.d.). *Use pronunciation assessment* [Documentation]. Microsoft Learn. Retrieved August 4, 2026, from https://learn.microsoft.com/en-us/azure/ai-services/speech-service/how-to-pronunciation-assessment

Phillips, J. J., & Phillips, P. P. (2016). *Handbook of training evaluation and measurement methods* (4th ed.). Routledge.

Rustici Software. (n.d.). *cmi5 in 60 seconds* [Video]. YouTube. Retrieved August 4, 2026, from https://www.youtube.com/watch?v=XxsO2RTakmM

Witt, S. M., & Young, S. J. (2000). Phone-level pronunciation scoring and assessment for interactive language learning. *Speech Communication, 30*(2–3), 95–108. https://doi.org/10.1016/S0167-6393(99)00044-8
