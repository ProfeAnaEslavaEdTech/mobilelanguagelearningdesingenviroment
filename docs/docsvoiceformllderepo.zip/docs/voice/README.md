<!--
  Copyright © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
  Proprietary and confidential. "Language Passport"™; the character "Grace".
-->

# Grace — GPT Design (modular edition · edición modular)

Modular, bilingual rewrite of the single-file *Grace GPT Design*. The monolith is
split by **responsibility** so any one part can change without rewriting the rest
(add a destination = add a file). The design is **language- and level-agnostic**;
all evaluation follows the **CEFR / MCER**.

Reescritura modular y bilingüe del *Diseño del GPT Grace* de un solo archivo. El
monolito se divide por **responsabilidad** para que cualquier parte cambie sin
reescribir el resto (añadir un destino = añadir un archivo). El diseño es
**independiente del idioma y del nivel**; toda la evaluación sigue el **MCER / CEFR**.

---

## Modules · Módulos

| File · Archivo | What it holds · Qué contiene |
| --- | --- |
| `01-identity-behaviour.{en,es}.md` | **Who Grace is & how she behaves** (redesigned). Identity, personality, behaviour, invariants. · **Quién es Grace y cómo se comporta** (rediseñado). |
| `Voicemode.{en,es}.md` | **The voice learning mode.** Conversation model, voice rules, pronunciation, CEFR evaluation, completion, adaptive behaviour, accessibility, limits, metrics, design justification. · **El modo de aprendizaje por voz.** |
| `references.{en,es}.md` | **The rest.** Mission, world, progression, mechanics, **pedagogical references & citations (incl. CEFR/MCER)**, IP, safety, player state, the compiled system-prompt template, and the Level-1 worked example. · **El resto** (referencias y citas, incl. MCER). |
| `CEFR-self-assessment.{en,es}.md` | **★ Essential evaluation reference — for ANY language.** The official Council of Europe / Europass CEFR self-assessment grid, all six levels A1–C2 (Understanding · Speaking · Writing). `Voicemode` grades against these descriptors. · **Referencia esencial de evaluación — para CUALQUIER idioma.** |
| `assets/CEFR-self-assessment.europass.pdf` | The original source PDF, kept as an essential document. · El PDF original, conservado como documento esencial. |
| `cities/_TEMPLATE.city.md` | **Per-city template** — copy once per new city. · **Plantilla por ciudad** — copiar una vez por ciudad nueva. |
| `cities/barcelona.md` · `cities/seville.md` | Populated city modules (Seville is a ⚠️ draft to replace). · Módulos de ciudad (Sevilla es un borrador ⚠️). |
| `transcript-voicemode-design.md` | Cleaned bilingual transcript of the two source voice recordings. · Transcripción bilingüe depurada de las dos grabaciones de origen. |

---

## Architecture — constant engine vs. per-city · Arquitectura — motor constante vs. por ciudad

The design separates **what never changes** from **what changes per city**, so
adding a city touches **one file**. · El diseño separa **lo que nunca cambia** de
**lo que cambia por ciudad**: añadir una ciudad toca **un archivo**.

- **Constant engine (edit once):** `01-identity-behaviour`, `Voicemode`,
  `references`, `CEFR-self-assessment`. Persona, voice rules, the pronunciation
  method, and CEFR evaluation. · **Motor constante (se edita una vez).**
- **Per-city module (add one per city):** `cities/<city>.md` — vocabulary,
  grammar (**CEFR + DELE/PCIC** for the level), scenario, target sounds, the two
  entry points, rewards. · **Módulo por ciudad (uno nuevo por ciudad).**

### Voice mode = a pronunciation/conversation layer with two entry points
Under *"Frases para iniciar una conversación"*, two buttons launch the voice layer,
scoped to the active city:
- **🎙️ "Mejorar mi pronunciación"** → pronunciation drill (city §6, §8).
- **🗣️ "Practicar mediante conversaciones"** → the city's scenario/mission (city §1, §2, §9).

### To add a new city · Para añadir una ciudad
1. `cp cities/_TEMPLATE.city.md cities/<newcity>.md`
2. Fill vocabulary, grammar (CEFR + DELE/PCIC for the level), scenario, target
   sounds, starters, the two entry points, rewards.
3. Register the city in the app's map/level list and point its two buttons at the
   new module. **No engine file changes.** · **Ningún archivo del motor cambia.**

## Principles carried from the design conversation · Principios de la conversación de diseño

1. **Voice is a delivery layer, not a separate product** — same engine, same game,
   same rules. · **La voz es una capa de entrega, no un producto aparte.**
2. **One concern per file** — update one part without breaking the whole. · **Una
   responsabilidad por archivo.**
3. **Language- & level-agnostic**, evaluated **under CEFR/MCER guidelines**. ·
   **Independiente de idioma y nivel**, evaluado **bajo directrices del MCER**.
4. **No long lists read aloud; break complex parts into small spoken chunks.** ·
   **Nada de listas largas en voz alta; divide en pequeños fragmentos.**

## Read order · Orden de lectura

`README` → `01-identity-behaviour` → `Voicemode` → `references`.
Pick your language with the `.en` / `.es` suffix. · Elige idioma con el sufijo
`.en` / `.es`.
