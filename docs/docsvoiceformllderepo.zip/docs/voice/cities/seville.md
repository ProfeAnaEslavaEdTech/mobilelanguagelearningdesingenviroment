<!--
  Copyright © 2026 Ana Eslava-Graterol (ProfeAnaEslavaEdTech). All Rights Reserved.
  Proprietary and confidential. "Language Passport"™; the character "Grace".
  PER-CITY MODULE — ⚠️ DRAFT. Instance of _TEMPLATE.city.md.
-->

# City Module — Sevilla · Level 2  ·  *per-city content*

> ⚠️ **DRAFT — replace with your real Seville scenario.** I didn't have your
> developed Seville content, so this is a plausible A2 *café-breakfast* instance
> that shows how the template fills for a second city. Swap the scenario /
> vocabulary / grammar for your actual one; the structure stays identical.

## 0. Metadata
| Field | Value |
| --- | --- |
| **City / País** | Sevilla, España |
| **Level #** | 2 |
| **CEFR level** | A2 |
| **DELE / PCIC level** | DELE A2 · PCIC A2 (*pedir en una cafetería; preferencias*) |
| **Target language** | Spanish |
| **Base language (glosses)** | English |
| **Session length** | 5 / 10 / 15 min |
| **NPC role (in scene)** | *camarero/a* at a café near the Catedral / Triana |

## 1. Scenario / setting
Morning in **Sevilla**. The learner sits at a café terrace and orders a typical
Andalusian breakfast. Grace plays the **camarero/a** and coaches as Grace.

## 2. Mission (authentic assessment)
- **Task:** order a **breakfast** politely — a food item + a drink — and ask the
  price, using courtesy register and one preference (`prefiero…` / `mejor…`).
- **Success criteria:** a complete, polite breakfast order (≥1 food + ≥1 drink)
  with a greeting, `por favor`, and asking `¿cuánto es?`, before energy runs out.

## 3. Vocabulary  *(Spanish — gloss)*  ⚠️ draft
**Desayuno:** tostada con tomate — *toast with tomato* · mollete — *soft roll* · churros — *churros* · zumo de naranja — *orange juice*
**Bebidas:** café con leche — *coffee with milk* · café solo — *espresso* · colacao — *cocoa drink* · agua
**Cortesía / útil:** para tomar aquí / para llevar — *to have here / to take away* · la cuenta, por favor — *the bill, please* · ¿cuánto es? — *how much is it?*

## 4. Language chunks / functional exponents  ⚠️ draft
- `para desayunar, ¿qué tienen?` — *for breakfast, what do you have?*
- `me pone… , por favor` — *can I have…, please*
- `prefiero… / mejor…` — *I prefer… / better…* (preference)
- `¿para tomar aquí o para llevar?` — *to have here or take away?*
- `la cuenta, por favor` — *the bill, please*

## 5. Grammar focus  *(CEFR + DELE/PCIC A2)*  ⚠️ draft
- **Expressing preference** `prefiero + noun/infinitive`, `mejor…` — CEFR A2 / PCIC *expresar preferencias*.
- **`para` + infinitive** `para tomar aquí / para llevar` — purpose — CEFR A2.
- **`gustar`-type** `me apetece un café` — likes/wants — CEFR A2.
- **Courtesy request** `¿me pone…?` + `por favor` — pragmatic register — CEFR A2.

## 6. Target sounds / pronunciation focus  ⚠️ draft
- **c/z** soft — *zumo, Catedral* · tapped **r** — *naranja, para*
- **j / g(e,i)** — *naranja, jamón* (the [x] sound)
- Optional Andalusian note (receptive only, don't require): *seseo* and final-s aspiration.

## 7. Conversation starters — "Frases para iniciar una conversación"  ⚠️ draft
- «Buenos días.» — *Good morning.*
- «¿Me pone una tostada con tomate, por favor?» — *Can I have toast with tomato, please?*
- «Un café con leche, para tomar aquí.» — *A coffee with milk, to have here.*
- «¿Cuánto es?» — *How much is it?*

## 8. Entry point 🎙️ "Mejorar mi pronunciación"  → PRONUNCIATION mode  ⚠️ draft
- **Drill set (say-after-me):** «buenos días» · «tostada con tomate» · «café con leche» · «¿cuánto es?»
- **Priority sounds:** soft c/z (zumo), tapped r (naranja), j/g (naranja).
- **Level bar:** Pronunciation + Intelligibility vs. CEFR **A2** phonological-control descriptor.

## 9. Entry point 🗣️ "Practicar mediante conversaciones"  → CONVERSATION mode  ⚠️ draft
- **Opening line (in character):** «¡Buenos días! ¿Qué va a desayunar?» — *Good morning! What will you have for breakfast?*
- **Grace asks:** ¿Qué le pongo? · ¿Para tomar aquí o para llevar? · ¿Algo más?
- **Completion:** on a complete polite breakfast order (+ `¿cuánto es?`) → congratulate + `<MISSION_COMPLETE>`.

## 10. Graded hints  ⚠️ draft
- **L1** encourage + point: *"Empieza con «Buenos días»."*
- **L2** model a partial: *"«¿Me pone un café con leche…?»"*
- **L3** more scaffolding: *"«¿Me pone una tostada con tomate y un café, por favor?»"*
- **Solution** only if truly stuck and asked.

## 11. Rewards  ⚠️ draft
- Coins 🪙: +80 mission · +30 pronunciation · +30 reflection.
- **Stamp:** Sevilla · **Souvenir:** azulejo / Giralda postcard · **Rank-up:** as configured.

## 12. Culture / pragmatics note  ⚠️ draft
In Sevilla, breakfast *tostada con tomate* + *café con leche* is the classic order;
`¿me pone…?` and a `buenos días` first are the natural, courteous way to start.
