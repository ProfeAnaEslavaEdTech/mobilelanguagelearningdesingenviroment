<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. Cites xAPI (ADL/IEEE 9274.1.1-2023), SCORM, cmi5 — not redistributed. -->

# xAPI & SCORM technical specification model (D3)

Use the IRI registry (`assets/mllde-xapi-iri-registry.json`) **verbatim**. Never
invent an IRI; if a concept is genuinely missing, propose it as a registry
addition for AE's approval and mark the deliverable "pending registry update."

## 1. Statement shape (xAPI)

`actor` — learner (account on the client LRS/LMS; use an opaque id, not PII).
`verb` — from the registry verbs (e.g. `.../verbs/passed`, `.../verbs/demonstrated`,
`.../verbs/self-assessed`, `.../verbs/mediated`, `.../verbs/coached`, `.../verbs/adapted`).
`object` — an Activity: a mission/task/assessment with an `activityType` from the
registry and a stable IRI id.
`result` — `score.scaled` (−1..1 or 0..1 per profile), `success`, `completion`,
`duration`, plus `result.extensions` for rubric categories and self-scale values.
`context.contextActivities` — attach the **CEFR scale IRI** as a `parent`/`grouping`
Activity so every performance statement is traceable to a descriptor.
`context.extensions` — carry `cefr-level`, `evidence-tier`, and (for mediation)
`mediation-output-channel`.

### Sample — a passed speaking transaction (A2)
```json
{
  "actor": {"account": {"homePage": "https://client.lrs/", "name": "u-8842"}},
  "verb": {"id": "https://profeanaeslavaedtech.github.io/xapi/mllde/verbs/passed",
           "display": {"en": "passed"}},
  "object": {
    "id": "https://client.app/missions/barcelona-tapas-order",
    "definition": {
      "type": "https://profeanaeslavaedtech.github.io/xapi/mllde/activity-types/mission",
      "name": {"en": "Order 2 tapas + 2 drinks, politely"}
    }
  },
  "result": {
    "success": true, "completion": true, "score": {"scaled": 0.83},
    "extensions": {
      "https://profeanaeslavaedtech.github.io/xapi/mllde/extensions/rubric-category": {
        "task-fulfilment": 3, "range": 2, "accuracy": 2, "fluency": 2, "intelligibility": 3
      },
      "https://profeanaeslavaedtech.github.io/xapi/mllde/extensions/evidence-tier": 1
    }
  },
  "context": {
    "contextActivities": {"grouping": [
      {"id": "https://profeanaeslavaedtech.github.io/xapi/mllde/cefr/speaking/transactions"}
    ]},
    "extensions": {
      "https://profeanaeslavaedtech.github.io/xapi/mllde/extensions/cefr-level": "A2"
    }
  }
}
```

## 2. Dual telemetry (the MLLDE differentiator)

Record **two statement streams**:
- **Performance** — what the learner did (verbs: attempted/passed/failed/
  demonstrated/scored/self-assessed).
- **Pedagogical action** — what the teaching agent did (verbs: `coached`,
  `adapted`; extensions `pedagogical-strategy` + `strategy-outcome`). Emit one
  whenever a hint, scaffold, re-level or feedback move is made — human OR AI.
This pairing is what makes AI-teacher adaptation measurable; keep the two streams
linked by a shared `context.registration` (the attempt/session id).

## 3. Mediation statements
Attach two grouping activities: the mediation scale IRI **and** the output-channel
skill IRI. Verb `.../verbs/mediated`; add `mediation-output-channel` extension
("oral"|"written").

## 4. Extensions (all from the registry)
`cefr-level`, `descriptor-iri`, `evidence-tier`, `rubric-category`,
`self-scale-value`, `ipa-target`, `gop-score`, `mediation-output-channel`,
`pedagogical-strategy`, `strategy-outcome`, `incident-id`.

## 5. SCORM mapping and its limits
When the client requires **SCORM 1.2 / 2004**:
- Map `passed/failed` → `cmi.core.lesson_status` / `cmi.completion_status` +
  `cmi.success_status`; `score.scaled` → `cmi.score.scaled` (2004) or
  `cmi.core.score.raw` (1.2, 0–100).
- **Limits to state explicitly in every SCORM deliverable:** SCORM cannot carry
  the rubric-category breakdown, the dual pedagogical-action stream, mediation's
  two-IRI link, or descriptor IRIs. It reduces a rich attempt to status + a single
  score. Therefore: use SCORM for LMS completion/gradebook interop only, and run
  **xAPI to an LRS in parallel** for the real measurement. Say this plainly.

## 6. cmi5
For LMS-**launched** content that still needs xAPI fidelity, use **cmi5**: the LMS
launches the AU and issues the `launched/initialized/…/passed/completed/terminated`
lifecycle, while your MLLDE statements flow to the LRS with full extensions. cmi5
is the recommended bridge when the client is "SCORM-minded" but needs xAPI data.

## 7. LRS notes
State: no PII in `actor` (opaque account ids); the client owns the LRS and data;
retention/GDPR is the client's responsibility; provide a conformance checklist
(statements validate against the registry; every performance statement has a CEFR
grouping activity and an evidence tier).
