<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. MLLDE self-scaling rubric model. -->

# Rubric model — the MLLDE self-scaling rubric (D2 canonical)

The self-scaling rubric is canonical for **speaking** and extends, with the same
three-part shape, to **writing, reading, listening and mediation**. It is
designed so that (a) an authentic task must be completed before quality is
scored, (b) categories scale with CEFR level rather than being fixed, and (c)
minimum "pass floors" protect intelligibility and task success.

## The three parts of every rubric

1. **Authentic-task gate (binary).** Did the learner accomplish the real
   communicative goal? (Ordered the 2 tapas + 2 drinks; wrote the email that
   gets the refund.) If the gate fails, the attempt is *not passed* regardless of
   language quality — record `failed` with reason `task-not-accomplished`. The
   gate is what keeps metrics tied to can-do, not to decontextualised accuracy.

2. **Self-scaling categories (0–3 each).** Each category is scored against the
   descriptor **for the task's target level**, so "3" means "meets the C-V
   descriptor for this band," not "native-like." Categories per skill below.
   The band scales the expectation; the scale (0–3) stays constant.

3. **Pass floors (per category).** A minimum each category must reach for the
   attempt to pass even if the gate is met (e.g. intelligibility ≥ 2). Floors
   encode the non-negotiables; everything else contributes to the aggregate.

**Aggregate:** pass = gate met AND all floors met. Score = mean of categories,
reported with the band. Never convert to a percentage without the band label.

## Categories by skill

- **Speaking (production/interaction):** Task fulfilment · Range (vocabulary &
  structures for the band) · Accuracy (band-appropriate) · Fluency/coherence ·
  **Intelligibility** (phonological control; floor ≥ 2). Interaction adds
  **Interaction management** (turn-taking, repair).
- **Writing:** Task fulfilment · Range · Accuracy · Cohesion/coherence ·
  Register/appropriacy. (Floors: task fulfilment ≥ 2, coherence ≥ 2.)
- **Reading (reception):** machine-scorable items primarily — comprehension
  accuracy, inference, orientation/scanning success, speed-appropriateness. The
  "rubric" here is an item map; production of a response uses the writing/speaking
  rubric.
- **Listening (reception):** comprehension accuracy, gist vs. detail, inference,
  coping with delivery speed/accent. Same item-map logic as reading.
- **Mediation:** Accomplishment of the mediation goal (gate) · Fidelity (no
  distortion of source) · Adaptation to the recipient · Clarity of the reformulation
  · plus the **output-channel** categories (speaking or writing) since the learner
  still produces oral/written text. Two IRIs travel with every mediation score.

## Item types (this decides telemetry)

- **Machine-scorable** (auto-captured): selected response, matching, ordering,
  gap-fill, short exact-match — used mostly for **reception**. Telemetry can
  score these automatically → evidence Tier 1.
- **Rubric / AI-judge scored**: production and mediation. Scored by a human, an
  AI judge, or self+peer with moderation. Telemetry captures the rubric category
  scores + who/what judged → Tier 1 if human/validated judge, Tier 2 if AI-judge
  pending validation (see `evidence-tiers-and-voice.md`).
- **Speech-scored**: pronunciation via GOP/acoustic pipeline → Tier 2/3 until the
  GOP build is validated; intelligibility by rubric can be Tier 1 today.

## Immersion rule

Learners see the product metaphor (stamp earned, rank up), never the rubric
category names or CEFR band. The rubric runs underneath; the dual ledger
(`personas-reporting.md`) maps stamp → band for teacher/admin views.

## Output for D2

For each skill in scope: the gate statement, the category list with band-scaled
descriptors (cite the CV scale IRI, don't paste text), the pass floors, the
item-type decision, and a worked example at one target level.
