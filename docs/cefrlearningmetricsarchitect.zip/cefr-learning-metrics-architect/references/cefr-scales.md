<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. Cites CEFR Companion Volume (Council of Europe, 2020); descriptor text is NOT reproduced here. -->

# CEFR scales — the five skills and their Companion Volume descriptor scales

**Copyright note.** The CEFR *Companion Volume* (Council of Europe, 2020) descriptor
wording is copyrighted. This file lists **scale names, level ranges, IRIs and
mapping guidance only** — never paste descriptor text into a deliverable; cite the
scale and quote from the official source under the client's own licence.

Every metric in D1 MUST cite one of the scale IRIs below (see
`assets/mllde-xapi-iri-registry.json`, which is the single source of truth for the
exact IRI strings). MLLDE organises the Companion Volume's communicative-activity
scales under **five skills**; interaction and production scales are grouped with
their output channel (speaking or writing).

## 1. Reading (reception, written)
Level range: Pre-A1 → C2.
Companion Volume scales:
- Overall reading comprehension — `cefr/reading/overall`
- Reading correspondence — `cefr/reading/correspondence`
- Reading for orientation — `cefr/reading/orientation`
- Reading for information and argument — `cefr/reading/information-argument`
- Reading instructions — `cefr/reading/instructions`
- Reading as a leisure activity — `cefr/reading/leisure`

## 2. Listening (reception, oral / audiovisual)
- Overall listening comprehension — `cefr/listening/overall`
- Understanding conversation between other people — `cefr/listening/conversation-others`
- Listening as a member of a live audience — `cefr/listening/live-audience`
- Listening to announcements and instructions — `cefr/listening/announcements-instructions`
- Listening to audio media and recordings — `cefr/listening/audio-media`
- Watching TV, film and video (audiovisual) — `cefr/listening/audiovisual`

## 3. Speaking (spoken production + spoken interaction + phonology)
Production:
- Overall oral production — `cefr/speaking/production-overall`
- Sustained monologue: describing experience — `cefr/speaking/monologue-describing`
- Sustained monologue: giving information — `cefr/speaking/monologue-information`
- Sustained monologue: putting a case (argument) — `cefr/speaking/monologue-argument`
Interaction:
- Overall spoken interaction — `cefr/speaking/interaction-overall`
- Conversation — `cefr/speaking/conversation`
- Informal / formal discussion — `cefr/speaking/discussion`
- Goal-oriented co-operation — `cefr/speaking/goal-oriented-cooperation`
- Transactions to obtain goods and services — `cefr/speaking/transactions`
- Information exchange — `cefr/speaking/information-exchange`
Phonology (Companion Volume 2018/2020 revised):
- Overall phonological control — `cefr/speaking/phonology-overall`
- Sound articulation — `cefr/speaking/phonology-articulation`
- Prosodic features — `cefr/speaking/phonology-prosody`

## 4. Writing (written production + written interaction)
Production:
- Overall written production — `cefr/writing/production-overall`
- Creative writing — `cefr/writing/creative`
- Reports and essays — `cefr/writing/reports-essays`
Interaction:
- Overall written interaction — `cefr/writing/interaction-overall`
- Correspondence — `cefr/writing/correspondence`
- Notes, messages and forms — `cefr/writing/notes-messages-forms`
Online interaction (cross-channel):
- Online conversation and discussion — `cefr/online/conversation-discussion`
- Goal-oriented online transactions and collaboration — `cefr/online/transactions-collaboration`

## 5. Mediation (MLLDE's fifth skill)
Output channel is ALWAYS oral or written — every mediation metric carries **both**
the mediation scale IRI and the output-channel skill IRI (see D1 rule).
Mediating texts:
- Relaying specific information — `cefr/mediation/relaying-information`
- Explaining data (graphs, diagrams) — `cefr/mediation/explaining-data`
- Processing text — `cefr/mediation/processing-text`
- Translating a written text (in speech / in writing) — `cefr/mediation/translating`
- Note-taking (lectures, meetings) — `cefr/mediation/note-taking`
- Expressing a personal response to creative texts — `cefr/mediation/response-creative`
Mediating concepts:
- Facilitating collaborative interaction with peers — `cefr/mediation/facilitating-collaboration`
- Collaborating to construct meaning — `cefr/mediation/constructing-meaning`
- Managing interaction — `cefr/mediation/managing-interaction`
Mediating communication:
- Facilitating pluricultural space — `cefr/mediation/pluricultural-space`
- Acting as intermediary in informal situations — `cefr/mediation/intermediary-informal`
- Facilitating communication in delicate situations and disagreements — `cefr/mediation/delicate-situations`
Mediation strategies:
- Adapting language — `cefr/mediation/strategy-adapting-language`
- Breaking down complicated information — `cefr/mediation/strategy-breaking-down`
- Amplifying / streamlining a text — `cefr/mediation/strategy-amplify-streamline`

## How to map an app task to a scale
1. State the task's **communicative purpose** in one sentence ("order tapas and drinks, politely").
2. Pick the **primary skill** by output channel (here: Speaking → transactions).
3. Pick the **most specific CV scale** whose can-do matches the purpose
   (`cefr/speaking/transactions`), not the "overall" scale, unless nothing fits.
4. Set the **target level band** the task is authored for (e.g. A1–A2).
5. Record the scale IRI + level band in the task inventory (project pack).
6. If the task mediates (relays/explains/translates), add the mediation scale IRI
   **and** keep the output-channel skill IRI.
7. If no CV scale fits, do **not** invent one — flag for expert review and, if
   truly needed, propose a registry addition for AE's approval.

## Level anchoring
Use the Companion Volume plus-levels (A2+, B1+, B2+) where the client needs finer
bands. Pre-A1 exists for reception and simple production/interaction only. Always
express a learner's estimated level as a **band with evidence**, never a single
point estimate, unless a calibrated test justifies it.
