<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. -->

# Persona reporting pack (D4)

Three report blueprints from **one data layer** (the xAPI stream). Same facts,
three audiences, three languages of presentation.

## 1. Learner report — the dual ledger
- **Front (immersive):** the product's own metaphor — stamps, coins, ranks,
  souvenirs, streaks. No CEFR jargon, ever.
- **Back (on request / for the curious learner):** a plain-language "what this
  means" line that maps the metaphor to a CEFR band ("Barcelona stamp ≈ you can
  handle A2 service transactions"). This is the **dual ledger**: stamp ↔ band.
- Tone: encouraging, non-punitive; show next step, not deficits.

## 2. Teacher report — human-readable + machine-readable
- **Human view:** per learner and per cohort — current band estimate per skill
  (with evidence tier), tasks passed/failed with the authentic-task gate result,
  rubric-category profile (strengths/gaps), and the **pedagogical-action** history
  (what scaffolds were tried and their outcome).
- **Machine view (JSON):** derived from the **NLU→Pedagogy handoff contract** so an
  AI teacher can consume it. Schema:
```json
{
  "learner": "u-8842",
  "skill": "speaking",
  "cefr_estimate": {"band": "A2", "evidence_tier": 1, "confidence": "band-not-point"},
  "scales": [
    {"iri": ".../cefr/speaking/transactions", "last_result": "passed", "score_scaled": 0.83}
  ],
  "rubric_profile": {"task-fulfilment": 3, "range": 2, "accuracy": 2, "fluency": 2, "intelligibility": 3},
  "pedagogical_actions": [
    {"strategy": "graded-hint", "outcome": "self-corrected", "ts": "2026-08-07T10:12:00Z"}
  ],
  "recommended_next": {"scale_iri": ".../cefr/speaking/information-exchange", "band": "A2"}
}
```
- Both views cite scale IRIs; both show evidence tier; neither invents precision.

## 3. Administrator → HR report — KPI / ROI
- Framework: **Kirkpatrick** (Reaction, Learning, Behaviour, Results) + **Phillips
  ROI** where cost data exists. Present Learning/Behaviour from the xAPI stream;
  be explicit when Results/ROI are modelled vs. measured.
- **Incident family is independent** — never folded into learning KPIs. Report
  system failures/improvements with their own metrics and a **resolution ledger**
  (incident-id → status → fix). This keeps product reliability honest and separate
  from learner success.
- **Optional ESCO alignment** — map achieved competences to ESCO language
  skills for EU HR interoperability (cite ESCO; alignment, not equivalence).
- Aggregate only; no learner PII in HR-facing views.

## Cross-cutting rules
- One data layer, three views — never recompute facts differently per audience.
- Every number carries its **evidence tier**; every skill claim carries a **CEFR
  scale IRI**; every report carries the copyright block + APA list.
- Learner-facing = no jargon; teacher/admin-facing = descriptor-precise.
