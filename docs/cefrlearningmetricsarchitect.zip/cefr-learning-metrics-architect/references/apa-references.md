<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. profeanaeslava · profeanaeslavaedtech · UPV. Part of a PhD proposal. -->

# Canonical copyright block and APA 7th references

Embed both in **every** deliverable produced with this skill (standing
documentation rule — no artifact ships without them).

## Copyright block (top of every deliverable)

> © 2026 Ana Eslava-Graterol. All Rights Reserved. Brand & website:
> profeanaeslava · GitHub: profeanaeslavaedtech · Universitat Politècnica de
> València. This document applies the **MLLDE Measurement Module** (PhD proposal).
> MLLDE methodology; "Language Passport"™; "Grace". CEFR (Council of Europe),
> PCIC (Instituto Cervantes), xAPI (ADL/IEEE), ESCO (European Union) and IPA
> (International Phonetic Association) are cited standards, not redistributed.

When a deliverable is produced for a client, add the client's name as the
recipient, never as rights holder, unless AE instructs otherwise.

## References (APA 7th) — include the full list

Advanced Distributed Learning Initiative. (2017). *xAPI profiles specification* (Version 1.0). GitHub. https://adlnet.github.io/xapi-profiles/

Advanced Distributed Learning Initiative. (n.d.). *ADL xAPI profile server*. Retrieved August 4, 2026, from https://profiles.adlnet.gov/

Advanced Distributed Learning Initiative. (n.d.). *cmi5 specification* [Repository]. GitHub. Retrieved August 4, 2026, from https://github.com/AICC/CMI-5_Spec_Current

Council of Europe. (2020). *Common European Framework of Reference for Languages: Learning, teaching, assessment — Companion volume*. Council of Europe Publishing. https://www.coe.int/lang-cefr

European Commission. (n.d.). *ESCO: European Skills, Competences, Qualifications and Occupations*. Retrieved August 4, 2026, from https://esco.ec.europa.eu/

Europass. (n.d.). *Common European Framework of Reference for language skills* [Self-assessment grid]. European Union. Retrieved August 4, 2026, from https://europass.europa.eu/en/common-european-framework-reference-language-skills

IEEE. (2023). *IEEE standard for learning technology — JSON data model format and RESTful web service for learner experience data tracking and access (xAPI)* (IEEE Std 9274.1.1-2023). IEEE Standards Association.

Instituto Cervantes. (2006). *Plan curricular del Instituto Cervantes: Niveles de referencia para el español*. Biblioteca Nueva.

International Phonetic Association. (1999). *Handbook of the International Phonetic Association: A guide to the use of the International Phonetic Alphabet*. Cambridge University Press.

Kirkpatrick, J. D., & Kirkpatrick, W. K. (2016). *Kirkpatrick's four levels of training evaluation*. ATD Press.

Krashen, S. D. (1985). *The input hypothesis: Issues and implications*. Longman.

Microsoft. (n.d.). *Use pronunciation assessment* [Documentation]. Microsoft Learn. Retrieved August 4, 2026, from https://learn.microsoft.com/en-us/azure/ai-services/speech-service/how-to-pronunciation-assessment

Phillips, J. J., & Phillips, P. P. (2016). *Handbook of training evaluation and measurement methods* (4th ed.). Routledge.

Rustici Software. (n.d.). *SCORM and xAPI resources*. Retrieved August 4, 2026, from https://scorm.com/

Witt, S. M., & Young, S. J. (2000). Phone-level pronunciation scoring and assessment for interactive language learning. *Speech Communication, 30*(2–3), 95–108. https://doi.org/10.1016/S0167-6393(99)00044-8

If a deliverable cites an additional source (e.g. a client's LMS documentation
or a vendor API), add it to that deliverable's list in APA 7th and keep the
retrieval-date convention shown above.
