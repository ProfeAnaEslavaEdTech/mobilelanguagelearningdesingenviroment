<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. Plain-language glossary (audience: linguists / non-engineers). -->

# Glossary — plain-language definitions

Reuse this wording when explaining technical terms to non-engineers (teachers,
linguists, administrators).

- **CEFR / MCER** — the Common European Framework of Reference (Marco Común
  Europeo de Referencia): the shared scale (Pre-A1–C2) describing what a learner
  *can do* in a language. We anchor every metric to it.
- **Companion Volume** — the 2020 update to the CEFR that adds mediation, online
  interaction and revised phonology scales. Our five-skill model follows it.
- **Descriptor scale** — a named "can-do" ladder for one activity (e.g. "Reading
  for orientation"). Each has an IRI in our registry.
- **Skill (the five)** — reading, writing, listening, speaking, and **mediation**
  (reformulating/relaying meaning; its output is always spoken or written).
- **Mediation** — helping meaning cross a gap: relaying information, explaining
  data, translating, facilitating a conversation.
- **Metric** — one measurable indicator (name + formula + data source +
  threshold) tied to a descriptor scale.
- **Metric family** — proficiency, process-support, pedagogical-action, or
  incident. Kept separate so KPIs stay clean.
- **Rubric** — the scoring guide. Ours is *self-scaling*: an authentic-task gate,
  0–3 categories judged against the target level, and pass floors.
- **Authentic-task gate** — did the learner actually accomplish the real goal?
  Language quality is only scored if the gate is passed.
- **Pass floor** — the minimum a category must reach (e.g. intelligibility ≥ 2)
  for an attempt to pass.
- **xAPI (Experience API / "Tin Can")** — a standard for recording learning
  "statements" (actor–verb–object) to a data store (an LRS). Richer than SCORM.
- **LRS (Learning Record Store)** — the database that holds xAPI statements.
- **SCORM** — an older e-learning packaging standard; good for LMS
  completion/grades, but it cannot carry our rich rubric/mediation data.
- **cmi5** — a modern profile that lets an LMS *launch* content while xAPI data
  still flows to an LRS — the bridge between SCORM-style LMSs and xAPI fidelity.
- **IRI** — a web-style unique identifier (like a URL) that names a verb, an
  activity type, or a descriptor scale so systems agree on meaning.
- **IRI registry** — our single list of approved IRIs
  (`assets/mllde-xapi-iri-registry.json`); never invent one outside it.
- **Dual telemetry** — recording both the *learner* act and the *teaching* act
  (what scaffold was used and whether it worked).
- **Evidence tier** — how sure we are a metric is real now: Tier 1 (today),
  Tier 2 (with instrumentation), Tier 3 (pending the pronunciation build).
- **GOP (Goodness of Pronunciation)** — phone-level scoring of how intelligibly a
  sound was produced (Witt & Young, 2000).
- **IPA** — the International Phonetic Alphabet; we use broad transcription to set
  target sounds and accepted variants per level.
- **Intelligibility-first** — we score being understood and appropriate, never
  native-accent perfection; regional/L1 accents are not penalised.
- **Dual ledger** — the mapping between the in-app metaphor (stamps/ranks) shown
  to learners and the CEFR band shown to teachers/admins.
- **ESCO** — the EU's skills/occupations taxonomy; optional mapping for HR
  interoperability.
- **Kirkpatrick / Phillips** — standard training-evaluation models (Reaction→
  Results; ROI) used for the administrator/HR report.
