<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. Cites Witt & Young (2000) GOP; IPA (1999); Microsoft pronunciation assessment. -->

# Evidence tiers and the voice pipeline

## The three evidence tiers (apply to every claim)

- **Tier 1 — measurable today.** The engine can compute it now from existing
  telemetry: reception item scores, task-gate results, rubric-category scores from
  a human or validated judge, completion/duration. Report as fact.
- **Tier 2 — measurable with instrumentation.** Computable once agreed
  instrumentation is switched on: AI-judge production scores pending validation,
  dual pedagogical-action capture, basic acoustic features. Report as
  "instrumented estimate — validation pending."
- **Tier 3 — pending the GOP build.** Requires the full pronunciation pipeline
  (phone-level Goodness-of-Pronunciation). Report as "planned metric — not yet
  measurable"; never show a Tier-3 number as if it were live.

Rule: **no report may claim more precision than its tier allows.** Every
voice-derived claim prints its tier.

## The voice pipeline (speaking / pronunciation)

Two halves, kept separate:

1. **Linguistic half (IPA).** A broad-transcription target-sound inventory per
   level: which phonemes/contrasts matter at A1 vs. B1, accepted variants, and the
   intelligibility threshold. This is authored by the linguist (AE) and cited to
   the IPA Handbook (1999). Accepted variants (e.g. Spanish *seseo* vs.
   *distinción*, *yeísmo*) are **never** penalised.

2. **Acoustic-engineering half (GOP).** Phone-level scoring after Witt & Young
   (2000): forced alignment → per-phone Goodness-of-Pronunciation → aggregate to
   intelligibility, not native-likeness. Vendor pronunciation-assessment APIs
   (e.g. Microsoft) may stand in during Tier-2 before the bespoke GOP build.

**The two-halves solution:** the IPA inventory defines *what* counts and *what is
allowed*; the GOP engine measures *how close*, bounded by the IPA rules so the
score rewards **intelligible, appropriate** speech. Store `ipa-target` and
`gop-score` extensions; keep the human intelligibility rubric as the Tier-1
fallback until GOP is validated.

## Intelligibility-first principle
The target is being understood and appropriate for the situation — never accent
elimination. A learner who is fully intelligible with a regional/L1-influenced
accent scores at ceiling on intelligibility. Build this into thresholds and say it
in the deliverable.

## Honesty in reporting
When cohort data does not yet exist, state that the evidence base today is **expert
evaluation + UX-testing signal**, not longitudinal cohort outcomes. This candour is
part of the brand and protects credibility with clients and reviewers.
