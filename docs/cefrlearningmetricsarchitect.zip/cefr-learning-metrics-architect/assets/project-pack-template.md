<!-- © 2026 Ana Eslava-Graterol. All Rights Reserved. Blank project pack — fill one per client app. -->

# MLLDE Measurement Module — Project Pack (fill one per client)

The **engine** (this skill + its references) never changes. Each client fills this
**pack**. Applying the module to a second app = filling this pack again.

## 0. Identification
- Client / app name:
- Contact & role:
- Date / version:
- Prepared by: Ana Eslava-Graterol (MLLDE Measurement Module)

## 1. Languages
- Target language(s):
- Base language(s):

## 2. CEFR levels in scope
- Range (Pre-A1 … C2):
- Plus-levels needed (A2+, B1+, B2+)? y/n:

## 3. Skills in scope
- [ ] Reading  [ ] Listening  [ ] Speaking  [ ] Writing  [ ] Mediation
- Notes on emphasis:

## 4. Task / mission inventory (map each to a CV scale)
| Task / mission | Communicative purpose | Primary skill | CEFR scale IRI (from registry) | Target band | Mediation? (2nd IRI) |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## 5. Pronunciation (required if Speaking in scope)
- IPA target-sound inventory (broad transcription) available? y/n:
- Target features per level:
- Accepted variants (never penalised) — e.g. seseo/distinción, yeísmo:
- If not available: generate a draft and FLAG for expert review.

## 6. Platform / delivery
- LMS / platform target:
- Standard required: [ ] pure xAPI + LRS  [ ] cmi5  [ ] SCORM 1.2  [ ] SCORM 2004
- LRS owner & location:
- PII / GDPR constraints:

## 7. Personas present
- [ ] Independent learners
- [ ] Teachers — [ ] human [ ] AI agent [ ] both
- [ ] LMS administrators reporting to HR
- ESCO alignment needed for HR? y/n:

## 8. Evidence base available today (be honest)
- What exists now (expert evaluation, UX-testing signal, pilot data, cohort data):
- Instrumentation that could be switched on (→ Tier 2):
- GOP / pronunciation build status (→ Tier 3):

## 9. Immersion metaphor (dual ledger)
- In-app metaphor (stamps, ranks, coins…):
- Mapping note (metaphor ↔ CEFR band):

## 10. Open questions / assumptions
- (State assumptions plainly where a field is missing; continue.)

---
*After the pack is filled, produce D1→D4 in order, reading the matching reference
file before each, and run the verification pass before delivery.*
